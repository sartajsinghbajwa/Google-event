/* Stripe Connect agency onboarding — no app-side bank details or account identifiers. */
'use strict';
window.EventOSPayments=(()=>{
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const path=()=>prefix()+'/payment-onboarding';
 function render(){
  const data=state.paymentOnboarding||{},s=data.status||{};
  return head('Agency payment onboarding','Connect your agency to a payment provider without sharing bank details with Honestly Zen Event Planning.')+
    '<section class="card pad m-top"><div class="section-title"><h2>Stripe Connect</h2></div>'+
    '<p class="small-note">Complete identity, business and payout details securely on Stripe. Honestly Zen Event Planning does not collect or store bank account numbers.</p>'+
    '<div class="grid kpis">'+
    stat('Provider linked',s.connected?'Yes':'No','Stripe Express account','wallet')+
    stat('Business details',s.details_submitted?'Submitted':'Pending','Provider verification','file')+
    stat('Payouts',s.payouts_enabled?'Enabled':'Pending','Provider approval','check')+
    stat('Card charges',s.charges_enabled?'Enabled':'Pending','Provider status','wallet')+'</div>'+
    (!data.configured?'<p class="small-note m-top">Payment onboarding is not configured by the Honestly Zen Event Planning platform administrator. Live payments remain disabled.</p>':
      '<div class="m-top"><label class="field"><span>Registered business country</span><select id="connect-country" '+(s.connected?'disabled':'')+'>'+
      [['CA','Canada'],['US','United States'],['GB','United Kingdom'],['AU','Australia']].map(x=>'<option value="'+x[0]+'" '+(s.country===x[0]?'selected':'')+'>'+x[1]+'</option>').join('')+'</select></label>'+
      '<div class="head-actions" style="margin-top:14px"><button class="btn primary" data-connect-action="start">'+
      (s.connected?'Continue provider onboarding':'Connect agency with Stripe')+'</button>'+
      (s.connected?'<button class="btn" data-connect-action="refresh">Refresh provider status</button>':'')+'</div></div>')+
    '<p class="small-note m-top">'+esc(data.note||'Stripe approval is required before account payouts can begin.')+'</p></section>'+
    '<section class="card pad m-top"><h2>Agency invoice payments</h2><p class="small-note">Existing manual invoice payment tracking remains unchanged. Stripe Connect onboarding by itself does not activate live invoice checkout, payouts or automatic refunds; those require separately tested payment routing and reconciliation.</p></section>';
 }
 document.addEventListener('click',async e=>{
   const el=e.target.closest('[data-connect-action]');if(!el)return;
   el.disabled=true;
   try{
     if(el.dataset.connectAction==='start'){
       const country=document.getElementById('connect-country')?.value||'CA';
       const r=await api(path()+'/start',{method:'POST',body:{country}});
       if(!r.url||!r.url.startsWith('https://connect.stripe.com/'))throw Error('Payment provider returned an invalid link');
       window.location.assign(r.url);
     }else if(el.dataset.connectAction==='refresh'){
       const r=await api(path()+'/refresh',{method:'POST'});
       toast(r.status?.payouts_enabled?'Stripe reports payouts enabled':'Provider status updated');
       await refresh();
     }
   }catch(err){toast(err.message);el.disabled=false;}
 });
 return {render};
})();
