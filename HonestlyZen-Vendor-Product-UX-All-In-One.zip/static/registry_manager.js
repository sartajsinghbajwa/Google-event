/* Honestly Zen Event Planning gift registry organizer console — products, cash-fund pledges and donor management. */
'use strict';
(function(){
 const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const d=()=>state.registryData||{items:[],reservations:[],settings:{},can_edit:false,currency:'CAD'};
 const ep=()=>evpath()+'/registry';
 const amt=n=>new Intl.NumberFormat('en-CA',{style:'currency',currency:d().currency||'CAD'}).format((Number(n)||0)/100);
 const status=s=>'<span class="exp-status '+h(s)+'">'+h(s)+'</span>';
 function giftCard(g){
  const qty=g.kind==='gift',done=qty?g.reserved_quantity:g.pledged_cents,total=qty?g.quantity:g.target_cents;
  const pct=total?Math.min(100,Math.round(done/total*100)):0;
  return '<article class="registry-card">'+
   ((g.has_image||g.image_url)?'<img loading="lazy" class="registry-thumb" src="'+h(g.has_image?'/api'+ep()+'/items/'+g.id+'/image':g.image_url)+'" alt="">':'<div class="registry-thumb registry-placeholder">🎁</div>')+
   '<div class="registry-card-body">'+
   '<div class="registry-card-labels"><span>'+h(g.category)+'</span>'+(g.priority==='High'?'<span>Most wanted</span>':'')+(g.archived?status('archived'):'')+'</div>'+
   '<h3>'+h(g.title)+'</h3><p>'+h(g.description||'No description')+'</p>'+
   '<div class="registry-measure"><div class="registry-progress"><span style="width:'+pct+'%"></span></div>'+
   '<div class="registry-level">'+(qty?done+' of '+total+' reserved':amt(done)+' of '+amt(total)+' pledged')+'</div></div>'+
   '<div class="registry-card-foot"><span>'+ (qty?amt(g.price_cents):'Gift fund')+'</span>'+
   (d().can_edit?'<button class="btn tiny" onclick="registryEdit(\''+g.id+'\')">Edit item</button>':'')+'</div></div></article>';
 }
 function render(){
  const r=d(),items=r.items||[],res=r.reservations||[],settings=r.settings||{};
  const active=res.filter(x=>x.status==='active'),completed=res.filter(x=>x.status==='completed');
  return head('Gift Registry','Create a personalized gift wishlist and funds, reserve gifts safely, and track gifts received.',
       r.can_edit?button('Add gift or fund',"registryEdit('')"): '')+
   '<div class="experience-stats">'+[['Registry items',items.filter(g=>!g.archived).length],['Active reservations',active.length],['Completed gifts',completed.length]].map(([n,v])=>'<div><strong>'+v+'</strong><span>'+n+'</span></div>').join('')+'</div>'+
   '<section class="card pad m-top"><h2>Public gift registry</h2>'+
   '<p class="small-note">Visitors can reserve physical gifts or pledge toward a gift fund. Honestly Zen Event Planning never charges a card or collects money; pledges are not paid gifts. Donor contact details remain organizer-only.</p>'+
   '<div class="experience-admin-row"><label class="exp-check"><input type="checkbox" '+(settings.enabled?'checked':'')+' '+(r.can_edit?'':'disabled')+' onchange="registrySetting(\'enabled\',this.checked)"> Enable guest registry</label>'+
   (r.can_edit?'<button class="btn tiny" onclick="registryRotate()">Regenerate link</button>':'')+'</div>'+
   '<div class="experience-share"><input readonly aria-label="Public gift registry link" value="'+h(location.origin+r.share_url)+'">'+
   '<button class="btn" onclick="registryCopy()">Copy gift registry link</button>'+
   '<button class="btn" onclick="window.open(\''+h(r.share_url)+'\',\'_blank\')">View guest registry</button></div>'+
   '<form id="registrySettingsForm" class="experience-settings-form" onsubmit="registrySaveSettings(event)">'+
   '<label>Registry title<input maxlength="100" name="title" value="'+h(settings.title||'Our Gift Registry')+'" '+(r.can_edit?'':'disabled')+' required></label>'+
   '<label>Welcome message<textarea name="intro" maxlength="1200" rows="2" '+(r.can_edit?'':'disabled')+'>'+h(settings.intro||'')+'</textarea></label>'+
   (r.can_edit?'<button type="submit" class="btn">Save introduction</button>':'')+'</form></section>'+
   '<section class="card pad m-top"><div class="experience-heading"><h2>Wishlist & contribution funds</h2><span>'+items.length+' total items</span></div>'+
   '<div class="registry-cards">'+items.map(giftCard).join('')+'</div>'+
   (!items.length?'<p class="small-note">Your registry is empty. Add a product or fund to get started.</p>':'')+'</section>'+
   '<section class="card pad m-top"><div class="experience-heading"><h2>Reservation & pledge tracking</h2>'+
   '<button class="btn" onclick="location.href=\'/api\'+evpath()+\'/registry/export.csv\'">Export CSV</button></div>'+
   '<p class="small-note">Completed means the organizer has marked a gift as received or a pledge as fulfilled. A guest’s fund pledge is not a payment.</p>'+
   '<div class="table-wrap"><table class="table"><thead><tr><th>Gift / fund</th><th>Reserved by</th><th>Quantity / pledged</th><th>Status</th><th>Manage</th></tr></thead><tbody>'+
   res.map(x=>'<tr><td><strong>'+h(x.item_title)+'</strong><div class="tiny-note">'+h(x.note||'')+'</div></td>'+
    '<td>'+h(x.donor_name)+'<div class="tiny-note">'+h(x.donor_email||'')+'</div></td>'+
    '<td>'+(x.kind==='gift'?x.quantity+' reserved':amt(x.pledged_cents)+' pledged')+'</td><td>'+status(x.status)+'</td>'+
    '<td>'+(r.can_edit?'<select class="select" aria-label="Reservation status" onchange="registryReservation(\''+x.id+'\',this.value)">'+
    ['active','completed','cancelled'].map(v=>'<option value="'+v+'" '+(x.status===v?'selected':'')+'>'+v+'</option>').join('')+'</select>':'—')+'</td></tr>').join('')+
   (!res.length?'<tr><td colspan="5">No gifts reserved yet.</td></tr>':'')+'</tbody></table></div></section>';
 }
 async function refresh(){state.registryData=await api(ep());render()}
 async function update(work,note){try{await work();if(note)toast(note);await refresh()}catch(e){toast(e.message)}}
 window.registrySetting=(key,on)=>update(()=>api(ep(),{method:'PATCH',body:{[key]:on}}),'Registry setting saved');
 window.registrySaveSettings=e=>{e.preventDefault();const f=new FormData(e.target);update(()=>api(ep(),{method:'PATCH',body:{title:f.get('title'),intro:f.get('intro')}}),'Registry introduction updated')};
 window.registryCopy=async()=>{try{await navigator.clipboard.writeText(location.origin+d().share_url);toast('Registry link copied')}catch{toast('Unable to copy link')}};
 window.registryRotate=()=>{if(confirm('Replace the registry sharing link? Existing links will stop working.'))update(()=>api(ep()+'/rotate-link',{method:'POST'}),'Registry link rotated')};
 window.registryDelete=id=>{if(confirm('Delete this gift and all its reservations? This cannot be undone.')){document.getElementById('modalRoot').innerHTML='';update(()=>api(ep()+'/items/'+id,{method:'DELETE'}),'Gift deleted')}};
 window.registryReservation=(id,status)=>update(()=>api(ep()+'/reservations/'+id,{method:'PATCH',body:{status}}),'Reservation status updated');
 window.registryEdit=id=>{
  const gift=(d().items||[]).find(i=>i.id===id)||null,kind=gift?.kind||'gift';
  const modalRoot=document.getElementById('modalRoot');
  modalRoot.innerHTML='<div class="modal-overlay" id="giftEditOverlay"><section class="modal experience-editor-modal" role="dialog" aria-modal="true">'+
   '<header class="modal-head"><h2>'+(id?'Edit gift':'Add gift or fund')+'</h2><button class="xclose" onclick="document.getElementById(\'modalRoot\').innerHTML=\'\'">×</button></header>'+
   '<div class="modal-body"><form id="giftEditor" onsubmit="registrySaveItem(event)">'+
   '<input type="hidden" name="item_id" value="'+h(id)+'"><div class="inline-fields">'+
   '<label class="field"><span>Registry item type</span><select name="kind" onchange="registryShowKind()"><option value="gift" '+(kind==='gift'?'selected':'')+'>Physical gift</option><option value="fund" '+(kind==='fund'?'selected':'')+'>Contribution fund</option></select></label>'+
   '<label class="field"><span>Priority</span><select name="priority"><option value="Normal" '+(gift?.priority==='High'?'':'selected')+'>Normal</option><option value="High" '+(gift?.priority==='High'?'selected':'')+'>Most wanted</option></select></label>'+
   '<label class="field wide"><span>Gift or fund name</span><input name="title" maxlength="130" required value="'+h(gift?.title||'')+'"></label>'+
   '<label class="field"><span>Category</span><input name="category" maxlength="60" value="'+h(gift?.category||'Home')+'"></label>'+
   '<label class="field" data-gift-only><span>How many gifts needed</span><input name="quantity" type="number" min="1" max="100" value="'+(gift?.quantity||1)+'"></label>'+
   '<label class="field" data-gift-only><span>Estimated price ('+h(d().currency)+')</span><input name="price" type="number" min="0" step=".01" value="'+((gift?.price_cents||0)/100).toFixed(2)+'"></label>'+
   '<label class="field" data-fund-only><span>Fund goal ('+h(d().currency)+')</span><input name="target" type="number" min="1" step=".01" value="'+((gift?.target_cents||10000)/100).toFixed(2)+'"></label>'+
   '<label class="field wide"><span>Product purchase link (HTTPS, optional)</span><input name="link_url" type="url" maxlength="500" value="'+h(gift?.link_url||'')+'" placeholder="https://shop.example/gift"></label>'+
   '<input type="hidden" name="image_url" value="'+h(gift?.image_url||'')+'">'+
   '<label class="field wide"><span>Upload product image (JPEG, PNG or WebP up to 8 MB)</span><input name="photo" type="file" accept="image/jpeg,image/png,image/webp"></label>'+ 
   (gift?.has_image?'<div class="field wide"><span>Uploaded image</span><img class="registry-thumb" style="width:140px" src="/api'+ep()+'/items/'+gift.id+'/image" alt="Uploaded gift image"><button type="button" class="btn tiny" onclick="registryRemoveImage(\''+gift.id+'\')">Remove uploaded image</button></div>':'')+
   '<label class="field wide"><span>Description</span><textarea name="description" rows="3" maxlength="1200">'+h(gift?.description||'')+'</textarea></label>'+
   '<label class="field wide"><span><input name="archived" type="checkbox" '+(gift?.archived?'checked':'')+'> Archive (hide from public)</span></label>'+
   '</div><div class="modal-actions">'+(id?'<button type="button" class="btn danger" onclick="registryDelete(\''+id+'\')">Delete</button>':'')+
   '<button type="button" class="btn" onclick="document.getElementById(\'modalRoot\').innerHTML=\'\'">Cancel</button>'+
   '<button type="submit" class="btn primary">Save registry item</button></div></form></div></section></div>';
  window.registryShowKind();
 };
 window.registryShowKind=()=>{
  const modal=document.getElementById('giftEditor');if(!modal)return;
  const fund=modal.elements.kind.value==='fund';
  modal.querySelectorAll('[data-fund-only]').forEach(n=>n.hidden=!fund);
  modal.querySelectorAll('[data-gift-only]').forEach(n=>n.hidden=fund);
 };
 window.registryRemoveImage=id=>{if(!confirm('Remove uploaded image?'))return;update(()=>api(ep()+'/items/'+id+'/image',{method:'DELETE'}),'Image removed').then(()=>document.getElementById('modalRoot').innerHTML='')};
 window.registrySaveItem=async e=>{
  e.preventDefault();const f=new FormData(e.target),id=f.get('item_id'),kind=f.get('kind');
  const toCents=x=>Math.round(Number(x||0)*100);
  const body={kind,title:f.get('title'),description:f.get('description'),category:f.get('category'),
   priority:f.get('priority'),quantity:kind==='fund'?1:Number(f.get('quantity')),
   price_cents:kind==='fund'?0:toCents(f.get('price')),
   target_cents:kind==='fund'?toCents(f.get('target')):0,
   image_url:f.get('image_url'),link_url:f.get('link_url'),archived:f.get('archived')==='on'};
  if(!Number.isInteger(body.price_cents)||!Number.isInteger(body.target_cents)){toast('Enter a valid amount');return}
  try{
   const saved=await api(ep()+'/items'+(id?'/'+id:''),{method:id?'PATCH':'POST',body});
   const itemId=id||saved.id;
   const file=e.target.querySelector('[name="photo"]')?.files?.[0];
   if(file){
    if(file.size>8*1024*1024)throw Error('Image must be less than 8 MB. Item details were saved.');
    const bytes=new Uint8Array(await file.arrayBuffer()),parts=[];
    for(let i=0;i<bytes.length;i+=32768)parts.push(String.fromCharCode(...bytes.subarray(i,i+32768)));
    await api(ep()+'/items/'+itemId+'/image',{method:'POST',body:{content_type:file.type,data_base64:btoa(parts.join(''))}});
   }
   document.getElementById('modalRoot').innerHTML='';toast('Registry item saved');await refresh()}
  catch(error){toast(error.message)}
 };
 window.EventOSRegistry={render,refresh};
})();
