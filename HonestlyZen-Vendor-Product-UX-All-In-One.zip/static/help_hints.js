/* Accessible contextual guidance for dynamically rendered Honestly Zen forms. */
'use strict';
(function(){
 const texts={
  title:'Use a descriptive title that clearly explains your question or content.',
  body:'Give enough context for a useful response. Never include private guest or payment information.',
  category:'Choose the category that best describes the service or topic.',
  event_type:'Select the type of celebration. Choose Other if none matches.',
  city:'Choose the main city, or province-wide when location does not matter.',
  business_name:'Enter the public trading name customers should recognize.',
  description:'Explain what is offered, what is included and what makes it distinctive. Minimum 40 characters for vendor listings.',
  service_cities:'Select the Alberta cities where this business will travel or provide services.',
  price_mode:'Choose fixed price, starting price or custom quote. Prices are in CAD.',
  starting_price:'For starting or fixed prices, enter an amount greater than zero. Choose custom quote for variable pricing.',
  listing_photo:'JPG, PNG or WebP only. Maximum 3 MB. Keep identifiable people’s photos permission-based.',
  image:'JPG, PNG or WebP only. Maximum 3 MB.',
  website:'Optional: enter a secure https:// URL.',
  video_url:'Optional: use a YouTube or Vimeo HTTPS video link.',
  public_email:'Optional: this email may be publicly visible to customers.',
  other_community:'Enter your town or community if you selected Other Alberta community.',
  brief:'Describe what you need, event date, estimated guest count, budget and any requirements.',
  event_date:'If known, choose the event date to help vendors assess availability.',
  budget:'Budget in Canadian dollars. Zero means you have not set a budget yet.',
  name:'Enter the name you want to use for this event or record.',
  full_name:'Use your preferred display name; account verification may require additional details.',
  email:'Use an email address you can access for confirmations and support.',
  password:'Choose a strong password and never share it.',
  venue:'Enter the event venue, location or online meeting address if known.',
  start_date:'Set the planned starting date. You can edit it later.',
  end_date:'The end date cannot be earlier than the start date.',
  max_guests:'Set the guest limit that fits your package or event capacity.',
  max_uses:'Choose how many accounts can redeem this access code.',
  expires_at:'Optional: specify when this offer or code should stop being valid.',
  audience:'Choose who should see the message. Avoid sending irrelevant announcements.',
  status:'Select the current workflow status. Public content may require administrator approval.',
  severity:'Select a level that accurately reflects the urgency of the message.',
  notes:'Add helpful background information. Do not submit private identification documents.',
  message_body:'Write a clear, respectful message about the vendor or event.',
  offer_amount:'Proposed amount in CAD. Confirm all service inclusions before agreeing.',
  total_amount:'Full agreed contract amount in Canadian dollars.',
  terms:'Include the scope, event date, payment schedule, cancellation rules and responsibilities.',
  consent:'Review the information carefully before agreeing.',
  typed_name:'Type your full name only after reviewing the agreement.'
 };
 const guess=(el)=>{
  const name=(el.name||'').toLowerCase();if(texts[name])return texts[name];
  if(el.type==='url')return 'Paste the complete secure https:// link.';
  if(el.type==='file')return 'Choose the file format and size required for this field.';
  if(el.type==='email')return 'Use a valid email address you can access.';
  if(el.type==='date'||el.type==='datetime-local')return 'Choose the relevant date or time.';
  if(el.type==='number')return 'Enter a number within the allowed range.';
  if(el.tagName==='SELECT')return 'Choose the most appropriate option from the menu.';
  if(el.tagName==='TEXTAREA')return 'Describe the item clearly and include relevant details.';
  return 'Enter the requested information. Required fields must be completed before saving.';
 };
 function scan(){
  document.querySelectorAll('form input,form select,form textarea').forEach(el=>{
   if(!el.name||el.type==='hidden'||el.type==='submit'||el.type==='button'||el.dataset.hzGuided)return;
   const label=el.closest('label')||el.id&&document.querySelector('label[for="'+CSS.escape(el.id)+'"]');
   if(!label)return;
   el.dataset.hzGuided='1';
   const msg=document.createElement('small');msg.className='hz-field-guide';
   const required=el.required?'Required. ':'Optional. ';
   const min=el.getAttribute('minlength');const max=el.getAttribute('maxlength');
   msg.textContent=required+guess(el)+(min?' Minimum '+min+' characters.':'')+(max?' Maximum '+max+' characters.':'');
   label.append(msg);
  });
 }
 let scheduled=false;
 function queue(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;scan()})}
 document.addEventListener('DOMContentLoaded',()=>{scan();new MutationObserver(queue).observe(document.body,{childList:true,subtree:true})});
})();
