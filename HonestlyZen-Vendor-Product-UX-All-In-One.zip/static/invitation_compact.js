'use strict';
(() => {
  const ed=window.EventOSCanvasEditor;if(!ed)return;
  const setup=ed.setup,reset=ed.reset,oldArrange=ed.arrange;
  let design,ctx,tool='clipart',folder='All',workspace='',fetched=false,assets={clipart:[],fonts:[],can_manage:false};
  const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const folders=['All','Flowers','Borders','Symbols','Cultural','Other'];
  const groups={rose:'Flowers',leaf:'Flowers',bouquet:'Flowers',flourish:'Borders',mandala:'Borders',rings:'Symbols',heart:'Symbols',stars:'Symbols',lotus:'Cultural',butterfly:'Other'};
  const base=()=>prefix()+'/design-assets';
  const assetUrl=id=>'/api'+base()+'/'+encodeURIComponent(id)+'/thumbnail';
  async function load(force=false){
    const id=state.ws?.id;if(!id)return;
    if(!force&&fetched&&workspace===id)return;
    workspace=id;fetched=true;
    try{const result=await api(base());if(state.ws?.id!==id)return;
      assets=result;ctx.assets=assets;ctx.assetUrl=assetUrl;ctx.render();
    }catch(e){if(force)ctx.toast(e.message)}
  }
  ed.setup=(d,c)=>{design=d;ctx=c;c.assets=assets;c.assetUrl=assetUrl;setup(d,c);
    if(!fetched||workspace!==state.ws?.id)Promise.resolve().then(()=>load())};
  ed.reset=()=>{tool='clipart';folder='All';reset()};
  const fonts=()=>[['serif','Elegant serif'],['sans','Modern sans'],['script','Calligraphy'],['display','Bold display'],...assets.fonts.map(x=>['font:'+x.id,x.name])];
  function panel(){
    if(tool==='background')return `<div class="compact-choices">${['ivory','blush','sage','champagne','midnight','parchment'].map(x=>`<button class="btn tiny" data-canvas-action="background" data-value="${x}">${x}</button>`).join('')}</div>
      <label class="btn tiny">Upload background<input type="file" data-invite-file="cover" accept="image/png,image/jpeg,image/webp" hidden></label>
      ${ctx.media?.cover?`<button class="btn tiny" data-compact-action="remove-bg">Remove uploaded image</button><p class="tiny-note">${esc(ctx.media.cover.filename)}</p>`:''}
      <label class="compact-check"><input type="checkbox" data-canvas-setting="canvas_use_cover" ${design.canvas_use_cover?'checked':''}> Use uploaded background</label>

      <label class="compact-check"><input type="checkbox" data-canvas-setting="guest_show_countdown" ${design.guest_show_countdown?'checked':''}> Show days until the event on guest RSVP page</label>
      <label class="field"><span>Optional guest music (direct HTTPS .mp3, .m4a, .ogg or .wav link)</span><input type="url" data-canvas-setting="guest_music_url" maxlength="500" value="${esc(design.guest_music_url||'')}" placeholder="https://example.com/celebration.mp3"></label><p class="tiny-note">Guests choose Play themselves; music will never autoplay.</p>`;
    if(tool==='text')return `<div class="compact-text-grid">${[['host_line','Hosted by'],['headline','Headline'],['canvas_title','Couple names'],['subtitle','Details'],['canvas_date','Date'],['canvas_location','Venue'],['closing_note','Closing']].map(([k,n])=>`<label class="field"><span>${n}</span><input data-canvas-word="${k}" value="${esc(design[k]||'')}" maxlength="350"></label>`).join('')}</div>`;
    if(tool==='clipart'){
      const a=window.eventosCanvasArt||{},names=window.eventosCanvasArtNames||{};
      return `<nav class="compact-folders">${folders.map(x=>`<button class="btn tiny ${folder===x?'active':''}" data-compact-action="folder" data-value="${x}">${x}</button>`).join('')}</nav>
      <div class="compact-art-grid">${Object.keys(a).filter(k=>folder==='All'||groups[k]===folder).map(k=>`<button class="compact-art-choice" data-canvas-action="add-art" data-value="${k}"><svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.5">${a[k]}</svg><span>${esc(names[k])}</span></button>`).join('')}
      ${assets.clipart.filter(x=>folder==='All'||x.category===folder).map(x=>`<button class="compact-art-choice" data-compact-action="add-image" data-id="${esc(x.id)}"><img src="${assetUrl(x.id)}" alt=""><span>${esc(x.name)}</span></button>`).join('')}</div>`;
    }
    if(tool==='layers'){
      const hidden=new Set(design.canvas_hidden_fields||[]);
      const labels=[['host_line','Hosted by'],['headline','Headline'],['title','Couple names'],
        ['subtitle','Details'],['date','Date'],['location','Location'],['closing_note','Closing note']];
      const visibility='<div class="compact-field-visibility"><strong>Text visibility</strong>'+
        labels.map(([key,name])=>'<button type="button" class="btn tiny '+(hidden.has(key)?'is-hidden':'')+
        '" data-compact-action="toggle-field" data-key="'+key+'">'+(hidden.has(key)?'Show ':'Hide ')+name+'</button>').join('')+'</div>';

      return '<div class="compact-layer-info">Tap any element on the invitation to select it. Drag it to reposition.</div>'+
        '<div class="compact-inline"><button type="button" class="btn tiny" data-canvas-action="add-text">+ Add text</button>'+
        '<button type="button" class="btn tiny" data-compact-action="delete-selected" '+(ed.selectedInfo()?.kind==='item'?'':'disabled')+'>Delete selected</button></div>'+
        alignTools()+ed.layerTools()+'<div id="canvasInspector">'+ed.inspector()+'</div><div class="compact-power-tools"><strong>Pro editor shortcuts</strong><p>Ctrl/⌘+Z Undo · Ctrl/⌘+D Duplicate · Arrow keys Move · Shift+Arrows Move faster · [ ] Rotate · Delete Remove. Changes save when you tap Save invitation.</p></div>'+visibility;
    }
    if(tool==='fonts')return `<label class="field"><span>Invitation font</span><select data-canvas-setting="canvas_font">${fonts().map(([k,n])=>`<option value="${k}" ${design.canvas_font===k?'selected':''}>${esc(n)}</option>`).join('')}</select></label>
      <label class="field"><span>Heading color</span><input type="color" data-canvas-setting="accent_color" value="${design.accent_color}"></label>
      <label class="field"><span>Text color</span><input type="color" data-canvas-setting="canvas_text_color" value="${design.canvas_text_color}"></label>`;
    return window.EventOSAssetPanel?window.EventOSAssetPanel.render(assets):'<p>Library loading…</p>';
  }
  function contextual(){
    const chosen=ed.selectedInfo?.();
    if(!chosen)return '';
    const isExtra=chosen.kind==='item';
    const isHidden=!isExtra&&(design.canvas_hidden_fields||[]).includes(chosen.key);
    const label=isExtra?(chosen.item.kind==='text'?'Text layer':'Clipart layer'):
      ({title:'Couple names',date:'Date',location:'Location',headline:'Headline'}[chosen.key]||'Text');
    const value=isExtra&&chosen.item.kind==='text'?chosen.item.font:isExtra?design.canvas_font:((design.canvas_field_fonts||{})[chosen.key]||design.canvas_font);
    const isText=!isExtra||chosen.item.kind==='text';
    return '<div class="compact-selection-bar"><span class="compact-selection-label">'+esc(label)+'</span>'+
      (isText?'<label class="compact-inline-font">Font <select '+(isExtra?'data-canvas-prop="font"':'data-canvas-field-font="'+esc(chosen.key)+'"')+'>'+
        fonts().map(([k,n])=>'<option value="'+esc(k)+'" '+(k===value?'selected':'')+'>'+esc(n)+'</option>').join('')+'</select></label>':'')+
      (!isExtra?'<button type="button" class="btn tiny" data-compact-action="toggle-field" data-key="'+esc(chosen.key)+'">'+(isHidden?'Show':'Hide')+'</button>':'')+
      (isExtra?'<button type="button" class="btn tiny" data-compact-action="duplicate-selected">Duplicate</button>'+
        '<button type="button" class="btn tiny danger" data-compact-action="delete-selected">Delete</button>':'')+
      '</div>';
  }
  function alignTools(){
    const choice=ed.selectedInfo?.();
    const buttons=[['x',10,'Left'],['x',50,'Center'],['x',90,'Right'],['y',10,'Top'],['y',50,'Middle'],['y',90,'Bottom']];
    const selected=!!choice;
    return '<div class="compact-alignment-tools"><strong>Align on page</strong>'+
      buttons.map(([axis,value,label])=>'<button type="button" class="btn tiny" data-compact-action="align-item" data-axis="'+axis+'" data-position="'+value+'" '+(selected?'':'disabled')+'>'+label+'</button>').join('')+
      '<label class="compact-check"><input type="checkbox" data-compact-action="guides" '+(ed.guidesEnabled?.()?'checked':'')+'> Guides & snap</label></div>';
  }
  function refreshTools(){
    const root=document.getElementById('modalRoot')?.querySelector('.invite-compact-tools');
    if(!root)return;
    root.querySelectorAll('.compact-tool-tabs [data-compact-action="tool"]').forEach(n=>n.classList.toggle('active',n.dataset.value===tool));
    const bar=root.querySelector('.compact-action-holder');if(bar)bar.innerHTML=contextual();
    root.querySelector('[data-compact-action="undo"]')?.toggleAttribute('disabled',!ed.canUndo?.());
    root.querySelector('[data-compact-action="redo"]')?.toggleAttribute('disabled',!ed.canRedo?.());
    const body=root.querySelector('.compact-tool-body');
    if(body)body.innerHTML=panel();
  }
  window.EventOSCompactHistoryChanged=()=>{
    const root=document.getElementById('modalRoot');
    root?.querySelector('[data-compact-action="undo"]')?.toggleAttribute('disabled',!ed.canUndo?.());
    root?.querySelector('[data-compact-action="redo"]')?.toggleAttribute('disabled',!ed.canRedo?.());
  };
  window.EventOSCompactSelectionChanged=()=>{
    if(!ctx?.editable)return;
    if(ed.selection())tool='layers';
    refreshTools();
  };
  function compact(){return `<div class="invitation-design-settings invite-compact-tools"><div class="compact-history" aria-label="Edit history"><button type="button" class="btn tiny" data-compact-action="undo" ${ed.canUndo?.()?'':'disabled'}>↶ Undo</button><button type="button" class="btn tiny" data-compact-action="redo" ${ed.canRedo?.()?'':'disabled'}>↷ Redo</button><span>Tap a layer to move or resize it</span></div><nav class="compact-tool-tabs">${[['background','Background'],['text','Text'],['clipart','Clipart'],['layers','Layers'],['fonts','Fonts'],...(assets.can_manage?[['library','Library']]:[])].map(([k,n])=>`<button type="button" class="${tool===k?'active':''}" data-compact-action="tool" data-value="${k}">${n}</button>`).join('')}</nav><div class="compact-action-holder">${contextual()}</div><div class="compact-tool-body">${panel()}</div></div>`}
  ed.main=compact;ed.arrange=compact;
  window.EventOSCompactContext=()=>({design,ctx,assets,base,assetUrl});
  window.EventOSCompactRefresh=()=>load(true);
  window.EventOSCompactUseUploaded=(kind,id)=>{
    if(!design||!ctx||!ctx.canEdit||!id)return false;
    if(kind==='clipart'){
      if(design.canvas_items.length>=40){ctx.toast('Maximum 40 layers');return false}
      ed.checkpoint?.();
      const item={id:'art'+crypto.randomUUID().replace(/-/g,''),kind:'asset',asset_id:id,x:50,y:28,size:20,rotation:0,color:design.accent_color};
      design.canvas_items.push(item);tool='layers';ed.select('item:'+item.id);ctx.render();return true;
    }
    if(kind==='font'){
      const chosen=ed.selectedInfo?.();ed.checkpoint?.();
      if(chosen?.kind==='field'){
        design.canvas_field_fonts=design.canvas_field_fonts||{};
        design.canvas_field_fonts[chosen.key]='font:'+id;
      }else if(chosen?.kind==='item'&&chosen.item.kind==='text'){
        chosen.item.font='font:'+id;
      }else design.canvas_font='font:'+id;
      tool='fonts';ctx.render();return true;
    }
    return false;
  };
  document.getElementById('modalRoot')?.addEventListener('click',async e=>{
    const btn=e.target.closest('[data-compact-action]');if(!btn||!btn.closest('.invitation-designer')||!ctx)return;
    const action=btn.dataset.compactAction;
    if(action==='undo'||action==='redo'){
      const changed=action==='undo'?ed.undo?.():ed.redo?.();
      if(!changed)ctx.toast('Nothing to '+action);
      return;
    }
    if(action==='tool'){tool=btn.dataset.value;refreshTools()}
    if(action==='folder'){folder=btn.dataset.value;refreshTools()}
    if(action==='align-item'){
      const axis=btn.dataset.axis,value=Number(btn.dataset.position);
      if(!ed.alignSelected(axis,value))ctx.toast('Select a text or clipart layer to align');
    }
    if(action==='guides'){
      ed.setGuides(btn.checked);
      return;
    }
    if(action==='toggle-field'){
      const key=btn.dataset.key;
      if(!['host_line','headline','title','subtitle','date','location','closing_note'].includes(key))return;
      const hidden=new Set(design.canvas_hidden_fields||[]);
      if(hidden.has(key))hidden.delete(key);else hidden.add(key);
      ed.checkpoint?.();design.canvas_hidden_fields=[...hidden];
      ctx.render();
    }
    if(action==='delete-selected'){
      if(!ed.deleteSelected())ctx.toast('Select a clipart or extra text layer to delete');
    }
    if(action==='duplicate-selected'){
      const choice=ed.selectedInfo?.();
      if(choice?.kind==='item'){
        if(design.canvas_items.length>=40){ctx.toast('Maximum 40 layers');return}
        const copy={...choice.item,id:'art'+crypto.randomUUID().replace(/-/g,''),x:Math.min(100,choice.item.x+4),y:Math.min(100,choice.item.y+4)};
        ed.checkpoint?.();design.canvas_items.splice(choice.index+1,0,copy);
        ed.select('item:'+copy.id);ctx.render();
      }
    }
    if(action==='add-image'){
      if(design.canvas_items.length>=40){ctx.toast('Maximum 40 layers');return}
      const id=btn.dataset.id;if(!assets.clipart.some(x=>x.id===id))return;
      ed.checkpoint?.();design.canvas_items.push({id:'art'+crypto.randomUUID().replace(/-/g,''),kind:'asset',asset_id:id,x:50,y:28,size:20,rotation:0,color:design.accent_color});
      tool='layers';ctx.render();
    }
    if(action==='remove-bg'){
      const cover=ctx.media?.cover;if(!cover||!confirm('Remove uploaded background?'))return;
      try{await api(evpath()+'/invitation-media/'+encodeURIComponent(cover.id),{method:'DELETE'});
        ed.checkpoint?.();ctx.media.cover=null;design.canvas_use_cover=false;design.cover_image_url='';ctx.render();ctx.toast('Image removed. Save invitation.')}
      catch(err){ctx.toast(err.message)}
    }
  });
})();