/* Honestly Zen Event Planning public navigation: verifies the session with the server, never trusts localStorage. */
'use strict';
(function(){
 const esc=v=>String(v??'');
 const $all=selector=>Array.from(document.querySelectorAll(selector));
 const setAuthenticated=(user,workspace)=>{
  const logged=!!user;
  $all('.auth-guest').forEach(el=>{el.hidden=logged});
  $all('.auth-member').forEach(el=>{el.hidden=!logged});
  if(logged){
   const wid=workspace?.id;
   $all('.account-link').forEach(a=>{a.href=wid?('/app#/'+encodeURIComponent(wid)+'/myAccount'):'/app'});
   $all('[data-auth-cta]').forEach(a=>{a.href='/app'});
  }
  document.documentElement.classList.add('public-auth-ready');
 };
 async function session(){
  try{
   const res=await fetch('/api/me',{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});
   if(!res.ok)return setAuthenticated(null,null);
   const info=await res.json();
   setAuthenticated(info?.user,info?.workspaces?.[0]);
  }catch(e){setAuthenticated(null,null)}
 }
 async function brand(){
  try{
   const res=await fetch('/api/public/site-brand',{cache:'no-store',credentials:'same-origin'});
   if(!res.ok)return;
   const data=await res.json();
   const name=typeof data.site_name==='string'&&data.site_name.trim()?data.site_name.trim():'Honestly Zen Event Planning';
   // Use DOM APIs to avoid interpreting admin-controlled branding as HTML.
   $all('.site-logo,.market-logo').forEach(el=>{
    if(data.logo_url&&typeof data.logo_url==='string'){
     let img=el.querySelector('.brand-uploaded-logo');
     if(!img){img=document.createElement('img');img.className='brand-uploaded-logo';img.alt='';img.decoding='async';el.insertBefore(img,el.firstChild)}
     img.src=data.logo_url;
     img.onerror=()=>{img.remove();};
     const old=el.querySelector('.logo-shape');if(old)old.hidden=true;
    }
    el.setAttribute('aria-label',name+' home');
   });
   if(data.favicon_url&&typeof data.favicon_url==='string'&&!document.querySelector('link[rel="icon"]')){
    const ico=document.createElement('link');ico.rel='icon';ico.href=data.favicon_url;document.head.append(ico);
   }
  }catch(e){}
 }
 async function logout(){
  if(!confirm('Sign out of Honestly Zen Event Planning?'))return;
  try{const res=await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin'});if(!res.ok)throw Error('Sign-out failed');
   setAuthenticated(null,null);window.location.assign('/');
  }catch(e){alert('Could not sign out. Please retry from your Honestly Zen Event Planning dashboard.')}
 }
 function normalizeNavigation(){
  // Keep the marketing header design but give every marketing page the same destinations.
  const links=[['Home','/'],['Find vendors','/discover/vendors'],['Community','/#community'],['Planning blog','/news'],['For vendors','/for-vendors']];
  const header=document.querySelector('body > header');
  if(!header)return;
  const seoStyle=header.classList.contains('seo-nav');
  const mainStyle=header.classList.contains('mainnav');
  const simple=seoStyle||mainStyle||(!header.classList.contains('site-header'));
  const menus=simple?[header.querySelector('nav')].filter(Boolean):Array.from(header.querySelectorAll('.desktop-nav,.mobile-nav'));
  menus.forEach(nav=>{
    // Preserve marketing page anchors and buttons; add missing global destinations.
    if(simple)nav.textContent='';
    for(const [label,href] of links){
      if(!simple&&Array.from(nav.querySelectorAll('a')).some(a=>a.getAttribute('href')===href))continue;
      const a=document.createElement('a');a.href=href;a.textContent=label;nav.append(a);
    }
    if(simple){
      const login=document.createElement('a');login.href='/app?mode=login';login.className='auth-guest';login.textContent='Log in';nav.append(login);
      const dashboard=document.createElement('a');dashboard.href='/app';dashboard.className='auth-member';dashboard.hidden=true;dashboard.textContent='Dashboard';nav.append(dashboard);
      const account=document.createElement('a');account.href='/app';account.className='auth-member account-link';account.hidden=true;account.textContent='My Account';nav.append(account);
      const logout=document.createElement('button');logout.type='button';logout.className='auth-member signout';logout.hidden=true;logout.textContent='Sign out';nav.append(logout);
    }
  });
  const css=document.createElement('link');css.rel='stylesheet';css.href='/static/public_nav_shared.css?v=20261021-ux1';document.head.append(css);
 }
 document.addEventListener('DOMContentLoaded',()=>{
  normalizeNavigation();
  $all('.signout').forEach(b=>b.addEventListener('click',logout));
  session();brand();
 });
 window.addEventListener('pageshow',event=>{if(event.persisted)session()});
})();
