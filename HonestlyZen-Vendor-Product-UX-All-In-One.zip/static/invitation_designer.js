/* Honestly Zen Event Planning invitation workshop: upload or builder, photo gallery, owner-curated library. */
'use strict';
(() => {
  let design=null, original=null, currentEvent=null, saving=false;
  let media={invite:null,cover:null,photos:[]},library={templates:[],can_manage:false},availableFonts=[];
  let tab='create',selectedTemplate='';
  const root=()=>document.querySelector('#modalRoot');
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const canEdit=()=>state.ws?.role!=='viewer';
  const evUrl=()=>'/api'+evpath()+'/invitation-media';
  const fields=[['headline','Invitation headline',120],['host_line','Hosted by (optional)',160],['subtitle','Invitation subtitle',240],['closing_note','Closing message',350]];
  const templateChoices=[['classic','Classic elegance'],['garden','Garden romance'],['modern','Modern minimal'],['celebration','Festive celebration']];
  function preview(){
    const el=root()?.querySelector('#invitationLivePreview');if(!el||!design)return;
    const data={event_name:currentEvent.name,start_date:currentEvent.start_date,location:currentEvent.location};
    el.innerHTML=window.eventosInvitationExperience(data,design,'Sample Guest',media,evUrl())+
      '<div class="invite-rsvp-sample"><h3>RSVP</h3><p>Will you attend?</p><select disabled><option>Choose your response</option></select><button type="button" class="btn primary" disabled>Send RSVP</button><p>Preview only · Real answers are collected via the guest link.</p></div>';
    if(design.mode==='canvas'||design.mode==='builder'){
      window.eventosPrepareCanvasFonts?.(design,evUrl(),message=>toast(message));
    }
    if(window.EventOSCanvasEditor)window.EventOSCanvasEditor.attach(design,{
      event:currentEvent,media,render,preview,toast,canEdit:canEdit(),
      editable:tab==='create'||tab==='canvas'
    });
  }
  function editField([key,label,max]){
    const isLong=key==='closing_note'||key==='subtitle';
    return `<label class="field"><span>${esc(label)}</span>${isLong?`<textarea rows="2" maxlength="${max}" data-design="${key}">${esc(design[key])}</textarea>`:`<input type="text" maxlength="${max}" data-design="${key}" value="${esc(design[key])}">`}</label>`;
  }
  function selectField(key,label,items){return `<label class="field"><span>${label}</span><select data-design="${key}">${items.map(([id,name])=>`<option value="${id}" ${design[key]===id?'selected':''}>${esc(name)}</option>`).join('')}</select></label>`}
  const basicFonts=[['serif','Elegant serif'],['sans','Clean sans-serif'],['script','Script / calligraphy'],['display','Bold display']];
  function builderFontChoices(){
    return [...basicFonts,...availableFonts.map(item=>['font:'+item.id,item.name+' · Uploaded'])];
  }
  function guestPageOptions(){return `<section class="invite-guest-options"><h3 class="invite-section-title">Guest invitation extras</h3>
    <label class="rsvp-check-label"><input type="checkbox" data-design="guest_show_countdown" ${design.guest_show_countdown?'checked':''}> Show event countdown (days remaining)</label>
    <label class="field"><span>Music URL (optional, direct HTTPS audio link)</span><input type="url" data-design="guest_music_url" maxlength="500" value="${esc(design.guest_music_url||'')}" placeholder="https://example.com/celebration.mp3"></label>
    <p class="invite-library-help">Use music you have permission to share. Guests play it manually; no autoplay.</p></section>`}
  function showCreate(){return `<div class="invitation-design-settings">
    <p class="invitation-tip">Choose a finished invitation or build one here. Your guests keep their existing RSVP links and questions.</p>
    <h3 class="invite-section-title">How would you like to create the invitation?</h3>
    <div class="invite-mode-switch"><button type="button" data-invite-action="mode" data-value="builder" class="${design.mode==='builder'?'active':''}">✦ Use builder</button><button type="button" data-invite-action="mode" data-value="canvas" class="${design.mode==='canvas'?'active':''}">✥ Design canvas</button><button type="button" data-invite-action="mode" data-value="upload" class="${design.mode==='upload'?'active':''}">↑ Upload invitation</button></div>
    <button type="button" class="btn invite-preview-shortcut" data-invite-action="tab" data-value="preview">👁 See live guest preview →</button>
    ${design.mode==='canvas'?(window.EventOSCanvasEditor?.main()||'Canvas editor unavailable'):design.mode==='builder'?`<div class="invitation-edit-grid">
       ${selectField('template','Style',templateChoices)}
       ${selectField('font','Font',builderFontChoices())}
       ${selectField('alignment','Alignment',[['center','Centered'],['left','Left aligned']])}
       <label class="field"><span>Accent color</span><input type="color" data-design="accent_color" value="${esc(design.accent_color)}"></label>
       ${fields.map(editField).join('')}
       <div class="invite-upload-box invite-cover-picker"><label class="field wide"><span>Upload cover photo</span><input type="file" data-invite-file="cover" aria-label="Upload cover photo" accept="image/jpeg,image/png,image/webp"></label>
       <p>Choose a photo from your phone (JPG, PNG or WebP, up to 4 MB). It appears at the top of the invitation, separate from your photo gallery.</p>
       ${media.cover?`<div class="invite-file-row"><img class="invite-cover-thumb" src="${esc(evUrl()+'/'+encodeURIComponent(media.cover.id))}" alt="Current cover photo"><span>${esc(media.cover.filename)}</span><button type="button" class="btn tiny" data-invite-action="delete-media" data-id="${esc(media.cover.id)}">Remove cover</button></div>`:'<p>No cover photo uploaded yet.</p>'}</div>

       <label class="rsvp-check-label"><input type="checkbox" data-design="show_date" ${design.show_date?'checked':''}> Show event date</label>
       <label class="rsvp-check-label"><input type="checkbox" data-design="show_location" ${design.show_location?'checked':''}> Show event location</label>
       </div>`:`<div class="invite-upload-box">
       <label class="field"><span>Upload your finished invitation</span><input aria-label="Upload invitation" type="file" data-invite-file="invite" accept="image/jpeg,image/png,image/webp,application/pdf,.pdf"></label>
       <p>JPG, PNG, WebP (up to 4 MB) or PDF (up to 6 MB). Your RSVP form remains below the invitation.</p>
       ${media.invite?`<div class="invite-file-row"><span>${esc(media.invite.filename)}</span><button type="button" class="btn" data-invite-action="delete-media" data-id="${esc(media.invite.id)}">Remove</button></div>`:'<p>No invitation uploaded yet.</p>'}
       </div>`}
    ${design.mode==='canvas'?'':guestPageOptions()}
    </div>`}
  function showPhotos(){return `<div class="invitation-design-settings">
    <h3 class="invite-section-title">Your event photo gallery</h3>
    <p class="invite-library-help">Photos appear beneath the invitation on the guest RSVP page, whether you upload an invitation or use the builder.</p>
    <div class="invite-upload-box"><label class="field"><span>Add photos (up to 8)</span><input type="file" data-invite-file="photo" aria-label="Upload event photos" accept="image/png,image/jpeg,image/webp" multiple ${media.photos.length>=8?'disabled':''}></label>
    <label class="field" style="margin-top:10px"><span>Caption for new photos (optional)</span><input type="text" maxlength="120" id="invitePhotoCaption" placeholder="A special moment"></label>
    <p>JPG, PNG, or WebP, up to 4 MB per photo. Please only upload images you have permission to share.</p></div>
    <div class="invite-photo-list">${media.photos.map(pic=>`<div class="invite-photo-tile"><img src="${esc(evUrl()+'/'+encodeURIComponent(pic.id))}" loading="lazy" alt="${esc(pic.caption||pic.filename)}"><small>${esc(pic.caption||pic.filename)}</small><button type="button" class="btn tiny" data-invite-action="delete-media" data-id="${esc(pic.id)}">Remove</button></div>`).join('')}</div>
    ${media.photos.length===0?'<p class="invite-library-help">No photos uploaded yet.</p>':''}
    </div>`}
  function showLibrary(){return `<div class="invitation-design-settings"><h3 class="invite-section-title">Invitation theme &amp; template library</h3>
    <p class="invite-library-help">Everyone in your workspace can choose from these designs. Only the workspace owner (administrator) can add, change or remove templates.</p>
    <div class="invite-template-grid">${library.templates.map(t=>`<article class="invite-template-card ${selectedTemplate===t.id?'chosen':''}">
      <div class="invite-template-art" style="--swatch:${/^#[0-9a-fA-F]{6}$/.test(t.design.accent_color)?t.design.accent_color:'#557d74'}">✦</div>
      <h4>${esc(t.name)}</h4><p>${esc(t.description)}${t.has_background?' · Includes background image':''}</p>
      <button type="button" class="btn tiny" data-invite-action="apply-template" data-id="${esc(t.id)}">Use design</button>
      ${library.can_manage&&!t.built_in?`<button type="button" class="btn tiny" data-invite-action="update-template" data-id="${esc(t.id)}">Update</button><button type="button" class="btn tiny danger" data-invite-action="delete-template" data-id="${esc(t.id)}">Delete</button>`:''}
    </article>`).join('')}</div>
    ${library.can_manage?`<div class="invite-template-tools"><strong>Admin library tools</strong><button type="button" class="btn" data-invite-action="create-template">Save current design as template</button></div>
    <p class="invite-library-help">Saving a canvas template preserves background images and workspace-library clipart (not guest-specific text). Guest-specific text remains editable for each event. Built-in templates cannot be deleted.</p>`:''}
    </div>`}
  function render(){
    if(!design||!currentEvent)return;
    const element=root();if(!element)return;
    window.EventOSCanvasEditor?.setup(design,{event:currentEvent,media,render,preview,toast,canEdit:canEdit(),editable:tab==='create'||tab==='canvas'});
    element.innerHTML=`<div class="modal-overlay invitation-designer-overlay"><section class="modal invitation-designer" role="dialog" aria-modal="true" aria-labelledby="invitation-designer-title">
      <header class="modal-head"><div><h2 id="invitation-designer-title">Invitation workshop</h2><p class="tiny-note">${esc(currentEvent.name)} · Personalize the guest invitation page · Editor 2.4 Align & Resize</p></div><button type="button" class="xclose" data-invite-action="close" aria-label="Close">×</button></header>
      <nav class="invite-workshop-tabs" aria-label="Invitation editor sections"><button type="button" class="${tab==='create'?'active':''}" data-invite-action="tab" data-value="create">Create</button><button type="button" class="${tab==='library'?'active':''}" data-invite-action="tab" data-value="library">Theme library</button><button type="button" class="${tab==='photos'?'active':''}" data-invite-action="tab" data-value="photos">Photos (${media.photos.length})</button>${design.mode==='canvas'? `<button type="button" class="${tab==='canvas'?'active':''}" data-invite-action="tab" data-value="canvas">Arrange canvas</button>`:''}<button type="button" class="${tab==='preview'?'active':''}" data-invite-action="tab" data-value="preview">Guest preview</button></nav>
      <div class="invitation-design-grid ${tab==='preview'?'invite-preview-mode':tab==='canvas'?'invite-canvas-arrange-mode':''}">${tab==='create'?showCreate():tab==='canvas'?(window.EventOSCanvasEditor?.arrange()||''):tab==='library'?showLibrary():tab==='photos'?showPhotos():''}
      <div class="invitation-live"><div class="invite-preview-heading"><div class="invitation-live-label">LIVE GUEST PREVIEW</div>${tab==='preview'?'<button type="button" class="btn tiny" data-invite-action="tab" data-value="create">← Back to editor</button>':''}</div><div id="invitationLivePreview"></div><p class="invite-preview-help">Preview only · Changes appear here before saving. The RSVP form remains available on each guest’s invitation link.</p></div></div>
      <footer class="rsvp-builder-footer"><span class="invite-library-help">Guest RSVP questions are unchanged.</span><button type="button" class="btn" data-invite-action="close">Close</button><button type="button" class="btn primary" data-invite-action="save" ${saving||!canEdit()?'disabled':''}>${saving?'Saving…':'Save invitation'}</button></footer>
      </section></div>`;
    element.querySelectorAll('[data-design]').forEach(input=>{
      const update=()=>{design[input.dataset.design]=input.type==='checkbox'?input.checked:input.value;preview()};
      input.addEventListener('input',update);input.addEventListener('change',update);
    });
    element.querySelectorAll('[data-invite-file]').forEach(input=>input.addEventListener('change',()=>uploadFiles(input)));
    preview();
  }
  async function open(initialTab='create'){
    try{currentEvent={...state.event};const [d,m,l,a]=await Promise.all([api(evpath()+'/invitation-design'),api(evpath()+'/invitation-media'),api(prefix()+'/invitation-templates'),api(prefix()+'/design-assets')]);
      availableFonts=Array.isArray(a.fonts)?a.fonts:[];
      design={mode:'builder',...d};original=JSON.stringify(design);media=m;library=l;tab=initialTab==='preview'?'preview':design.mode==='canvas'?'canvas':'create';selectedTemplate='';window.EventOSCanvasEditor?.reset();render();}
    catch(e){toast(e.message)}
  }
  async function save(){
    if(saving||!canEdit())return;
    if(design.mode==='upload'&&!media.invite){toast('Upload an invitation file first');return;}
    const controller=new AbortController();
    let timeoutId;
    saving=true;
    const button=root()?.querySelector('[data-invite-action="save"]');
    if(button){button.disabled=true;button.textContent='Saving…';}
    try{
      timeoutId=setTimeout(()=>controller.abort(),20000);
      const response=await fetch('/api'+evpath()+'/invitation-design',{
        method:'PUT',credentials:'same-origin',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(design),signal:controller.signal
      });
      let result={};try{result=await response.json()}catch{}
      if(!response.ok)throw Error(typeof result.detail==='string'?result.detail:'Could not save invitation ('+response.status+').');
      design=result;original=JSON.stringify(design);
      toast('Invitation saved successfully');
    }catch(e){toast(e.name==='AbortError'?'Save timed out. Check your connection and reopen to verify the saved invitation.':e.message||'Unable to save invitation');}
    finally{
      clearTimeout(timeoutId);saving=false;
      // Always redraw from the settled state; never strand the Save button at Saving…
      if(design&&currentEvent)render();
    }
  }
  function base64(arrayBuffer){const bytes=new Uint8Array(arrayBuffer);let output='';for(let i=0;i<bytes.length;i+=32768)output+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(output)}
  async function uploadFiles(input){
    if(!canEdit())return;
    const kind=input.dataset.inviteFile;
    const files=[...input.files];if(!files.length)return;
    const caption=root()?.querySelector('#invitePhotoCaption')?.value||'';
    input.disabled=true;
    try{
      for(const file of files){
        if(kind==='photo'&&media.photos.length>=8){toast('Maximum eight photos');break}
        if(!['image/jpeg','image/png','image/webp',...(kind==='invite'?['application/pdf']:[])].includes(file.type))throw Error('Choose JPG, PNG, WebP'+(kind==='invite'?' or PDF':''));
        if(file.size>(file.type==='application/pdf'?6:4)*1024*1024)throw Error('File exceeds upload size limit');
        const payload={kind,filename:file.name,caption:kind==='photo'?caption:'',content_type:file.type,data_base64:base64(await file.arrayBuffer())};
        await api(evpath()+'/invitation-media',{method:'POST',body:payload});
      }
      media=await api(evpath()+'/invitation-media');if(kind==='invite'&&media.invite)design.mode='upload';if(kind==='cover'&&design.mode==='canvas')design.canvas_use_cover=true;
      toast(kind==='cover'?'Cover photo uploaded':kind==='photo'?'Photo added to gallery':'Invitation uploaded · save to switch modes');render();
    }catch(e){toast(e.message);media=await api(evpath()+'/invitation-media');render()}
  }
  async function removeMedia(id){
    if(!canEdit()||!window.confirm('Remove this uploaded file?'))return;
    try{await api(evpath()+'/invitation-media/'+encodeURIComponent(id),{method:'DELETE'});media=await api(evpath()+'/invitation-media');if(!media.invite&&design.mode==='upload')design.mode='builder';render();toast('File removed')}
    catch(e){toast(e.message)}
  }
  function selected(id){return library.templates.find(x=>x.id===id)}
  async function applyTemplate(id){
    const t=selected(id);if(!t)return;
    if(t.has_background){
      try{
        await api(evpath()+'/invitation-templates/'+encodeURIComponent(id)+'/apply-background',{method:'POST'});
        media=await api(evpath()+'/invitation-media');
      }catch(e){toast('Could not apply template background: '+e.message);return}
    }
    const keep=['headline','host_line','subtitle','closing_note','canvas_title','canvas_date','canvas_location'];
    const content=Object.fromEntries(keep.map(key=>[key,design[key]]));
    const extraText=(design.canvas_items||[]).filter(item=>item.kind==='text');
    design={...design,...t.design,...content,mode:t.design.mode==='canvas'?'canvas':'builder',
      canvas_items:[...(t.design.canvas_items||[]).filter(item=>item.kind==='clipart'||item.kind==='asset'),...extraText],
      canvas_use_cover:t.has_background||design.canvas_use_cover};
    selectedTemplate=id;window.EventOSCanvasEditor?.reset();
    toast('Artwork applied; your event wording is preserved. Save invitation to publish.');tab='create';render();
  }
  function artworkTemplate(){
    return {...design,mode:design.mode==='canvas'?'canvas':'builder',
      canvas_use_cover:false,canvas_title:'',canvas_date:'',canvas_location:'',
      host_line:'',headline:"You're invited",subtitle:'',
      closing_note:'We look forward to celebrating with you.',
      canvas_items:(design.canvas_items||[]).filter(item=>item.kind==='clipart'||item.kind==='asset').map(item=>({...item}))};
  }
  async function addTemplate(){
    if(!library.can_manage)return;
    const name=window.prompt('Name for your reusable template?');if(!name)return;
    const description=window.prompt('Short template description (optional):')||'';
    try{await api(prefix()+'/invitation-templates',{method:'POST',body:{name,description,design:artworkTemplate(),
      background_event_id:design.mode==='canvas'&&design.canvas_use_cover&&media.cover?currentEvent.id:null}});
      library=await api(prefix()+'/invitation-templates');tab='library';render();toast('Artwork-only template saved · edit text on each event')}
    catch(e){toast(e.message)}
  }
  async function updateTemplate(id){
    if(!library.can_manage)return;const t=selected(id);if(!t||t.built_in)return;
    if(!window.confirm(`Replace “${t.name}” with your current builder settings?`))return;
    try{await api(prefix()+'/invitation-templates/'+encodeURIComponent(id),{method:'PUT',body:{name:t.name,description:t.description,design:artworkTemplate(),
      background_event_id:design.mode==='canvas'&&design.canvas_use_cover&&media.cover?currentEvent.id:''}});
      library=await api(prefix()+'/invitation-templates');render();toast('Artwork template updated')}
    catch(e){toast(e.message)}
  }
  async function deleteTemplate(id){
    if(!library.can_manage)return;const t=selected(id);if(!t||t.built_in||!window.confirm(`Delete “${t.name}” from the library?`))return;
    try{await api(prefix()+'/invitation-templates/'+encodeURIComponent(id),{method:'DELETE'});library=await api(prefix()+'/invitation-templates');render();toast('Template removed')}
    catch(e){toast(e.message)}
  }
  function close(){if(JSON.stringify(design)!==original&&!window.confirm('Discard unsaved design changes? Uploaded files are stored separately.'))return;design=null;currentEvent=null;window.EventOSCanvasEditor?.reset();root().innerHTML=''}
  document.querySelector('#modalRoot')?.addEventListener('click',e=>{
    const btn=e.target.closest('[data-invite-action]');if(!btn||!design)return;
    const a=btn.dataset.inviteAction,id=btn.dataset.id;
    if(a==='close')close();else if(a==='save')save();else if(a==='mode'){design.mode=btn.dataset.value;if(design.mode==='canvas')tab='canvas';render()}
    else if(a==='tab'){tab=btn.dataset.value;render()}else if(a==='delete-media')removeMedia(id);
    else if(a==='apply-template')applyTemplate(id);else if(a==='create-template')addTemplate();
    else if(a==='update-template')updateTemplate(id);else if(a==='delete-template')deleteTemplate(id);
  });
  window.openInvitationDesigner=open;
})();
