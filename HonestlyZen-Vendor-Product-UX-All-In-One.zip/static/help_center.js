/* Honestly Zen Event Planning searchable Help Center, for personal and business workspaces. */
'use strict';
(function(){
const catalog=window.EventOSHelpCatalog||{categories:[],articles:[]};
const categories=catalog.categories||[];
const articles=catalog.articles||[];
const categoryById=Object.fromEntries(categories.map(c=>[c.id,c]));
const byId=Object.fromEntries(articles.map(a=>[a.id,a]));
const escapeHTML=x=>String(x??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[k]));
let filterAudience='auto',category='all',kind='all',query='';
const audience=()=>filterAudience==='auto'?(state.ws?.type==='business'?'business':'personal'):filterAudience;
const available=a=>a.audience==='both'||a.audience===audience();
const kindName=k=>k==='faq'?'FAQ':k==='troubleshooting'?'Troubleshooting':'Step-by-step guide';
const snippets=()=>articles.filter(a=>available(a)).filter(a=>category==='all'||a.category===category).filter(a=>kind==='all'||a.kind===kind).filter(a=>{
 const q=query.trim().toLowerCase();
 if(!q)return true;
 const source=[a.title,a.summary,a.keywords,categoryById[a.category]?.label,...a.steps,a.tip].join(' ').toLowerCase();
 return q.split(/\s+/).every(part=>source.includes(part));
});
const catLink=c=>'<button type="button" class="hc-category'+(c.id===category?' selected':'')+'" onclick="EventOSHelp.setCategory(\''+escapeHTML(c.id)+'\')"><span>'+escapeHTML(c.label)+'</span><span class="hc-count">'+articles.filter(a=>a.category===c.id).length+'</span></button>';
const articleCard=a=>'<button type="button" class="hc-article" onclick="EventOSHelp.open(\''+escapeHTML(a.id)+'\')"><div class="hc-article-meta"><span>'+escapeHTML(categoryById[a.category]?.label||'Help')+'</span><span>'+escapeHTML(kindName(a.kind))+'</span></div><strong>'+escapeHTML(a.title)+'</strong><p>'+escapeHTML(a.summary)+'</p><div class="hc-article-foot">Read article <span aria-hidden="true">→</span></div></button>';
function resultHTML(){
 const list=snippets();
 const label=category==='all'?'All topics':categoryById[category]?.label||'All topics';
 return '<div class="hc-results-head"><div><h2>'+escapeHTML(label)+'</h2><p>'+list.length+' '+(list.length===1?'article':'articles')+' match your filters</p></div>'+
 (category!=='all'||kind!=='all'||query?'<button type="button" class="btn" onclick="EventOSHelp.resetFilters()">Clear filters</button>':'')+'</div>'+
 (list.length?'<div class="hc-article-grid">'+list.map(articleCard).join('')+'</div>':'<div class="hc-no-results"><strong>No matching articles</strong><p>Try a different search or create a support ticket if you are stuck.</p><button class="btn primary" onclick="go(\'support\')">Contact support</button></div>');
}
function renderHome(){
 const type=audience();
 const visibleCats=categories.filter(c=>c.audience==='both'||c.audience===type);
 if(category!=='all'&&!visibleCats.some(c=>c.id===category))category='all';
 const common=articles.filter(a=>a.audience==='both').length;
 const specific=articles.filter(a=>a.audience===type).length;
 return head('Help Center','Search guides, answers and tutorials for everything you do in Honestly Zen Event Planning.')+
 '<section class="hc-hero"><div><div class="hc-eyebrow">EVENTOS KNOWLEDGE BASE</div><h2>What can we help you with?</h2><p>Explore '+(common+specific)+' available guides for '+(type==='business'?'business planners and agencies':'personal event planning')+'. Find instructions, troubleshooting tips and answers without waiting for a ticket.</p><label class="hc-search-label"><span class="visually-hidden">Search help articles</span><input type="search" id="hc-search" autocomplete="off" placeholder="Search RSVP, seating, payment, invitations..." value="'+escapeHTML(query)+'" oninput="EventOSHelp.setQuery(this.value)" aria-label="Search help articles"></label></div><div class="hc-hero-aside"><div><strong>'+categories.length+'</strong><span>topic categories</span></div><div><strong>'+articles.length+'</strong><span>total guides and FAQs</span></div><div><strong>24/7</strong><span>searchable self-service</span></div></div></section>'+
 '<div class="hc-switcher"><span>Browse as</span><div class="hc-segments" role="group" aria-label="Help audience"><button type="button" class="'+(type==='personal'?'active':'')+'" aria-pressed="'+(type==='personal')+'" onclick="EventOSHelp.setAudience(\'personal\')">Personal planning</button><button type="button" class="'+(type==='business'?'active':'')+'" aria-pressed="'+(type==='business')+'" onclick="EventOSHelp.setAudience(\'business\')">Business & agencies</button></div><span class="hc-context">Shared guides are included in both views</span></div>'+
 '<div class="hc-main-layout"><aside class="card hc-categories"><div class="hc-category-heading"><strong>Topics</strong><span>'+visibleCats.length+' groups</span></div><button type="button" class="hc-category'+(category==='all'?' selected':'')+'" onclick="EventOSHelp.setCategory(\'all\')"><span>All topics</span><span class="hc-count">'+(common+specific)+'</span></button><div class="hc-category-label">Core help</div>'+visibleCats.filter(c=>c.audience==='both').map(catLink).join('')+'<div class="hc-category-label">'+(type==='business'?'Business workflows':'Personal workflows')+'</div>'+visibleCats.filter(c=>c.audience!=='both').map(catLink).join('')+'</aside><main class="hc-results"><div class="hc-toolbar"><span>Show</span><select id="hc-kind" aria-label="Article type" onchange="EventOSHelp.setKind(this.value)"><option value="all"'+(kind==='all'?' selected':'')+'>All content</option><option value="guide"'+(kind==='guide'?' selected':'')+'>Guides</option><option value="faq"'+(kind==='faq'?' selected':'')+'>FAQs</option><option value="troubleshooting"'+(kind==='troubleshooting'?' selected':'')+'>Troubleshooting</option></select><button class="btn" type="button" onclick="go(\'support\')">Open Support Center →</button></div><div id="hc-results" aria-live="polite">'+resultHTML()+'</div></main></div>'+supportStrip();
}
function supportStrip(){return '<section class="hc-support-strip"><div><strong>Still need help?</strong><p>Send a private ticket to Honestly Zen Event Planning support. Your question and follow-up replies stay with your account.</p></div><button class="btn primary" type="button" onclick="go(\'support\')">Create support ticket</button></section>'}
function renderArticle(a){
 const c=categoryById[a.category]||{};
 if(!available(a))return head('Article unavailable','Switch to the appropriate Personal or Business help view to read this topic.')+'<button class="btn" type="button" onclick="go(\'help\')">← Back to Help Center</button>';
 const related=articles.filter(b=>b.id!==a.id&&available(b)&&b.category===a.category).slice(0,4);
 return head('Help Center','Guides and tutorials for your workspace')+
 '<nav class="hc-breadcrumb" aria-label="Help navigation"><button type="button" onclick="go(\'help\')">All help</button><span>›</span><span>'+escapeHTML(c.label||'Topic')+'</span></nav>'+
 '<article class="card hc-reader"><div class="hc-reader-head"><span class="hc-eyebrow">'+escapeHTML(audience()==='business'?'Business / Agency help':'Personal help')+' · '+escapeHTML(kindName(a.kind))+'</span><h2>'+escapeHTML(a.title)+'</h2><p>'+escapeHTML(a.summary)+'</p></div><div class="hc-reader-content"><h3>How to do it</h3><ol>'+a.steps.map(step=>'<li>'+escapeHTML(step)+'</li>').join('')+'</ol>'+(a.tip?'<div class="hc-tip"><strong>Helpful note</strong><p>'+escapeHTML(a.tip)+'</p></div>':'')+'<div class="hc-reader-actions"><button type="button" class="btn primary" onclick="EventOSHelp.askSupport(\''+escapeHTML(a.id)+'\')">Ask support about this topic</button><button class="btn" type="button" onclick="go(\'help\')">Back to articles</button></div></div></article>'+
 (related.length?'<section class="hc-related"><h2>Related articles</h2><div class="hc-article-grid">'+related.map(articleCard).join('')+'</div></section>':'')+supportStrip();
}
function render(){
 const slug=state.page==='help'?state.eventId:null;
 return slug?(byId[slug]?renderArticle(byId[slug]):head('Help article not found','This guide may have moved.')+'<button type="button" class="btn" onclick="go(\'help\')">Browse all topics</button>'):renderHome();
}
function redraw(){if(state.page==='help')window.render()}
function askSupport(id){
 const a=byId[id];if(!a||!available(a))return;
 const type=categoryById[a.category]?.id||'';
 const supportCategory=['billing','plans','invoices','connect'].includes(type)?'billing':['account','security','workspace'].includes(type)?'account':['trouble','websites','invitations','checkin'].includes(type)?'technical':(['support'].includes(type)?'other':'event');
 window.EventOSHelp.draft={subject:'Help with: '+a.title,category:supportCategory,message:'I read the Honestly Zen Event Planning Help Center article “'+a.title+'” ('+a.id+').\n\nMy question or issue: '};
 go('support');
}
window.EventOSHelp={
 render,askSupport,draft:null,
 setAudience:v=>{if(!['personal','business'].includes(v))return;filterAudience=v;category='all';redraw()},
 setCategory:v=>{if(v!=='all'&&!categories.some(c=>c.id===v&&['both',audience()].includes(c.audience)))return;category=v;redraw()},
 setKind:v=>{if(!['all','guide','faq','troubleshooting'].includes(v))return;kind=v;const node=document.getElementById('hc-results');if(node)node.innerHTML=resultHTML()},
 setQuery:v=>{query=String(v||'').slice(0,180);const node=document.getElementById('hc-results');if(node)node.innerHTML=resultHTML()},
 resetFilters:()=>{category='all';kind='all';query='';redraw()},
 open:id=>{if(byId[id]&&available(byId[id]))go('help',id)}
};
})();
