/* Honestly Zen Event Planning Phase 7: subscription usage and account recovery UX. */
'use strict';
(function(){
 const esc7=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const request=async(path,body)=>{
   const r=await fetch('/api'+path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   const d=await r.json().catch(()=>({}));
   if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'Request failed');
   return d;
 };
 const flow=()=>location.hash.startsWith('#/verify-email?')?'verify':
                 location.hash.startsWith('#/reset-password?')?'reset':'';
 function page(title,subtitle,form){
   document.getElementById('app').innerHTML='<div class="auth-page"><aside class="auth-aside"><div><div class="brand"><div class="logo-mark">✦</div> Event<span>OS</span></div><h1>Secure your<br>Honestly Zen Event Planning account.</h1></div><p>Plan · Collaborate · Celebrate</p></aside><main class="auth-panel"><div class="auth-box"><h2>'+esc7(title)+'</h2><p>'+esc7(subtitle)+'</p>'+form+'<p><a href="/" class="btn">Back to sign in</a></p></div></main></div>';
 }
 function renderAuthRoute(){
   const mode=flow();if(!mode)return false;
   const token=new URLSearchParams(location.hash.split('?')[1]||'').get('token')||'';
   if(mode==='verify'){
     page('Confirm your email','Complete your Honestly Zen Event Planning account registration.',
       '<form id="phase7VerifyForm"><button class="btn primary full" type="submit">Verify email address</button></form><p id="phase7Result" class="small-note" role="status"></p>');
   }else{
     page('Choose a new password','Your reset link expires one hour after it was issued.',
       '<form id="phase7ResetForm"><label class="field"><span>New password (minimum 12 characters)</span><input name="password" type="password" minlength="12" maxlength="256" autocomplete="new-password" required></label><button class="btn primary full" type="submit">Reset password</button></form><p id="phase7Result" role="status"></p>');
   }
   const el=document.getElementById(mode==='verify'?'phase7VerifyForm':'phase7ResetForm');
   el.addEventListener('submit',async event=>{
     event.preventDefault();const btn=el.querySelector('button'),status=document.getElementById('phase7Result');btn.disabled=true;
     try{
       if(mode==='verify')await request('/auth/verify-email',{token});
       else await request('/auth/password/reset',{token,password:el.elements.password.value});
       status.textContent=mode==='verify'?'Email verified! Return to sign in.':'Password updated! Sign in with your new password.';
       el.hidden=true;
     }catch(e){status.textContent=e.message;btn.disabled=false}
   });
   return true;
 }
 function dialog(title,text,submitLabel,action){
   const container=document.getElementById('modalRoot');
   container.innerHTML='<div class="modal-overlay"><section class="modal" role="dialog" aria-modal="true" style="max-width:440px"><div class="modal-head"><h2>'+esc7(title)+'</h2><button type="button" class="xclose" id="p7Cancel" aria-label="Close">×</button></div><div class="modal-body"><p>'+esc7(text)+'</p><form id="p7Form"><label class="field"><span>Email address</span><input name="email" type="email" autocomplete="email" required maxlength="255"></label><p id="p7Status" role="status"></p><button class="btn primary full" type="submit">'+esc7(submitLabel)+'</button></form></div></section></div>';
   container.querySelector('#p7Cancel').onclick=()=>container.replaceChildren();
   container.querySelector('#p7Form').onsubmit=async e=>{
     e.preventDefault();const btn=e.target.querySelector('button[type=submit]'),status=document.getElementById('p7Status');btn.disabled=true;
     try{const result=await request(action,{email:e.target.elements.email.value});status.textContent=result.message||'Check your email for instructions.';e.target.reset()}
     catch(err){status.textContent=err.message;btn.disabled=false}
   };
 }
 window.phase7Forgot=()=>dialog('Reset your password','Enter your email address. If an eligible account exists, a reset link will be sent.','Send reset link','/auth/password/forgot');
 window.phase7Resend=()=>dialog('Resend verification','Enter the email address you used for Honestly Zen Event Planning signup.','Send verification link','/auth/verify-resend');

 const planLabel=n=>({free:'Starter',pro:'Pro',business:'Business',legacy:'Existing plan'})[n]||n;
 function renderBilling(){
   const b=state.billing||{limits:{},usage:{},plans:{}},owner=b.can_manage;
   const cycle=state.selectedLandingCycle==='yearly'?'yearly':'monthly';
   const selected=state.selectedLandingPlan;
   const totals=['events','guests','members'];
   return head('Subscription & usage','Manage your Honestly Zen Event Planning plan, billing settings and workspace resource limits.')+
    (selected&&selected!=='free'?'<section class="card pad phase7-plan-choice"><strong>Your selected plan: '+esc7(planLabel(selected))+'</strong><p class="small-note">Review your plan below. No upgrade or charge occurs until you explicitly complete checkout.</p></section>':'')+
    (state.billingReturn?'<section class="card pad m-top"><strong>'+(state.billingReturn==='return'?'Checkout return received':'Checkout cancelled')+'</strong><p class="small-note">'+(state.billingReturn==='return'?'Your subscription status updates only after Stripe sends a verified payment notification.':'Your plan has not changed.')+'</p></section>':'')+
    '<section class="card pad"><div class="billing-top"><div><p class="small-label">CURRENT PLAN</p><h2>'+esc7(planLabel(b.plan||'legacy'))+'</h2><p class="small-note">Status: '+esc7(b.status||'legacy')+'</p></div><div>'+
    (b.billing_enabled?'<span class="small-note">Provider billing available</span>':'<span class="small-note">Payments are not configured on this test service</span>')+'</div></div><div class="billing-usage">'+totals.map(k=>{
      const used=b.usage?.[k]||0,maximum=b.limits?.[k]||1,pct=Math.min(100,Math.round(100*used/maximum));
      return '<div><div class="attention-row"><span>'+esc7(k)+'</span><strong>'+used+' / '+maximum+'</strong></div><div class="registry-progress"><span style="width:'+pct+'%"></span></div></div>';
    }).join('')+'</div></section>'+
    '<section class="card pad m-top"><label for="billingCycleSelect" class="small-note">Billing period </label><select id="billingCycleSelect" class="select" onchange="state.selectedLandingCycle=this.value;render()"><option value="monthly" '+(cycle==='monthly'?'selected':'')+'>Monthly</option><option value="yearly" '+(cycle==='yearly'?'selected':'')+'>Yearly</option></select></section>'+
    '<div class="grid three-col m-top">'+Object.entries(b.plans||{}).map(([slug,p])=>
      '<div class="card pad"><h2>'+esc7(p.label)+'</h2><p class="small-note">'+p.max_events+' events · '+p.max_guests+' guests · '+p.max_members+' team members</p>'+
       (slug==='free'?'<span class="small-note">Starter access</span>':
         owner&&b.billing_enabled&&b.available_cycles?.[slug]?.[cycle]?'<button type="button" class="btn primary" onclick="phase7Checkout(\''+slug+'\')">Continue to '+esc7(p.label)+' checkout</button>':'<span class="small-note">Paid '+cycle+' checkout is not configured</span>')+'</div>').join('')+'</div>'+
    '<section class="card pad m-top"><h2>Subscription management</h2><p class="small-note">Plan changes and cancellations are controlled by the payment provider. Returning from checkout does not activate a plan until its signed webhook is processed.</p>'+
    (owner&&b.billing_enabled?'<button class="btn" onclick="phase7Portal()">Manage billing, invoices & cancellation</button>':'<p class="small-note">Online billing is not available yet.</p>')+'</section>';
 }
 window.phase7Checkout=async plan=>{
   if(!confirm('Continue to the secure payment provider to subscribe to '+plan+'?'))return;
   try{const d=await request('/w/'+state.ws.id+'/billing/checkout',{plan,billing_cycle:state.selectedLandingCycle||'monthly'});if(!d.checkout_url?.startsWith('https://'))throw Error('Invalid billing provider URL');location.assign(d.checkout_url)}
   catch(e){toast(e.message)}
 };
 window.phase7Portal=async()=>{
   try{const d=await request('/w/'+state.ws.id+'/billing/portal',{});if(!d.portal_url?.startsWith('https://'))throw Error('Invalid billing portal');location.assign(d.portal_url)}
   catch(e){toast(e.message)}
 };
 window.EventOSPhase7={renderAuthRoute,renderBilling};
})();