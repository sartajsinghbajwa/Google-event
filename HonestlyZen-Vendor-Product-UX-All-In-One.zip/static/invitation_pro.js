/* Honestly Zen Event Planning advanced canvas shortcuts. Avoid intercepting text input, preserves editor save flow. */
'use strict';
(function(){
  const editor=()=>window.EventOSCanvasEditor;
  const context=()=>window.EventOSCompactContext?.();
  function active(){return !!document.querySelector('#modalRoot .invitation-designer .invite-compact-tools')&&!!context()?.ctx?.canEdit}
  function targetInput(node){return !!node?.closest?.('input,textarea,select,[contenteditable="true"]')}
  function selected(){return editor()?.selectedInfo?.()}
  function transform(fn){
    const info=selected(),ctx=context();if(!info||!ctx)return false;
    const item=info.kind==='field'?info.field:info.item;
    editor().checkpoint();fn(item,info);ctx.ctx.preview();return true;
  }
  document.addEventListener('keydown',e=>{
    if(!active()||e.defaultPrevented||targetInput(e.target))return;
    const key=e.key.toLowerCase(),mod=e.ctrlKey||e.metaKey;
    if(mod&&key==='z'){e.preventDefault();if(e.shiftKey)editor().redo?.();else editor().undo?.();return}
    if(mod&&key==='y'){e.preventDefault();editor().redo?.();return}
    if(mod&&key==='d'){
      const info=selected(),c=context();
      if(info?.kind!=='item'||c.design.canvas_items.length>=40)return;
      editor().checkpoint();
      const copy={...info.item,id:crypto.randomUUID().replaceAll('-',''),x:Math.min(100,info.item.x+4),y:Math.min(100,info.item.y+4)};
      c.design.canvas_items.splice(info.index+1,0,copy);editor().select('item:'+copy.id);c.ctx.render();e.preventDefault();return;
    }
    if(e.key==='Delete'||e.key==='Backspace'){if(editor()?.deleteSelected?.()){e.preventDefault()}return}
    if(e.key==='Escape'){editor()?.select?.(null);return}
    const dir={'ArrowLeft':[-1,0],'ArrowRight':[1,0],'ArrowUp':[0,-1],'ArrowDown':[0,1]}[e.key];
    if(dir&&selected()){
      if(transform(x=>{const step=e.shiftKey?5:1;x.x=Math.max(0,Math.min(100,x.x+dir[0]*step));x.y=Math.max(0,Math.min(100,x.y+dir[1]*step))})){e.preventDefault()}return;
    }
    if((e.key==='['||e.key===']')&&selected()?.kind==='item'){
      if(transform(item=>{item.rotation=Math.max(-180,Math.min(180,(item.rotation||0)+(e.key==='['?-5:5)))}))e.preventDefault();
    }
  });
  window.EventOSInvitationShortcuts={help:'Ctrl/Cmd+Z undo · Ctrl/Cmd+Shift+Z redo · Ctrl/Cmd+D duplicate · Arrows move · Shift+Arrows move 5% · [ and ] rotate · Delete remove'};
})();