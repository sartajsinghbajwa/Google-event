/* Honestly Zen Event Planning public landing: provider-verified subscription prices, never invented amounts. */
'use strict';
(function(){
  const cards=document.getElementById('pricingCards');
  const toggle=document.getElementById('billingToggle');
  const menu=document.getElementById('mobileMenu');
  const menuButton=document.getElementById('mobileMenuButton');
  const year=document.getElementById('currentYear');
  if(year)year.textContent=String(new Date().getFullYear());
  const planCopy={
    free:{description:'For everyday moments, beautifully organized.',label:'Perfect for personal celebrations.',
      perks:['Digital invitations & RSVP','Guest management','Interactive seating planner','Event photo gallery','Gift registry & contribution pledges']},
    pro:{description:'For hosts who want more room to celebrate.',label:'More events and room to grow.',
      perks:['Everything in Starter','More guests and events','Collaborative team access','Advanced invitation editor','Reports and event operations']},
    business:{description:'For teams who make extraordinary events happen.',label:'Built for event planning organizations.',
      perks:['Everything in Pro','Multiple event workflows','Team roles & staff access codes','Client and vendor CRM','Admin-managed organization limits']}
  };
  const defaults=[
    {id:'free',label:'Starter',max_events:3,max_guests:120,max_members:2,available:true,prices:{monthly:null,yearly:null}},
    {id:'pro',label:'Pro',max_events:10,max_guests:1000,max_members:5,available:false,prices:{monthly:null,yearly:null}},
    {id:'business',label:'Business',max_events:60,max_guests:10000,max_members:25,available:false,prices:{monthly:null,yearly:null}}
  ];
  let published=defaults,cycle='monthly',backendAvailable=false;
  const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const plainNum=n=>new Intl.NumberFormat('en-CA').format(n||0);
  const planLink=(slug,period)=>'/app?mode=signup&plan='+encodeURIComponent(slug)+'&cycle='+encodeURIComponent(period)
    +'&workspace_type='+encodeURIComponent(slug==='business'?'business':'personal');
  function priceFor(plan){
    if(plan.id==='free')return {label:'Free',tail:'',note:'Personal starter plan'};
    const price=plan.prices?.[cycle];
    if(price&&Number.isInteger(price.amount_cents)&&typeof price.currency==='string'){
      const amount=new Intl.NumberFormat('en-CA',{style:'currency',currency:price.currency,
        minimumFractionDigits:price.amount_cents%100===0?0:2,maximumFractionDigits:2}).format(price.amount_cents/100);
      return {label:amount,tail:cycle==='yearly'?'/year':'/month',
        note:'Billed '+(cycle==='yearly'?'annually':'monthly')+' · '+price.currency};
    }
    return {label:'Coming soon',tail:'',note:'Online '+(cycle==='yearly'?'annual':'monthly')+' subscription not yet available'};
  }
  function card(plan){
    const copy=planCopy[plan.id]||planCopy.pro,pr=priceFor(plan);
    const isFree=plan.id==='free',isPro=plan.id==='pro';
    const currentAvailable=isFree||!!plan.prices?.[cycle];
    const cta=isFree?'Get started for free':currentAvailable?'Choose '+plan.label:'Start with Honestly Zen';
    const summary=isFree?'Includes '+plainNum(plan.max_events)+' events, '+plainNum(plan.max_guests)+' guests and '+plainNum(plan.max_members)+' team members.':
      currentAvailable?'Secure checkout opens after you create an account.':'Paid checkout is not configured for this billing period. You can still create an account.';
    return '<article class="price-card '+(isPro?'featured':'')+'">'+
      (isPro?'<span class="price-popular">FOR GROWING PLANS</span>':'')+
      '<div class="price-plan-name">'+escape(plan.label)+'</div>'+
      '<p class="price-description">'+escape(copy.description)+'</p>'+
      '<div class="price-number">'+escape(pr.label)+(pr.tail?'<small> '+escape(pr.tail)+'</small>':'')+'</div>'+
      '<span class="price-note">'+escape(pr.note)+'</span>'+
      '<a class="btn price-cta" href="'+planLink(plan.id,cycle)+'" aria-label="'+escape(cta)+' — '+escape(plan.label)+'">'+escape(cta)+' <span aria-hidden="true">↗</span></a>'+
      '<hr class="price-divider"><div class="price-includes">'+escape(copy.label)+'</div>'+
      '<ul class="price-features">'+
        ['Up to '+plainNum(plan.max_events)+' events',
         'Up to '+plainNum(plan.max_guests)+' guest records',
         'Up to '+plainNum(plan.max_members)+' team members',...copy.perks].map(x=>'<li>'+escape(x)+'</li>').join('')+
      '</ul><p class="price-summary" style="font-size:10px;line-height:1.65;margin:25px 0 0;color:inherit;opacity:.67">'+escape(summary)+'</p></article>';
  }
  function draw(){
    if(!cards)return;
    cards.innerHTML=published.map(card).join('');
    const note=document.getElementById('pricingNote');
    if(note)note.textContent=backendAvailable
      ?'Displayed subscription prices come from the configured payment provider. Checkout requires an account and confirmation. Gift-fund pledges are not payments.'
      :'Paid subscriptions are not activated on this preview. No payments will be collected. Gift-fund contributions are pledges, not purchases.';
  }
  async function load(){
    try{
      const response=await fetch('/api/public/plans',{cache:'no-store',headers:{'Accept':'application/json'}});
      if(!response.ok)throw Error('Plans unavailable');
      const json=await response.json();
      if(!Array.isArray(json.plans))throw Error('Plans unavailable');
      const valid=json.plans.filter(p=>p&&typeof p.id==='string'&&/^[a-z][a-z0-9_-]{1,30}$/.test(p.id)&&p.label&&Number.isInteger(p.max_events));
      if(!valid.length)throw Error('Plans unavailable');
      published=valid;
      backendAvailable=!!json.billing_enabled;
    }catch(e){published=defaults;backendAvailable=false}
    draw();
  }
  toggle?.addEventListener('click',()=>{
    const annual=toggle.getAttribute('aria-checked')!=='true';
    toggle.setAttribute('aria-checked',String(annual));cycle=annual?'yearly':'monthly';draw();
  });
  menuButton?.addEventListener('click',()=>{
    const isOpen=menuButton.getAttribute('aria-expanded')==='true';
    menuButton.setAttribute('aria-expanded',String(!isOpen));
    menu.hidden=isOpen;menuButton.setAttribute('aria-label',isOpen?'Open menu':'Close menu');
  });
  menu?.addEventListener('click',event=>{
    if(event.target.closest('a')){menu.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-label','Open menu')}
  });
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'&&!menu?.hidden){menu.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.focus()}
  });
  // Preserve old shared workspace, invite and recovery hash links to the SPA
  // after "/" becomes the public homepage.
  if(location.hash.startsWith('#/')){
    location.replace('/app'+location.search+location.hash);
    return;
  }
  if(cards)load();
})();