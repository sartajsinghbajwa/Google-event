/* Consent-based GA4 / Meta Pixel: IDs are public; never runs before opt-in. */
'use strict';
(function(){
let started=false, settings=null,lastPage='';
function getConsent(){try{return localStorage.getItem('eventos_analytics_consent')}catch(e){return null}}
function putConsent(v){try{localStorage.setItem('eventos_analytics_consent',v)}catch(e){}}
function script(src){const s=document.createElement('script');s.async=true;s.referrerPolicy='strict-origin-when-cross-origin';s.src=src;document.head.append(s)}
function track(){if(!started)return;const view=location.pathname==='/app'?((location.hash.split('/')[2]||'dashboard').replace(/[^a-zA-Z0-9_-]/g,'')):'',path=location.pathname+(view?'?view='+view:'');if(path===lastPage)return;lastPage=path;
 if(settings.ga4_id&&typeof window.gtag==='function')window.gtag('event','page_view',{page_path:path,page_title:document.title});
 if(settings.meta_pixel_id&&typeof window.fbq==='function')window.fbq('track','PageView');}
window.EventOSTrackEvent=function(name,params={}){if(!started||!['sign_up','generate_lead','view_item'].includes(name))return;
 const cleaned={};for(const key of ['content_type','currency','value'])if(Object.hasOwn(params,key))cleaned[key]=params[key];
 if(settings.ga4_id&&typeof window.gtag==='function')window.gtag('event',name,cleaned);
 if(settings.meta_pixel_id&&typeof window.fbq==='function'){if(name==='sign_up')window.fbq('track','CompleteRegistration');else if(name==='generate_lead')window.fbq('track','Lead');else if(name==='view_item')window.fbq('track','ViewContent')}
};
function run(){if(started||getConsent()!=='yes'||!settings)return;started=true;
 const ga=settings.ga4_id,pixel=settings.meta_pixel_id;
 if(/^G-[A-Z0-9]{5,20}$/.test(ga||'')){
  window.dataLayer=window.dataLayer||[];
  window.gtag=function(){window.dataLayer.push(arguments)};
  window.gtag('js',new Date());window.gtag('config',ga,{send_page_view:false,anonymize_ip:true});
  script('https://www.googletagmanager.com/gtag/js?id='+encodeURIComponent(ga));
 }
 if(/^[0-9]{8,25}$/.test(pixel||'')){
  if(!window.fbq){const fb=function(){fb.callMethod?fb.callMethod.apply(fb,arguments):fb.queue.push(arguments)};fb.queue=[];fb.loaded=true;fb.version='2.0';window.fbq=fb;}
  script('https://connect.facebook.net/en_US/fbevents.js');window.fbq('init',pixel);
 }
 track();
}
function banner(){if(getConsent()!==null)return;const el=document.createElement('div');el.id='eventos-consent';el.setAttribute('role','dialog');el.setAttribute('aria-label','Analytics cookie preferences');el.style.cssText='position:fixed;bottom:16px;left:16px;right:16px;max-width:650px;margin:auto;z-index:1000;background:#15394a;color:#fff;padding:16px;border-radius:14px;box-shadow:0 8px 35px #0004;font:14px system-ui;display:flex;flex-wrap:wrap;gap:12px;align-items:center';
 const msg=document.createElement('span');msg.style.flex='1 1 275px';msg.textContent='Optional analytics: allow Google Analytics and Meta Pixel to help us improve Honestly Zen Event Planning? You can decline and still use every feature.';el.append(msg);
 for(const [name,answer] of [['Decline','no'],['Allow analytics','yes']]){const b=document.createElement('button');b.textContent=name;b.type='button';b.style.cssText='border:1px solid #cce2de;border-radius:9px;padding:10px 13px;cursor:pointer;background:'+(answer==='yes'?'#13a18b':'#fff')+';color:'+(answer==='yes'?'#fff':'#183c4d');b.onclick=()=>{putConsent(answer);el.remove();if(answer==='yes')run()};el.append(b)}document.body.append(el)}
async function publicAlerts(){
 try{const r=await fetch('/api/growth/public-alerts');if(!r.ok)return;const rows=(await r.json()).items||[];if(!rows.length)return;
  const host=document.createElement('section');host.style.cssText='background:#fbf3de;color:#69471b;padding:12px 20px;display:grid;gap:7px;font:14px system-ui';
  rows.forEach(a=>{const p=document.createElement('p');p.style.margin='0';const strong=document.createElement('strong');strong.textContent=a.title+' — ';p.append(strong,document.createTextNode(a.body));host.append(p)});
  document.body.prepend(host);
 }catch(e){}
}
window.EventOSCookieSettings=function(){try{localStorage.removeItem('eventos_analytics_consent')}catch(e){}document.getElementById('eventos-consent')?.remove();banner()};
function privacyChoice(){if(document.getElementById('eventos-privacy-choice'))return;const b=document.createElement('button');b.id='eventos-privacy-choice';b.type='button';b.textContent='Privacy choices';b.setAttribute('aria-label','Change optional analytics consent');b.style.cssText='position:fixed;bottom:5px;right:6px;z-index:999;background:#fff;color:#37535e;border:1px solid #cfdcde;border-radius:5px;padding:5px;font:10px system-ui;cursor:pointer;opacity:.82';b.onclick=()=>{if(started){try{localStorage.removeItem('eventos_analytics_consent')}catch(e){}alert('Your preference has been reset. Reload to apply privacy choices; tracking already loaded in this tab cannot be unloaded.') ;location.reload()}else window.EventOSCookieSettings()};document.body.append(b)}
async function init(){publicAlerts();try{const resp=await fetch('/api/growth/public-settings',{credentials:'same-origin'});if(resp.ok)settings=await resp.json()}catch(e){}if(settings&&(settings.ga4_id||settings.meta_pixel_id)){banner();privacyChoice();run();setInterval(track,1500)}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
