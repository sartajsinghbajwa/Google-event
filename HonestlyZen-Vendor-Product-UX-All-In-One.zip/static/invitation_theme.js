/* Reusable safe invitation card markup for designer preview and guest RSVP links. */
'use strict';
(() => {
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const defaults = {template:'classic',accent_color:'#946e50',font:'serif',alignment:'center',headline:"You're invited",subtitle:'',host_line:'',closing_note:'We look forward to celebrating with you.',cover_image_url:'',show_date:true,show_location:true};
  function header(eventData, selected, name, media, urlPrefix) {
    const d = Object.assign({},defaults,selected||{});
    const template = ['classic','garden','modern','celebration'].includes(d.template) ? d.template : 'classic';
    const legacyFallback={
      'google:Playfair Display':'serif','google:Great Vibes':'script',
      'google:Montserrat':'sans','google:Poppins':'sans','google:Lora':'serif',
      'google:Dancing Script':'script','google:Pacifico':'script',
      'google:Cormorant Garamond':'serif','google:Libre Baskerville':'serif',
      'google:DM Sans':'sans'};
    const chosen=legacyFallback[d.font]||d.font;
    const font = ['serif','sans','script','display'].includes(chosen)?chosen:'serif';
    const guestPath=String(urlPrefix||'').match(/^(\/api\/rsvp\/[^/]+)\/media$/);
    const adminPath=String(urlPrefix||'').match(/^\/api\/w\/([^/]+)\/events\/[^/]+\/invitation-media$/);
    const assetsBase=guestPath?guestPath[1]+'/design-assets':adminPath?'/api/w/'+encodeURIComponent(adminPath[1])+'/design-assets':'';
    const isUpload=/^font:[0-9a-f-]{36}$/.test(chosen)&&!!assetsBase;
    const ident=isUpload?chosen.slice(5):'';
    const face=isUpload?'EventOS'+ident.replace(/-/g,''):'';
    const uploadedCss=isUpload?'font-family:&quot;'+face+'&quot;,Georgia,serif;':'';
    const definition=isUpload?'<style>@font-face{font-family:"'+face+'";src:url("'+assetsBase+'/'+encodeURIComponent(ident)+'");font-display:swap}</style>':'';
    const align = d.alignment==='left' ? 'left' : 'center';
    const accent = /^#[0-9a-fA-F]{6}$/.test(d.accent_color) ? d.accent_color : defaults.accent_color;
    const externalImage = typeof d.cover_image_url==='string' && /^https:\/\/[^\s<>'"]+$/i.test(d.cover_image_url) ? d.cover_image_url : '';
    const cover=media?.cover;
    const image=cover && urlPrefix ? urlPrefix+'/'+encodeURIComponent(cover.id) : externalImage;
    const date = d.show_date && eventData.start_date ? `<span>📅 ${esc(eventData.start_date)}</span>` : '';
    const venue = d.show_location && eventData.location ? `<span>📍 ${esc(eventData.location)}</span>` : '';
    return `${definition}<div class="invite-design invite-${template} invite-font-${isUpload?'custom':font} invite-align-${align}" style="--invite-accent:${accent};${uploadedCss}">
      <div class="invite-cover">${image?`<img src="${esc(image)}" alt="Event invitation cover" referrerpolicy="no-referrer" loading="lazy" onerror="this.style.display='none'">`:''}
      <div class="invite-cover-art" aria-hidden="true"><span>✦</span><span>✧</span><span>✦</span></div></div>
      <div class="invite-content" ${isUpload?'style="'+uploadedCss+'"':''}><div class="invite-kicker">THE CELEBRATION</div>
      ${d.host_line?`<p class="invite-host">${esc(d.host_line)}</p>`:''}
      <h1 ${isUpload?'style="'+uploadedCss+'"':''}>${esc(d.headline)}</h1><h2 ${isUpload?'style="'+uploadedCss+'"':''}>${esc(eventData.event_name||eventData.name||'Your event')}</h2>
      ${d.subtitle?`<p class="invite-subtitle">${esc(d.subtitle)}</p>`:''}
      ${date||venue?`<div class="invite-meta">${date}${venue}</div>`:''}
      ${name?`<div class="invite-salutation">Dear ${esc(name)},</div>`:''}
      ${d.closing_note?`<p class="invite-note">${esc(d.closing_note)}</p>`:''}
      </div></div>`;
  }
  function experience(eventData, selected, name, media, urlPrefix) {
    const d=Object.assign({},defaults,selected||{});
    const assets=media||{};
    const url=id=>urlPrefix+'/'+encodeURIComponent(id);
    const invite=assets.invite;
    let main='';
    if(d.mode==='upload' && invite) {
      main=`<section class="invite-uploaded"><div class="invite-uploaded-tag">PERSONAL INVITATION</div>
      ${invite.content_type==='application/pdf'?`<a class="invite-pdf-link" target="_blank" rel="noopener noreferrer" href="${esc(url(invite.id))}">📄 Open invitation PDF</a>`:
        `<img class="invite-uploaded-image" src="${esc(url(invite.id))}" alt="Uploaded invitation design" loading="lazy">`}
      <div class="invite-uploaded-meta"><h2>${esc(eventData.event_name||eventData.name||'Event')}</h2>${name?`<p>Prepared for ${esc(name)}</p>`:''}</div></section>`;
    } else if (d.mode==='canvas' && window.eventosInvitationCanvas) {
      main=window.eventosInvitationCanvas(eventData,d,name,assets,urlPrefix);
    } else {
      main=header(eventData,d,name,assets,urlPrefix);
    }
    const photos=(assets.photos||[]).map((pic,i)=>
      `<figure class="invite-gallery-item"><img loading="lazy" src="${esc(url(pic.id))}" alt="Event photo ${i+1}"><figcaption>${esc(pic.caption||'')}</figcaption></figure>`).join('');
    return main+(photos?`<section class="invite-photo-section"><h3>Moments &amp; memories</h3><div class="invite-gallery">${photos}</div></section>`:'');
  }
  window.eventosInvitationHeader=header;
  window.eventosInvitationExperience=experience;
})();
