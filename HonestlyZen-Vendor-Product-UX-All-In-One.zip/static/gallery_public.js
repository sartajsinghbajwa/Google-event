/* Honestly Zen Event Planning guest photo gallery — auto-updating approved photos and moderated uploads. */
'use strict';
(function(){
 const token=location.pathname.split('/').pop();
 const root=document.getElementById('experienceRoot');
 const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let lastKey='',data=null,working=false;
 const endpoint='/api/gallery/'+encodeURIComponent(token);
 const image=(p,size='thumb')=>endpoint+'/photos/'+encodeURIComponent(p.id)+'/'+size;
 async function request(url,opt={}){
  const r=await fetch(url,{...opt,cache:'no-store'});
  let result;try{result=await r.json()}catch{result={}};
  if(!r.ok)throw Error(result.detail||'Gallery unavailable');
  return result;
 }
 function render(data){
  const photos=data.photos||[];
  root.innerHTML='<header class="experience-hero"><div class="experience-mark">✦ EVENT MEMORIES</div><h1>'+h(data.title)+'</h1><p class="experience-hero-sub">'+h(data.event_name)+'</p>'+
  '<div class="experience-hero-count"><strong>'+photos.length+'</strong> shared memories</div></header>'+
  (data.allow_uploads?'<section class="experience-guest-uploader"><div><h2>Share your favorite moments</h2><p>Choose a photo from your phone or camera. '+(data.approval_required?'The host will review it before it appears here.':'Approved photos appear in the gallery shortly.')+'</p></div>'+
  '<form id="guestPhotoForm"><label>Your name (optional)<input name="submitted_by" maxlength="70" placeholder="Your name"></label>'+
  '<label>Photo caption (optional)<input name="caption" maxlength="200" placeholder="A special moment…"></label>'+
  '<label class="experience-file">Choose or take a photo<input name="photo" type="file" accept="image/jpeg,image/png,image/webp" required></label>'+
  '<button class="experience-primary" type="submit">Upload photo</button></form><p class="experience-feedback" id="guestPhotoStatus" role="status"></p></section>':'')+
  '<section class="experience-public-gallery"><div class="experience-public-head"><h2>Moments from the celebration</h2><span>Updates automatically</span></div>'+
  '<div class="experience-public-grid">'+photos.map(p=>'<button type="button" class="experience-public-photo" data-photo="'+h(p.id)+'" aria-label="Enlarge photo"><img loading="lazy" alt="'+h(p.caption||'Event photo')+'" src="'+image(p)+'"><span class="experience-photo-caption">'+h(p.caption||'')+(p.submitted_by?' · '+h(p.submitted_by):'')+'</span></button>').join('')+'</div>'+
  (!photos.length?'<p class="experience-empty">No published photos yet. This gallery will update as memories are shared.</p>':'')+
  '</section><footer class="experience-footer">Made with Honestly Zen Event Planning · Photos shared by event participants</footer>';
 }
 async function load(force=false){
  if(working)return;working=true;
  try{
   const next=await request(endpoint);
   const key=JSON.stringify(next.photos)+String(next.allow_uploads)+next.title;
   // Avoid replacing the upload form in the middle of a submission or while a user types.
   if((force||key!==lastKey)&&!document.activeElement?.closest?.('#guestPhotoForm')){
    data=next;lastKey=key;render(next);
   }
  }catch(e){if(!data){root.innerHTML='<section class="experience-error"><h1>Gallery unavailable</h1><p>'+h(e.message)+'</p></section>'}}
  finally{working=false}
 }
 root.addEventListener('submit',async ev=>{
  if(ev.target.id!=='guestPhotoForm')return;ev.preventDefault();
  const form=ev.target,button=form.querySelector('button[type=submit]'),file=form.querySelector('[name=photo]')?.files[0],info=form.querySelector('#guestPhotoStatus')||root.querySelector('#guestPhotoStatus');
  if(!file)return;
  if(file.size>8*1024*1024){info.textContent='Please choose an image smaller than 8 MB.';return}
  button.disabled=true;button.textContent='Uploading…';
  try{
   const raw=new Uint8Array(await file.arrayBuffer()),chunks=[];
   for(let i=0;i<raw.length;i+=32768)chunks.push(String.fromCharCode(...raw.subarray(i,i+32768)));
   const payload={filename:file.name,content_type:file.type,
     data_base64:btoa(chunks.join('')),submitted_by:form.elements.submitted_by.value,
     caption:form.elements.caption.value};
   const result=await request(endpoint+'/photos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
   info.textContent=result.status==='pending'?'Photo received! It will appear once the host approves it.':'Photo uploaded successfully!';
   form.reset();lastKey='';setTimeout(()=>load(true),1200);
  }catch(e){info.textContent=e.message}
  finally{button.disabled=false;button.textContent='Upload photo'}
 });
 root.addEventListener('click',ev=>{
  const button=ev.target.closest('[data-photo]');if(!button)return;
  const photo=(data?.photos||[]).find(p=>p.id===button.dataset.photo);
  if(!photo)return;
  const backdrop=document.createElement('div');backdrop.className='experience-lightbox';backdrop.setAttribute('role','dialog');backdrop.setAttribute('aria-modal','true');
  const imageEl=document.createElement('img');imageEl.src=image(photo,'full');imageEl.alt=photo.caption||'Event photo';
  const close=document.createElement('button');close.textContent='× Close';close.onclick=()=>backdrop.remove();
  backdrop.append(close,imageEl);backdrop.onclick=e=>{if(e.target===backdrop)backdrop.remove()};
  document.body.append(backdrop);close.focus();
 });
 setInterval(()=>{if(!document.hidden)load()},12000);
 load(true);
})();
