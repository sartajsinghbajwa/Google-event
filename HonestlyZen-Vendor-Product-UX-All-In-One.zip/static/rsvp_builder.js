/* Honestly Zen Event Planning RSVP form builder: per-event editor, preview, and organizer response viewer. */
'use strict';
(() => {
  const TYPES = {
    short_text:'Short text', paragraph:'Paragraph', single_choice:'Single choice',
    multiple_choice:'Multiple choice', number:'Number', date:'Date', yes_no:'Yes / No'
  };
  let form = null, tab = 'edit', responses = [], templates = [], busy = false;
  const attendanceDefaults = {question:'Will you attend?',confirmed:'Joyfully accepts',maybe:'Maybe',declined:'Regretfully declines'};
  const partyDefaults = {enabled:true,allow_plus_one:true,ask_adults_kids:true,names_optional:true,meals_optional:true,meal_options:['Vegetarian','Non-vegetarian','Vegan','Kids meal']};
  const copy = value => JSON.parse(JSON.stringify(value));
  const prepare = value => ({...value, attendance:{...attendanceDefaults,...value.attendance},
    party:{...partyDefaults,...value.party}});
  const templatePath = () => evpath().split('/events/')[0]+'/rsvp-templates';
  const downloadJson = (filename,data) => {
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  const root = () => document.querySelector('#modalRoot');
  const html = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const newId = () => (crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : Math.random().toString(36).slice(2));
  const questionPreview = q => {
    const input = {
      short_text:`<input placeholder="Your answer" disabled>`, paragraph:`<textarea placeholder="Your answer" disabled></textarea>`,
      number:`<input type="number" placeholder="0" disabled>`, date:`<input type="date" disabled>`,
      yes_no:`<select disabled><option>Choose one</option><option>Yes</option><option>No</option></select>`,
      single_choice:`<div class="rsvp-check-options">${q.options.map(o=>`<label><input type="radio" disabled> ${html(o)}</label>`).join('')}</div>`,
      multiple_choice:`<div class="rsvp-check-options">${q.options.map(o=>`<label><input type="checkbox" disabled> ${html(o)}</label>`).join('')}</div>`
    }[q.type];
    return `<div class="field rsvp-preview-field"><span>${html(q.label)}${q.required?' *':''}</span>${q.show_when&&q.show_when!=='always'?'<small>Shown when RSVP is '+html(q.show_when)+'</small>':''}${q.help_text?`<small>${html(q.help_text)}</small>`:''}${input}</div>`;
  };
  const qEditor = (q, i) => `<section class="rsvp-question" data-index="${i}">
    <div class="rsvp-question-head"><strong>Question ${i+1}</strong><div class="rsvp-question-actions">
      <button class="btn tiny" type="button" data-action="up" data-index="${i}" ${i===0?'disabled':''} aria-label="Move question up">↑</button>
      <button class="btn tiny" type="button" data-action="down" data-index="${i}" ${i===form.questions.length-1?'disabled':''} aria-label="Move question down">↓</button>
      <button class="btn tiny danger" type="button" data-action="remove" data-index="${i}">Remove</button></div></div>
    <div class="inline-fields"><label class="field"><span>Question label</span><input data-index="${i}" data-field="label" value="${html(q.label)}" maxlength="180" required></label>
      <label class="field"><span>Answer type</span><select data-index="${i}" data-field="type">${Object.entries(TYPES).map(([k,v])=>`<option value="${k}" ${q.type===k?'selected':''}>${v}</option>`).join('')}</select></label>
      <label class="field wide"><span>Help text (optional)</span><input data-index="${i}" data-field="help_text" value="${html(q.help_text)}" maxlength="350"></label>
      ${['single_choice','multiple_choice'].includes(q.type)?`<label class="field wide"><span>Choices — one per line (2–15)</span><textarea data-index="${i}" data-field="options" rows="4">${html(q.options.join('\n'))}</textarea></label>`:''}
      <label class="field"><span>Show this question when</span><select data-index="${i}" data-field="show_when">${[['always','Any RSVP response'],['Confirmed','Attending'],['Maybe','Maybe'],['Declined','Declined']].map(([v,n])=>`<option value="${v}" ${(q.show_when||'always')===v?'selected':''}>${n}</option>`).join('')}</select></label>
      <label class="rsvp-check-label"><input type="checkbox" data-index="${i}" data-field="required" ${q.required?'checked':''}> Required answer when visible</label>
    </div></section>`;
  function render() {
    if (!form) return;
    root().innerHTML = `<div class="modal-overlay rsvp-builder-overlay" role="presentation"><section class="modal rsvp-builder" role="dialog" aria-modal="true" aria-labelledby="rsvp-builder-heading">
      <header class="modal-head"><div><h2 id="rsvp-builder-heading">RSVP Form Builder</h2><p class="tiny-note">${html(state.event?.name || 'Your event')}</p></div><button class="xclose" type="button" data-action="close" aria-label="Close">×</button></header>
      <div class="rsvp-builder-tabs">${[['edit','Edit form'],['preview','Guest preview'],['responses','Saved answers']].map(([k,v])=>`<button type="button" data-action="tab" data-tab="${k}" class="${tab===k?'active':''}">${v}</button>`).join('')}</div>
      <div class="modal-body rsvp-builder-content">${tab==='edit'?`
        <div class="inline-fields"><label class="field wide"><span>Form title</span><input data-setting="title" value="${html(form.title)}" maxlength="160"></label>
        <label class="field wide"><span>Welcome message</span><textarea data-setting="intro" rows="3" maxlength="1500">${html(form.intro)}</textarea></label>
        <label class="field"><span>RSVP deadline (optional)</span><input data-setting="deadline" type="date" value="${html(form.deadline)}"></label>
        <label class="rsvp-check-label"><input data-setting="published" type="checkbox" ${form.published?'checked':''}> Accept guest responses</label></div>
        <section class="rsvp-question"><h3>Start with an RSVP template</h3>
          <div class="inline-fields"><label class="field wide"><span>Choose a built-in or saved template</span><select id="rsvpTemplateSelect"><option value="">Choose a template…</option>
            ${templates.map(t=>`<option value="${html(t.id)}">${t.built_in?'Ready-made: ':'My template: '}${html(t.name)}</option>`).join('')}</select></label></div>
          <div class="rsvp-template-actions"><button class="btn" type="button" data-action="use-template">Use template</button>
            <button class="btn" type="button" data-action="save-template">Save as template</button>
            <button class="btn" type="button" data-action="export-template">Export JSON</button>
            <button class="btn" type="button" data-action="import-template">Import JSON</button>
            <button class="btn tiny danger" type="button" data-action="delete-template">Delete saved template</button></div>
          <input id="rsvpImportFile" type="file" accept=".json,application/json" hidden>
          <p class="tiny-note">Using a template updates this editor only until you save. Export and import JSON to reuse templates in other Honestly Zen Event Planning workspaces.</p>
        </section>
        <section class="rsvp-question"><h3>Attendance question & answers</h3>
          <div class="inline-fields">
            <label class="field wide"><span>Attendance question</span><input data-attendance="question" maxlength="140" value="${html(form.attendance.question)}"></label>
            <label class="field"><span>Attending option</span><input data-attendance="confirmed" maxlength="140" value="${html(form.attendance.confirmed)}"></label>
            <label class="field"><span>Maybe option</span><input data-attendance="maybe" maxlength="140" value="${html(form.attendance.maybe)}"></label>
            <label class="field"><span>Declining option</span><input data-attendance="declined" maxlength="140" value="${html(form.attendance.declined)}"></label>
          </div><p class="tiny-note">Change any wording. Honestly Zen Event Planning still tracks attending, maybe and declined.</p></section>
        <section class="rsvp-question"><h3>Guest counts, plus-one & meals</h3>
          <div class="inline-fields">
            ${[['enabled','Ask how many guests are attending'],['allow_plus_one','Offer an optional plus-one'],['ask_adults_kids','Ask adults and kids separately'],['names_optional','Allow optional guest names'],['meals_optional','Allow optional meal preferences']].map(([key,label])=>`<label class="rsvp-check-label"><input type="checkbox" data-party="${key}" ${form.party[key]?'checked':''}> ${label}</label>`).join('')}
            <label class="field wide"><span>Meal choices — one per line</span><textarea data-party="meal_options" rows="4">${html(form.party.meal_options.join('\n'))}</textarea></label>
          </div><p class="tiny-note">Every invitation limits responses to reserved seats, plus one extra if enabled. Guest names and meals are optional.</p></section>
        <div class="rsvp-section-heading"><h3>Custom questions (${form.questions.length}/30)</h3><button class="btn" type="button" data-action="add" ${form.questions.length>=30?'disabled':''}>+ Add question</button></div>
        ${form.questions.length?form.questions.map(qEditor).join(''):'<p class="muted">Add questions about meals, dietary needs, transportation, song requests, and more.</p>'}
      `:tab==='preview'?`<div class="rsvp-preview"><div class="eyebrow">GUEST PREVIEW</div><h2>${html(form.title)}</h2><p class="muted">${html(form.intro)}</p>${form.deadline?`<p class="tiny-note">Please reply by ${html(form.deadline)}</p>`:''}<div class="field"><span>${html(form.attendance.question)} *</span><select disabled><option>Choose one</option><option>${html(form.attendance.confirmed)}</option><option>${html(form.attendance.maybe)}</option><option>${html(form.attendance.declined)}</option></select></div>${form.party.enabled?`<div class="rsvp-question"><strong>Guests attending</strong><p class="tiny-note">Adults, children, optional plus-one${form.party.names_optional?', guest names':''}${form.party.meals_optional?', and meal preferences':''} appear here for invited guests.</p></div>`:''}${form.questions.map(questionPreview).join('')}<button type="button" class="btn primary full" disabled>Save my RSVP</button><p class="tiny-note">Preview only — no responses will be submitted.</p></div>`:
        `<div class="rsvp-responses"><button class="btn primary" type="button" data-action="export-excel">Download Excel (.xlsx)</button>${responses.length?responses.map(r=>`<section class="rsvp-response-card"><strong>${html(r.guest_name)}</strong> · ${html(r.rsvp)}<div class="tiny-note">Submitted ${html(r.submitted_at||'')}</div>${r.party?.total?`<p>Attending: ${r.party.total} · Adults: ${r.party.adults} · Kids: ${r.party.kids} · Plus-one: ${r.party.plus_one?'Yes':'No'}</p><p>${(r.party.guests||[]).map(g=>[g.name,g.meal].filter(Boolean).map(html).join(' — ')).filter(Boolean).join('; ')}</p>`:''}${Object.entries(r.answers).map(([id,val])=>`<p><strong>${html(form.questions.find(q=>q.id===id)?.label||'Removed question')}:</strong> ${html(Array.isArray(val)?val.join(', '):typeof val==='boolean'?(val?'Yes':'No'):val)}</p>`).join('')||'<p class="muted">No custom answers.</p>'}</section>`).join(''):'<p class="muted">No guest form submissions yet. Answers appear here after a guest submits their RSVP.</p>'}</div>`}
      </div><footer class="rsvp-builder-footer"><button type="button" class="btn" data-action="close">Close</button>${tab==='edit'?`<button type="button" data-action="save" class="btn primary" ${busy?'disabled':''}>${busy?'Saving…':'Save RSVP form'}</button>`:''}</footer>
    </section></div>`;
    root().querySelectorAll('[data-setting],[data-field],[data-attendance],[data-party]').forEach(node => {
      const change = () => {
        const value = node.type==='checkbox'?node.checked:node.value;
        if (node.dataset.setting) form[node.dataset.setting] = value;
        else if (node.dataset.attendance) form.attendance[node.dataset.attendance] = value;
        else if (node.dataset.party) form.party[node.dataset.party] = node.dataset.party==='meal_options' ? String(value).split(/\r?\n/).map(v=>v.trim()).filter(Boolean) : value;
        else {
          const q = form.questions[Number(node.dataset.index)];
          if (node.dataset.field==='options') q.options = String(value).split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
          else q[node.dataset.field] = value;
          if (node.dataset.field==='type') { if (['single_choice','multiple_choice'].includes(value) && q.options.length<2) q.options=['Option 1','Option 2']; else if (!['single_choice','multiple_choice'].includes(value)) q.options=[]; render(); }
        }
      };
      node.addEventListener('input', change);
      if (node.tagName==='SELECT' || node.type==='checkbox') node.addEventListener('change', change);
    });
  }
  async function open(selected='edit') {
    try {
      form=prepare(await api(evpath()+'/rsvp-form'));tab=selected;responses=[];
      try{templates=await api(templatePath())}catch(err){templates=[];toast('Could not load templates: '+err.message)}
      if (tab==='responses') responses=await api(evpath()+'/rsvp-responses');
      render();
    } catch(e) { toast(e.message); }
  }
  root()?.addEventListener('click', async e => {
    const b=e.target.closest('[data-action]');if(!b || !form)return;
    const action=b.dataset.action, i=Number(b.dataset.index);
    if (action==='use-template'){
      const id=root().querySelector('#rsvpTemplateSelect')?.value, chosen=templates.find(t=>t.id===id);
      if(!chosen){toast('Choose a template first');return}
      if(form.questions.length && !confirm('Replace the current form with this template?'))return;
      form=prepare(copy(chosen.form));tab='edit';render();toast('Template loaded — save your form to apply');return;
    }
    if (action==='save-template'){
      const name=prompt('Name for this reusable RSVP template',form.title);
      if(!name)return;
      try{const t=await api(templatePath(),{method:'POST',body:{name,form}});templates.push(t);render();toast('Template saved')}catch(err){toast(err.message)}return;
    }
    if (action==='export-template'){downloadJson('eventos-rsvp-template.json',{version:1,name:form.title,form});toast('Template downloaded');return}
    if (action==='import-template'){root().querySelector('#rsvpImportFile')?.click();return}
    if (action==='delete-template'){
      const id=root().querySelector('#rsvpTemplateSelect')?.value, t=templates.find(x=>x.id===id);
      if(!t||t.built_in){toast('Choose one of your saved templates');return}
      if(!confirm('Delete template "'+t.name+'"?'))return;
      try{await api(templatePath()+'/'+encodeURIComponent(t.id),{method:'DELETE'});templates=templates.filter(x=>x.id!==id);render();toast('Template deleted')}catch(err){toast(err.message)}return;
    }
    if (action==='export-excel'){location.href='/api'+evpath()+'/rsvp-responses.xlsx';return}    if (action==='close'){form=null;root().innerHTML='';return}
    if (action==='add'){form.questions.push({id:newId(),label:'New question',type:'short_text',required:false,help_text:'',options:[],show_when:'always'});render();return}
    if (action==='remove'){form.questions.splice(i,1);render();return}
    if (action==='up' && i>0){[form.questions[i-1],form.questions[i]]=[form.questions[i],form.questions[i-1]];render();return}
    if (action==='down' && i<form.questions.length-1){[form.questions[i+1],form.questions[i]]=[form.questions[i],form.questions[i+1]];render();return}
    if (action==='tab'){tab=b.dataset.tab;if(tab==='responses'){try{responses=await api(evpath()+'/rsvp-responses')}catch(err){toast(err.message);return}}render();return}
    if (action==='save' && !busy){busy=true;render();try{form=await api(evpath()+'/rsvp-form',{method:'PUT',body:form});toast('RSVP form saved');tab='preview'}catch(err){toast(err.message);tab='edit'}finally{busy=false;render()}}
  });
  root()?.addEventListener('change',async e=>{
    if(e.target.id!=='rsvpImportFile')return;
    const file=e.target.files?.[0];if(!file)return;
    try{
      if(file.size>65536)throw Error('Template file must be smaller than 64 KB');
      const data=JSON.parse(await file.text());
      if(data.version!==1||typeof data.name!=='string'||!data.form||typeof data.form!=='object')throw Error('Invalid Honestly Zen Event Planning template format');
      const template=await api(templatePath(),{method:'POST',body:{name:data.name,form:data.form}});
      templates.push(template);render();toast('Template imported and saved. Choose it to apply.');
    }catch(err){toast('Import failed: '+err.message)}
  });  window.openRSVPBuilder=open;
  window.viewRSVPAnswers=()=>open('responses');
})();
