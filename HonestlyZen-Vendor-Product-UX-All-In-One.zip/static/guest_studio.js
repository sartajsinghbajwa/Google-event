/* Honestly Zen Event Planning Phase 11 organizer Guest Experience Studio, rendered inside Event Operations. */
'use strict';
(function(){
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const d=()=>state.guestExperience||null;
 const canEdit=()=>Boolean(d()?.can_edit);
 const base=()=>evpath()+'/guest-experience';
 const action=(caption,id,attrs='')=>'<button type="button" class="btn tiny" data-ge-action="'+id+'" '+attrs+'>'+esc(caption)+'</button>';
 function sectionHeader(title,note){
  return '<div class="section-title"><div><h2>'+esc(title)+'</h2><p class="small-note">'+esc(note)+'</p></div></div>';
 }
 function render(){
  const data=d();
  if(!data)return '<section class="card pad"><p>Loading the guest experience studio…</p></section>';
  const guests=state.operations?.guests||[];
  const editor=data.can_edit;
  const count=guests.filter(x=>x.rsvp==='Confirmed').length;
  return '<section class="guest-studio">'+
   '<div class="grid two-col"><article class="card pad">'+
   sectionHeader('Guest passes','Each invitation has its own secure, mobile-friendly QR pass and seating map.')+
   '<div class="attention-row"><span>Confirmed invitation groups</span><strong>'+count+'</strong></div>'+
   '<div class="guest-studio-people">'+guests.slice(0,75).map(g=>
     '<div class="guest-studio-person"><div><strong>'+esc(g.name)+'</strong><p class="tiny-note">'+esc(g.table_name||'Table not assigned')+' · '+esc(g.rsvp)+'</p></div>'+
     action('Copy pass link','pass','data-token="'+esc(g.invitation_token)+'"')+'</div>').join('')+'</div>'+
   '<p class="small-note">Personal links are private. Do not post individual pass links publicly.</p></article>'+
   '<article class="card pad">'+sectionHeader('Guest seat finder','Optional welcome-desk lookup: secret QR link plus a separate numeric PIN.')+
   '<div class="attention-row"><span>Venue finder</span><strong>'+(data.finder_enabled?'Enabled':'Disabled')+'</strong></div>'+
   '<div class="attention-row"><span>Access PIN set</span><strong>'+(data.finder_pin_set?'Yes':'Not yet')+'</strong></div>'+
   (editor?'<div class="guest-studio-actions">'+
       action(data.finder_enabled?'Disable finder':'Enable finder','toggle','data-enabled="'+String(!data.finder_enabled)+'"')+
       action('Set PIN and rotate QR','pin')+'</div>':'')+
   (data.finder_enabled?'<div class="guest-studio-actions">'+
       action('Copy venue finder URL','finder-copy')+action('Show venue QR sign','finder-qr')+
       '<a class="btn tiny" href="/api'+base()+'/finder-sign.pdf" download>Download A4 QR poster</a>'+
       '</div><p class="small-note">Print the QR sign at the venue, and share the PIN separately. Guests must enter their exact invitation name. No full guest list is displayed.</p>':'')+
   '</article></div>'+
   '<article class="card pad m-top">'+sectionHeader('Guest-visible event itinerary',
      'Publish only the program items guests should see, not the internal operations schedule.')+
   (editor?'<form class="guest-studio-form" data-ge-form="itinerary"><label>Program item<input name="title" required maxlength="120" placeholder="Ceremony / Dinner / First dance"></label>'+
     '<label>Date & time (event local)<input type="datetime-local" name="start_at" required></label>'+
     '<label>Location<input name="location" maxlength="160" placeholder="Main hall"></label>'+
     '<label class="guest-studio-wide">Description<textarea name="description" maxlength="600" rows="2" placeholder="Helpful details"></textarea></label>'+
     '<label class="guest-studio-check"><input type="checkbox" name="published" checked> Publish to guests</label>'+
     '<button class="btn primary" type="submit">Add event program item</button></form>':'')+
   (data.itinerary.length?data.itinerary.map(x=>
       '<div class="guest-studio-row"><div><strong>'+esc(x.title)+'</strong><div class="tiny-note">'+esc(x.start_at.replace('T',' · '))+' · '+esc(x.location)+'</div>'+
       (x.description?'<p class="small-note">'+esc(x.description)+'</p>':'')+'</div><div class="guest-studio-actions">'+
       '<span class="badge '+(x.published?'good':'')+'">'+(x.published?'Published':'Draft')+'</span>'+
       (editor?action(x.published?'Unpublish':'Publish','publish','data-type="itinerary" data-id="'+esc(x.id)+'" data-state="'+String(!x.published)+'"')+
         action('Delete','delete','data-type="itinerary" data-id="'+esc(x.id)+'"'):'')+
       '</div></div>').join(''):'<p class="small-note">No guest program entries yet.</p>')+'</article>'+
   '<article class="card pad m-top">'+sectionHeader('Event-day updates',
      'Published notices appear when guests refresh their private hub. Email or push delivery is not automatic.')+
   '<p class="small-note">Need to send an email or WhatsApp update? Use Event Operations messaging to select guests and prepare a direct announcement.</p>'+
   action('Open guest messaging','messages')+
   (editor?'<form class="guest-studio-form" data-ge-form="updates"><label>Announcement title<input name="title" required maxlength="120" placeholder="Parking update"></label>'+
     '<label>Type<select name="category"><option value="info">General</option><option value="important">Important</option><option value="transport">Travel & parking</option></select></label>'+
     '<label class="guest-studio-wide">Message<textarea name="body" required maxlength="1000" rows="3" placeholder="What guests should know…"></textarea></label>'+
     '<label class="guest-studio-check"><input type="checkbox" name="published" checked> Publish now</label>'+
     '<button class="btn primary" type="submit">Post announcement</button></form>':'')+
   (data.updates.length?data.updates.map(x=>
       '<div class="guest-studio-row"><div><strong>'+esc(x.title)+'</strong><p class="tiny-note">'+esc(x.category)+' · '+esc(x.created_at?.slice(0,16)||'')+'</p>'+
       '<p class="small-note">'+esc(x.body)+'</p></div><div class="guest-studio-actions">'+
       '<span class="badge '+(x.published?'good':'')+'">'+(x.published?'Published':'Draft')+'</span>'+
       (editor?action(x.published?'Unpublish':'Publish','publish','data-type="updates" data-id="'+esc(x.id)+'" data-state="'+String(!x.published)+'"')+
         action('Delete','delete','data-type="updates" data-id="'+esc(x.id)+'"'):'')+
       '</div></div>').join(''):'<p class="small-note">No updates yet.</p>')+'</article></section>';
 }
 async function load(){
  try{state.guestExperience=await api(base());window.render()}
  catch(e){toast(e.message);window.render()}
 }
 async function update(work,message){
  try{await work();await load();if(message)toast(message)}
  catch(e){toast(e.message)}
 }
 async function copy(text){
  try{await navigator.clipboard.writeText(text);toast('Link copied')}
  catch(e){window.prompt('Copy this link:',text)}
 }
 document.addEventListener('click',e=>{
  const element=e.target.closest('[data-ge-action]');
  if(!element||state.page!=='operations'||state.opsTab!=='guest')return;
  const mode=element.dataset.geAction;
  if(mode==='messages'){window.opsTab('messages');return}
  if(mode==='pass'){
    const token=element.dataset.token;
    if(token)copy(location.origin+'/guest/'+encodeURIComponent(token));
  }
  if(mode==='toggle'){
    const enabled=element.dataset.enabled==='true';
    if(!enabled&&!confirm('Disable the venue name finder?'))return;
    if(enabled&&!d().finder_pin_set){document.querySelector('[data-ge-action="pin"]')?.click();return}
    update(()=>api(base()+'/finder',{method:'PUT',body:{enabled}}),
       enabled?'Seat finder enabled':'Seat finder disabled');
  }
  if(mode==='pin'){
    const pin=window.prompt('New 6–12 digit numeric venue PIN. Share this separately from the QR sign.');
    if(pin===null)return;
    if(!/^[0-9]{6,12}$/.test(pin)){toast('Enter 6–12 digits');return}
    if(!confirm('Change PIN and rotate finder URL? Previously printed QR signs will stop working.'))return;
    update(()=>api(base()+'/finder',{method:'PUT',body:{enabled:true,pin,rotate:true}}),
           'New PIN saved. Download a new QR sign.');
  }
  if(mode==='finder-copy'&&d()?.finder_url)copy(location.origin+d().finder_url);
  if(mode==='finder-qr')window.open('/api'+base()+'/finder-qr.png','_blank','noopener,noreferrer');
  if(mode==='publish'){
    const kind=element.dataset.type,id=element.dataset.id,published=element.dataset.state==='true';
    if(['updates','itinerary'].includes(kind))update(()=>api(base()+'/'+kind+'/'+encodeURIComponent(id),
           {method:'PATCH',body:{published}}),'Publication updated');
  }
  if(mode==='delete'){
    if(!confirm('Delete this guest-facing item?'))return;
    const kind=element.dataset.type,id=element.dataset.id;
    if(['updates','itinerary'].includes(kind))update(()=>api(base()+'/'+kind+'/'+encodeURIComponent(id),
           {method:'DELETE'}),'Item deleted');
  }
 });
 document.addEventListener('submit',e=>{
  const form=e.target.closest('[data-ge-form]');
  if(!form||state.page!=='operations'||state.opsTab!=='guest')return;
  e.preventDefault();
  if(!canEdit())return;
  const kind=form.dataset.geForm;
  if(kind!=='itinerary'&&kind!=='updates')return;
  const values=Object.fromEntries(new FormData(form));
  values.published=!!form.querySelector('[name="published"]')?.checked;
  update(()=>api(base()+'/'+kind,{method:'POST',body:values}),kind==='itinerary'?'Program item saved':'Announcement saved');
 });
 window.EventOSGuestStudio={render,load};
})();