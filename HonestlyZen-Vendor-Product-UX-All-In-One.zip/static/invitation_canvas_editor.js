'use strict';
(() => {
  let current=null,callbacks=null,selected=null,tool='clipart',category='All',showGuides=true;
  const history=[],redoHistory=[],editingInputs=new WeakSet();
  function checkpoint(){
    if(!current)return;
    const snapshot=JSON.stringify(current);
    if(history[history.length-1]!==snapshot){history.push(snapshot);if(history.length>60)history.shift()}
    redoHistory.length=0;
    window.EventOSCompactHistoryChanged?.();
  }
  function restore(from,to){
    if(!from.length||!current)return false;
    to.push(JSON.stringify(current));
    const data=JSON.parse(from.pop());
    for(const key of Object.keys(current))delete current[key];
    Object.assign(current,data);selected=null;callbacks.render();return true;
  }
  const esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const clamp=(n,low,high)=>Math.min(high,Math.max(low,n));
  const names={host_line:'Hosted by',headline:'Invitation headline',title:'Couple / event names',
    subtitle:'Invitation details',date:'Date',location:'Location',closing_note:'Closing message'};
  const fieldNames={host_line:'host_line',headline:'headline',title:'canvas_title',
    subtitle:'subtitle',date:'canvas_date',location:'canvas_location',closing_note:'closing_note'};
  const wordLimit={host_line:160,headline:120,title:160,subtitle:240,date:120,location:160,closing_note:350};
  const colors=['ivory','blush','sage','champagne','midnight','parchment'];
  const categories=['All','Flowers','Borders','Symbols','Cultural','Other'];
  const artCategories={rose:'Flowers',leaf:'Flowers',bouquet:'Flowers',flourish:'Borders',mandala:'Borders',rings:'Symbols',heart:'Symbols',stars:'Symbols',lotus:'Cultural',butterfly:'Other'};
  const assetStore=()=>callbacks?.assets||{clipart:[],fonts:[],can_manage:false};
  const fontChoices=()=>[['serif','Elegant serif'],['sans','Modern sans'],['script','Calligraphy'],['display','Bold display'],
    ...assetStore().fonts.map(item=>['font:'+item.id,item.name])];
  const fontPicker=(selectedValue,attr)=>'<select '+attr+'>'+fontChoices().map(([id,name])=>option(id,name,selectedValue)).join('')+'</select';
  const defaultPositions=()=>JSON.parse(JSON.stringify(window.eventosCanvasDefaultPositions));
  const elem=id=>document.querySelector('#modalRoot')?.querySelector(id);
  const art=()=>window.eventosCanvasArt||{};
  const artNames=()=>window.eventosCanvasArtNames||{};
  const uid=()=>crypto.randomUUID?.().replaceAll('-','')||Math.random().toString(36).slice(2);
  function pos(field){return current.canvas_positions?.[field]||window.eventosCanvasDefaultPositions[field]}
  function currentChoice(){
    if(!selected||!current)return null;
    if(selected.startsWith('field:')){
      const key=selected.slice(6);
      if(!fieldNames[key])return null;
      return {kind:'field',key,field:pos(key)};
    }
    const key=selected.slice(5),index=current.canvas_items.findIndex(x=>x.id===key);
    return index>=0?{kind:'item',key,index,item:current.canvas_items[index]}:null;
  }
  const option=(value,label,selectedValue)=>`<option value="${esc(value)}" ${selectedValue===value?'selected':''}>${esc(label)}</option>`;
  function inspector(){
    const chosen=currentChoice();
    if(!chosen)return '<p class="invite-canvas-empty">Tap a text block or decoration on the invitation to move, resize or recolor it.</p>';
    const target=chosen.kind==='field'?chosen.field:chosen.item;
    const isField=chosen.kind==='field', isArt=target.kind==='clipart'||target.kind==='asset';
    const title=isField?names[chosen.key]:target.kind==='asset'?(assetStore().clipart.find(a=>a.id===target.asset_id)?.name||'Uploaded clipart'):isArt?artNames()[target.art]:'Extra text';
    const sizeLow=isArt?3:isField?1.6:1.8,sizeHigh=isArt?48:12;
    const color=isField?(['headline','title'].includes(chosen.key)?current.accent_color:current.canvas_text_color):target.color;
    return `<section class="invite-canvas-inspector">
      <strong>Selected: ${esc(title)}</strong>
      ${isField?`<label class="field"><span>${esc(names[chosen.key])} wording</span>
        <textarea rows="2" data-canvas-word="${fieldNames[chosen.key]}" maxlength="${wordLimit[chosen.key]}">${esc(current[fieldNames[chosen.key]]||window.eventosCanvasFieldValues({event_name:callbacks.event.name,start_date:callbacks.event.start_date,location:callbacks.event.location},current)[chosen.key])}</textarea></label>`:''}
      ${!isField&&!isArt?`<label class="field"><span>Text</span><textarea rows="2" data-canvas-prop="text" maxlength="240">${esc(target.text)}</textarea></label>`:''}
      ${!isField&&target.kind==='clipart'?`<label class="field"><span>Clipart type</span><select data-canvas-prop="art">${Object.keys(art()).map(key=>option(key,artNames()[key],target.art)).join('')}</select></label>`:''}
      <div class="invite-canvas-inspector-row">
        <label class="field"><span>Horizontal (%)</span><input type="number" min="0" max="100" step="1" data-canvas-prop="x" value="${target.x}"></label>
        <label class="field"><span>Vertical (%)</span><input type="number" min="0" max="100" step="1" data-canvas-prop="y" value="${target.y}"></label>
        <label class="field"><span>Size</span><input type="range" min="${sizeLow}" max="${sizeHigh}" step=".5" data-canvas-prop="size" value="${target.size}"></label>
        ${!isField?`<label class="field"><span>Rotation</span><input type="range" min="-180" max="180" step="5" data-canvas-prop="rotation" value="${target.rotation}"></label>`:''}
        <label class="field"><span>${isField?'Body text':'Element'} color</span><input type="color" data-canvas-prop="color" value="${esc(color)}"></label>
        ${!isField&&!isArt?`<label class="field"><span>Font</span>${fontPicker(target.font,'data-canvas-prop="font"')}</label>`:''}
      </div>
      <div class="invite-canvas-toolbar">
        ${!isField?`<button type="button" class="btn tiny" data-canvas-action="duplicate">Duplicate</button>
          <button type="button" class="btn tiny" data-canvas-action="forward">Bring forward</button>
          <button type="button" class="btn tiny" data-canvas-action="backward">Send backward</button>
          <button type="button" class="btn tiny danger" data-canvas-action="remove">Remove</button>`:
          '<button type="button" class="btn tiny" data-canvas-action="reset-field">Reset position</button>'}
      </div>
    </section>`;
  }
  function palette(){
    return `<div class="invite-canvas-background">${colors.map(bg=>
      `<button type="button" data-canvas-action="background" data-value="${bg}" class="${current.canvas_background===bg?'active':''}">${bg.charAt(0).toUpperCase()+bg.slice(1)}</button>`).join('')}</div>`;
  }
  function layerTools(){
    return `<div class="invite-canvas-layers">
      ${['host_line','headline','title','subtitle','date','location','closing_note'].map(key=>`<button type="button" class="btn ${selected==='field:'+key?'is-active':''}" data-canvas-action="select" data-key="field:${key}">${esc(names[key])}</button>`).join('')}
      ${current.canvas_items.map((item,i)=>`<button type="button" class="btn ${selected==='item:'+item.id?'is-active':''}" data-canvas-action="select" data-key="item:${esc(item.id)}">${item.kind==='clipart'?'✦ '+esc(artNames()[item.art]):item.kind==='asset'?'▣ '+esc(assetStore().clipart.find(a=>a.id===item.asset_id)?.name||'Uploaded image'):'T '+esc(String(item.text||'Text').slice(0,15))} ${i+1}</button>`).join('')}
    </div>`;
  }
  function artPalette(){
    return `<div class="invite-canvas-art-grid">${Object.keys(art()).map(key=>`<button type="button" class="invite-canvas-art-button" data-canvas-action="add-art" data-value="${esc(key)}" title="Add ${esc(artNames()[key])}">
      <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true">${art()[key]}</svg><span>${esc(artNames()[key])}</span></button>`).join('')}</div>`;
  }
  function wordFields(){
    const choices=[
      ['host_line','Hosted by / family names',160],['headline','Headline',120],
      ['canvas_title','Couple / event names',160],['subtitle','Invitation details',240],
      ['canvas_date','Date wording (leave blank to use event date)',120],
      ['canvas_location','Venue wording (leave blank to use event location)',160],
      ['closing_note','Closing message',350]
    ];
    return `<div class="invite-canvas-form-fields">${choices.map(([key,label,max])=>`<label class="field"><span>${label}</span>
      ${key==='subtitle'||key==='closing_note'?`<textarea rows="2" data-canvas-word="${key}" maxlength="${max}">${esc(current[key]||'')}</textarea>`:
      `<input data-canvas-word="${key}" type="text" value="${esc(current[key]||'')}" maxlength="${max}">`}</label>`).join('')}
      <label class="rsvp-check-label"><input type="checkbox" data-canvas-setting="show_date" ${current.show_date?'checked':''}> Show date</label>
      <label class="rsvp-check-label"><input type="checkbox" data-canvas-setting="show_location" ${current.show_location?'checked':''}> Show location</label>
      <label class="field"><span>Accent / heading color</span><input type="color" data-canvas-setting="accent_color" value="${esc(current.accent_color)}"></label>
      <label class="field"><span>Invitation font</span>${fontPicker(current.canvas_font||'serif','data-canvas-setting="canvas_font"')}</label>
      <label class="field"><span>Body text color</span><input type="color" data-canvas-setting="canvas_text_color" value="${esc(current.canvas_text_color)}"></label>
    </div>`;
  }
  function canvasSettings(){
    return `<h3 class="invite-section-title">Full-page background</h3>
      ${palette()}
      <label class="rsvp-check-label" style="margin-top:13px"><input type="checkbox" data-canvas-setting="canvas_use_cover" ${current.canvas_use_cover?'checked':''}> Use uploaded image as full-page background</label>
      <div class="invite-upload-box"><label class="field"><span>Upload background (JPG, PNG or WebP, 4 MB)</span>
        <input type="file" data-invite-file="cover" accept="image/jpeg,image/png,image/webp"></label>
        ${callbacks.media.cover?`<p>Current: ${esc(callbacks.media.cover.filename)} <button class="btn tiny" data-invite-action="delete-media" data-id="${esc(callbacks.media.cover.id)}" type="button">Remove</button></p>`:'<p>No background image uploaded.</p>'}
        <p>Uploaded images are saved for this event. Artwork-only library templates retain vector decorations, not uploaded files.</p></div>
`;
  }
  function artTools(){
    return `<h3 class="invite-section-title">Add clipart anywhere</h3><p class="invite-canvas-edit-help">Add as many decorations as you like (up to 40 total layers), then drag each one into position using a finger or mouse.</p>
      ${artPalette()}<button type="button" class="btn" data-canvas-action="add-text">+ Add custom text layer</button>
      <h3 class="invite-canvas-layer-label">Move or edit a layer</h3>${layerTools()}
      <div id="canvasInspector">${inspector()}</div>`;
  }
  function main(){
    return `<div class="invitation-design-settings">
      <p class="invitation-tip">Wedding canvas: choose a full-page background, add floral clipart and move each layer. Edit all wording without changing the artwork.</p>
      ${canvasSettings()}
      <div class="invite-canvas-toolbar"><button type="button" class="btn primary" data-invite-action="tab" data-value="canvas">✥ Arrange on canvas →</button></div>
      <h3 class="invite-section-title">Editable wedding invitation text</h3>${wordFields()}
      ${artTools()}
      <p class="invite-library-help">Tap Save invitation when finished. To reuse only this artwork for another event, save it in Theme library.</p></div>`;
  }
  function arrange(){
    return `<div class="invitation-design-settings invite-canvas-arrange-tools">
      <p class="invitation-tip">Drag any text or clipart directly on the page. Tap a layer to edit its size, color and rotation.</p>
      <div class="invite-canvas-toolbar"><button type="button" class="btn" data-invite-action="tab" data-value="create">← Edit wording & background</button></div>
      ${artTools()}
    </div>`;
  }
  const resizeDirections=['nw','ne','sw','se'];
  const snap=(value)=>{
    for(const guide of [25,50,75]){
      if(Math.abs(value-guide)<2.5)return guide;
    }
    return value;
  };
  function highlight(){
    const canvas=elem('#invitationLivePreview .invite-canvas');if(!canvas)return;
    canvas.classList.toggle('invite-guides-on',showGuides);
    canvas.querySelectorAll('.invite-canvas-item').forEach(node=>{
      const key=node.dataset.canvasField?'field:'+node.dataset.canvasField:'item:'+node.dataset.canvasItem;
      const active=selected===key;
      node.classList.toggle('is-selected',active);
      if(active){
        if(!node.querySelector('[data-canvas-resize]')){
          for(const dir of resizeDirections){
            const handle=document.createElement('span');
            handle.className='invite-resize-handle invite-resize-'+dir;
            handle.dataset.canvasResize=dir;
            handle.setAttribute('aria-hidden','true');
            node.appendChild(handle);
          }
        }
      }else{
        node.querySelectorAll('[data-canvas-resize]').forEach(el=>el.remove());
      }
    });
  }
  function refreshInspector(){
    const panel=elem('#canvasInspector');if(panel)panel.innerHTML=inspector();
    elem('.invite-canvas-layers')?.querySelectorAll('[data-canvas-action="select"]').forEach(node=>{
      node.classList.toggle('is-active',node.dataset.key===selected);
    });
    highlight();
    window.EventOSCompactSelectionChanged?.(selected);
  }
  function attach(design,config){
    current=design;callbacks=config;
    const preview=elem('#invitationLivePreview');
    const live=preview?.closest('.invitation-live');
    const editable=config.editable&&design?.mode==='canvas'&&config.canEdit;
    if(live)live.classList.toggle('invite-canvas-editing',!!editable);
    if(!editable){return}
    const canvas=preview.querySelector('.invite-canvas');if(!canvas)return;
    if(!canvas.querySelector('.invite-canvas-guide')){
      const lines=[['v',25],['v',50],['v',75],['h',25],['h',50],['h',75]];
      for(const [axis,position] of lines){
        const guide=document.createElement('span');
        guide.className='invite-canvas-guide guide-'+axis+(position===50?' guide-center':'');
        guide.style[axis==='v'?'left':'top']=position+'%';
        canvas.appendChild(guide);
      }
    }
    canvas.querySelectorAll('.invite-canvas-item').forEach(node=>{
      node.tabIndex=0;
      node.setAttribute('role','button');
      node.setAttribute('aria-label','Drag to position '+(node.dataset.canvasField?names[node.dataset.canvasField]:'decoration or text'));
      node.addEventListener('pointerdown',event=>{
        if(event.button!==0||!editable)return;
        const key=node.dataset.canvasField?'field:'+node.dataset.canvasField:'item:'+node.dataset.canvasItem;
        selected=key;refreshInspector();
        const picked=currentChoice(),target=picked?.kind==='field'?picked.field:picked?.item;
        if(!target)return;
        const rect=canvas.getBoundingClientRect();
        const pointX=event.clientX,pointY=event.clientY,startingX=target.x,startingY=target.y;
        const grip=event.target.closest('[data-canvas-resize]');
        const direction=grip?.dataset.canvasResize||'';
        const startSize=target.size;
        let didMove=false;
        const minSize=picked.kind==='item'&&picked.item.kind!=='text'?3:picked.kind==='field'?1.6:1.8;
        const maxSize=picked.kind==='item'&&picked.item.kind!=='text'?48:12;
        node.setPointerCapture?.(event.pointerId);
        const move=e=>{
          if(e.pointerId!==event.pointerId)return;
          if(!didMove){checkpoint();didMove=true}
          if(direction){
            const deltaX=100*(e.clientX-pointX)/rect.width*(direction.endsWith('e')?1:-1);
            const deltaY=100*(e.clientY-pointY)/rect.height*(direction.startsWith('s')?1:-1);
            const next=+(clamp(startSize+(deltaX+deltaY)/2,minSize,maxSize)).toFixed(2);
            target.size=next;
            if(picked.kind==='item'&&picked.item.kind!=='text')node.style.width=next+'%';
            else node.style.fontSize=next+'cqw';
            return;
          }
          target.x=+clamp(showGuides?snap(startingX+100*(e.clientX-pointX)/rect.width):startingX+100*(e.clientX-pointX)/rect.width,0,100).toFixed(2);
          target.y=+clamp(showGuides?snap(startingY+100*(e.clientY-pointY)/rect.height):startingY+100*(e.clientY-pointY)/rect.height,0,100).toFixed(2);
          node.style.left=target.x+'%';node.style.top=target.y+'%';
        };
        const end=e=>{
          if(e.pointerId!==event.pointerId)return;
          node.removeEventListener('pointermove',move);node.removeEventListener('pointerup',end);node.removeEventListener('pointercancel',end);
          refreshInspector();
        };
        node.addEventListener('pointermove',move);node.addEventListener('pointerup',end);node.addEventListener('pointercancel',end);
        event.preventDefault();
      });
      node.addEventListener('keydown',e=>{
        if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
        selected=node.dataset.canvasField?'field:'+node.dataset.canvasField:'item:'+node.dataset.canvasItem;
        const chosen=currentChoice(),target=chosen?.kind==='field'?chosen.field:chosen?.item;if(!target)return;
        checkpoint();const step=e.shiftKey?5:1;
        if(e.key==='ArrowLeft')target.x=clamp(target.x-step,0,100);
        if(e.key==='ArrowRight')target.x=clamp(target.x+step,0,100);
        if(e.key==='ArrowUp')target.y=clamp(target.y-step,0,100);
        if(e.key==='ArrowDown')target.y=clamp(target.y+step,0,100);
        node.style.left=target.x+'%';node.style.top=target.y+'%';
        refreshInspector();e.preventDefault();
      });
    });
    highlight();
  }
  function canvasClick(button){
    if(!current||!callbacks)return false;
    const action=button.dataset.canvasAction;
    if(!action)return false;
    if(!callbacks.canEdit)return true;
    if(action!=='select')checkpoint();
    if(action==='background'){
      current.canvas_background=button.dataset.value;
      if(button.dataset.value==='midnight'){current.canvas_text_color='#f7f0e5';current.accent_color='#edcf95'}
      else if(current.canvas_text_color==='#f7f0e5'){current.canvas_text_color='#403735';current.accent_color='#946e50'}
      callbacks.render();return true;
    }
    if(action==='select'){selected=button.dataset.key;refreshInspector();return true}
    if(action==='add-art'){
      if(current.canvas_items.length>=40){callbacks.toast('Maximum 40 canvas layers');return true}
      const id=uid();
      current.canvas_items.push({id,kind:'clipart',art:button.dataset.value,
        x:50,y:22+((current.canvas_items.length*13)%55),size:18,rotation:0,color:current.accent_color});
      selected='item:'+id;callbacks.render();return true;
    }
    if(action==='add-text'){
      if(current.canvas_items.length>=40){callbacks.toast('Maximum 40 canvas layers');return true}
      const id=uid();current.canvas_items.push({id,kind:'text',text:'Your custom text',
        x:50,y:60,size:3.5,rotation:0,color:current.canvas_text_color,font:'serif'});
      selected='item:'+id;callbacks.render();return true;
    }
    const chosen=currentChoice();if(!chosen)return true;
    if(action==='reset-field'&&chosen.kind==='field'){
      current.canvas_positions[chosen.key]={...defaultPositions()[chosen.key]};callbacks.render();return true;
    }
    if(chosen.kind!=='item')return true;
    if(action==='remove'){current.canvas_items.splice(chosen.index,1);selected=null;callbacks.render();return true}
    if(action==='duplicate'){
      if(current.canvas_items.length>=40){callbacks.toast('Maximum 40 canvas layers');return true}
      const copy={...chosen.item,id:uid(),x:clamp(chosen.item.x+6,0,100),y:clamp(chosen.item.y+6,0,100)};
      current.canvas_items.splice(chosen.index+1,0,copy);selected='item:'+copy.id;callbacks.render();return true;
    }
    if(action==='forward'&&chosen.index<current.canvas_items.length-1){
      const arr=current.canvas_items;[arr[chosen.index],arr[chosen.index+1]]=[arr[chosen.index+1],arr[chosen.index]];callbacks.render();return true;
    }
    if(action==='backward'&&chosen.index>0){
      const arr=current.canvas_items;[arr[chosen.index],arr[chosen.index-1]]=[arr[chosen.index-1],arr[chosen.index]];callbacks.render();return true;
    }
    return true;
  }
  function canvasInput(input){
    if(!current||!callbacks||!callbacks.canEdit)return;
    const raw=input.type==='checkbox'?input.checked:input.value;
    if(input.dataset.canvasWord){
      const field=input.dataset.canvasWord;
      if(field in current)current[field]=raw;
      callbacks.preview();return;
    }
    if(input.dataset.canvasFieldFont){
      const key=input.dataset.canvasFieldFont;
      if(!fieldNames[key])return;
      if(!current.canvas_field_fonts)current.canvas_field_fonts={};
      current.canvas_field_fonts[key]=raw;
      callbacks.preview();return;
    }
    if(input.dataset.canvasSetting){
      current[input.dataset.canvasSetting]=raw;callbacks.preview();return;
    }
    const key=input.dataset.canvasProp,chosen=currentChoice();
    if(!key||!chosen)return;
    if(key==='text'&&String(raw).trim()==='')return;
    const target=chosen.kind==='field'?chosen.field:chosen.item;
    if(key==='color'){
      if(chosen.kind==='field')current[['headline','title'].includes(chosen.key)?'accent_color':'canvas_text_color']=raw;
      else target.color=raw;
    }else if(key==='size'||key==='x'||key==='y'||key==='rotation'){
      const number=Number(raw);
      if(!Number.isFinite(number))return;
      if(key==='size')target.size=clamp(number,target.kind==='clipart'||target.kind==='asset'?3:1.8,target.kind==='clipart'||target.kind==='asset'?48:12);
      else if(key==='rotation')target.rotation=clamp(number,-180,180);
      else target[key]=clamp(number,0,100);
    }else if(key in target)target[key]=raw;
    callbacks.preview();
  }
  document.getElementById('modalRoot')?.addEventListener('click',e=>{
    const btn=e.target.closest('[data-canvas-action]');
    if(btn&&btn.closest('.invitation-designer')){e.preventDefault();canvasClick(btn)}
  });
  document.getElementById('modalRoot')?.addEventListener('focusin',e=>{
    if(e.target.matches('[data-canvas-word],[data-canvas-prop],[data-canvas-setting],[data-canvas-field-font]')&&!editingInputs.has(e.target)){
      checkpoint();editingInputs.add(e.target);
    }
  });
  document.getElementById('modalRoot')?.addEventListener('input',e=>{
    if(e.target.matches('[data-canvas-word],[data-canvas-prop],[data-canvas-setting],[data-canvas-field-font]'))canvasInput(e.target);
  });
  document.getElementById('modalRoot')?.addEventListener('change',e=>{
    if(e.target.matches('[data-canvas-word],[data-canvas-prop],[data-canvas-setting],[data-canvas-field-font]'))canvasInput(e.target);
  });
  window.EventOSCanvasEditor={
    main,arrange,attach,inspector,layerTools,
    setup:(design,config)=>{current=design;callbacks=config},
    reset:()=>{selected=null;history.length=0;redoHistory.length=0},
    checkpoint,
    canUndo:()=>history.length>0,
    canRedo:()=>redoHistory.length>0,
    undo:()=>restore(history,redoHistory),
    redo:()=>restore(redoHistory,history),
    selection:()=>selected,
    selectedInfo:currentChoice,
    alignSelected:(axis,value)=>{
      const choice=currentChoice();
      if(!choice||!['x','y'].includes(axis)||![10,25,50,75,90].includes(value))return false;
      const target=choice.kind==='field'?choice.field:choice.item;
      checkpoint();target[axis]=value;
      callbacks.preview();return true;
    },
    setGuides:shown=>{showGuides=!!shown;highlight()},
    guidesEnabled:()=>showGuides,
    select:key=>{selected=key;refreshInspector()},
    deleteSelected:()=>{
      const choice=currentChoice();
      if(!choice||choice.kind!=='item')return false;
      checkpoint();current.canvas_items.splice(choice.index,1);
      selected=null;callbacks.render();return true;
    }
  };
})();