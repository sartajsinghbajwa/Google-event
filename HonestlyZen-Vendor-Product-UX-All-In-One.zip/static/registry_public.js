/* Honestly Zen Event Planning guest gift registry — reservations and contributions are not payments. */
'use strict';
(function(){
 const root=document.getElementById('experienceRoot'),token=location.pathname.split('/').pop();
 const ep='/api/registry/'+encodeURIComponent(token);
 const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let data=null,category='All',view='all',chosen=null;
 const money=cents=>new Intl.NumberFormat('en-CA',{style:'currency',currency:data?.currency||'CAD'}).format((Number(cents)||0)/100);
 async function request(path,method='GET',body){
  const r=await fetch(path,{method,cache:'no-store',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});
  const result=await r.json().catch(()=>({}));
  if(!r.ok)throw Error(result.detail||'Unable to process request');
  return result;
 }
 function itemCard(g){
  const physical=g.kind==='gift',current=physical?g.reserved_quantity:g.pledged_cents,total=physical?g.quantity:g.target_cents;
  const available=Math.max(0,total-current),percent=total?Math.round(current/total*100):0;
  return '<article class="registry-guest-item">'+
   ((g.image_path||g.image_url)?'<img loading="lazy" alt="'+h(g.title)+'" src="'+h(g.image_path||g.image_url)+'">':'<div class="registry-guest-placeholder">'+(physical?'🎁':'💝')+'</div>')+
   '<div class="registry-guest-item-content"><div class="registry-card-labels"><span>'+h(g.category)+'</span>'+(g.priority==='High'?'<span>Most wanted</span>':'')+'</div>'+
   '<h3>'+h(g.title)+'</h3><p>'+h(g.description||'A thoughtful gift for our special day.')+'</p>'+
   '<div class="registry-progress"><span style="width:'+percent+'%"></span></div>'+
   '<div class="registry-level">'+(physical?current+' of '+total+' gifts reserved':money(current)+' pledged toward '+money(total))+'</div>'+
   '<div class="registry-guest-actions">'+
   (g.link_url?'<a href="'+h(g.link_url)+'" rel="noopener noreferrer" target="_blank">View at store ↗</a>':'')+
   '<button type="button" class="experience-primary" data-reg-reserve="'+h(g.id)+'" '+(!available?'disabled':'')+'>'+
   (available?(physical?'Reserve gift':'Make a pledge'):(physical?'Fully reserved':'Goal reached'))+'</button></div>'+
   '</div></article>';
 }
 function render(){
  if(!data)return;
  const items=data.items||[],categories=['All',...new Set(items.map(x=>x.category))];
  const available=x=>x.kind==='gift'?x.reserved_quantity<x.quantity:x.pledged_cents<x.target_cents;
  const shown=items.filter(x=>(category==='All'||x.category===category)&&(view!=='available'||available(x)));
  root.innerHTML='<header class="experience-hero registry-hero"><div class="experience-mark">✦ WISHES & GRATITUDE</div>'+
   '<h1>'+h(data.title)+'</h1><p class="experience-hero-sub">'+h(data.event_name)+'</p>'+
   '<p>'+h(data.intro)+'</p></header>'+
   '<section class="registry-public-content"><div class="experience-public-head"><h2>Our wishlist</h2><span>'+items.length+' gifts & funds</span></div>'+
   '<p class="experience-disclaimer">Reservations help guests coordinate gifts. Fund contributions are pledges only; no payments are collected or transferred by Honestly Zen Event Planning.</p>'+
   '<div class="registry-filters"><select id="registryCategory" aria-label="Filter gift categories">'+categories.map(x=>'<option value="'+h(x)+'" '+(x===category?'selected':'')+'>'+h(x)+'</option>').join('')+'</select>'+
   '<label><input id="registryAvailable" type="checkbox" '+(view==='available'?'checked':'')+'> Show available only</label></div>'+
   '<div class="registry-public-grid">'+shown.map(itemCard).join('')+'</div>'+
   (!shown.length?'<div class="experience-empty">No gifts match this filter.</div>':'')+
   '<div class="registry-cancel-help"><h3>Need to change a reservation?</h3><p>Use the reservation ID and private management code you received when making your reservation.</p><button type="button" class="experience-secondary" id="cancelGiftButton">Cancel a reservation</button></div>'+
   '</section><footer class="experience-footer">Made with Honestly Zen Event Planning · Celebrating together</footer>'+
   '<div id="registryDialog"></div>';
 }
 function dialog(content){
  const outlet=document.getElementById('registryDialog');if(!outlet)return;
  outlet.innerHTML='<div class="experience-dialog-overlay"><div class="experience-dialog" role="dialog" aria-modal="true"><button type="button" class="experience-close" id="registryDialogClose" aria-label="Close">×</button>'+content+'</div></div>';
  outlet.querySelector('#registryDialogClose').onclick=()=>outlet.replaceChildren();
 }
 function reserveItem(id){
  chosen=(data.items||[]).find(x=>x.id===id);if(!chosen)return;
  const gift=chosen.kind==='gift',remaining=gift?chosen.quantity-chosen.reserved_quantity:chosen.target_cents-chosen.pledged_cents;
  if(remaining<=0)return;
  const content='<h2>'+(gift?'Reserve a gift':'Make a contribution pledge')+'</h2><p class="small-note">'+h(chosen.title)+'</p>'+
   (gift?'<p class="small-note">'+remaining+' still available to reserve</p>':'<p class="experience-disclaimer">This records your intended contribution. No money will be charged or collected.</p>')+
   '<form id="registryReserveForm"><label>Your name *<input name="donor_name" maxlength="100" required></label>'+
   '<label>Email for your own reference (optional)<input name="donor_email" maxlength="255" type="email"></label>'+
   (gift?'<label>How many?<input name="quantity" type="number" min="1" max="'+remaining+'" value="1" required></label>':
    '<label>Amount you intend to contribute ('+h(data.currency)+')<input name="amount" type="number" min="1" step=".01" max="'+(remaining/100).toFixed(2)+'" required></label>')+
   '<label>Gift message (optional)<textarea maxlength="400" rows="3" name="note"></textarea></label>'+
   '<button type="submit" class="experience-primary">Confirm '+(gift?'reservation':'pledge')+'</button></form><p class="experience-feedback" role="status"></p>';
  dialog(content);
 }
 function success(result){
  dialog('<h2>'+(result.status==='reserved'?'Gift reserved!':'Pledge recorded!')+'</h2>'+
   '<p>'+h(result.message)+'</p>'+
   '<p class="experience-disclaimer">Save both values below if you might need to cancel. They cannot be retrieved later.</p>'+
   '<label>Reservation ID<input readonly id="registryResultId" value="'+h(result.reservation_id)+'"></label>'+
   '<label>Private management code<input readonly id="registryResultCode" value="'+h(result.manage_code)+'"></label>'+
   '<button type="button" id="registryCopyCodes" class="experience-primary">Copy management details</button>');
 }
 function cancelDialog(){
  dialog('<h2>Cancel a reservation</h2><p class="small-note">Enter your reservation details to release a gift or an unfulfilled pledge.</p>'+
  '<form id="registryCancelForm"><label>Reservation ID<input name="reservation_id" required></label>'+
  '<label>Private management code<input name="manage_code" required></label>'+
  '<button type="submit" class="experience-primary">Cancel reservation</button></form><p class="experience-feedback" role="status"></p>');
 }
 root.addEventListener('change',e=>{
  if(e.target.id==='registryCategory'){category=e.target.value;render()}
  else if(e.target.id==='registryAvailable'){view=e.target.checked?'available':'all';render()}
 });
 root.addEventListener('click',e=>{
  const reserve=e.target.closest('[data-reg-reserve]');
  if(reserve){reserveItem(reserve.dataset.regReserve);return}
  if(e.target.id==='cancelGiftButton'){cancelDialog();return}
  if(e.target.id==='registryCopyCodes'){
   const id=document.getElementById('registryResultId')?.value||'';
   const code=document.getElementById('registryResultCode')?.value||'';
   navigator.clipboard.writeText('Reservation ID: '+id+'\nManagement code: '+code)
    .then(()=>e.target.textContent='Copied!').catch(()=>{e.target.textContent='Select and copy the values above'});
  }
 });
 root.addEventListener('submit',async e=>{
  if(e.target.id==='registryReserveForm'){
   e.preventDefault();const f=new FormData(e.target),gift=chosen.kind==='gift',btn=e.target.querySelector('button[type=submit]');
   const pledged=gift?0:Math.round(Number(f.get('amount')||0)*100);
   if(!gift&&(!Number.isInteger(pledged)||pledged<100)){e.target.nextElementSibling.textContent='Enter a valid amount of at least 1.00';return}
   btn.disabled=true;
   try{
    const result=await request(ep+'/reserve','POST',{item_id:chosen.id,donor_name:f.get('donor_name'),
       donor_email:f.get('donor_email'),note:f.get('note'),quantity:gift?Number(f.get('quantity')):1,pledged_cents:pledged});
    success(result);
    data=await request(ep);
   }catch(err){e.target.nextElementSibling.textContent=err.message;btn.disabled=false}
  }else if(e.target.id==='registryCancelForm'){
   e.preventDefault();const f=new FormData(e.target),btn=e.target.querySelector('button[type=submit]');
   btn.disabled=true;
   try{await request(ep+'/cancel','POST',{reservation_id:f.get('reservation_id'),manage_code:f.get('manage_code')});
     dialog('<h2>Reservation cancelled</h2><p>The organizer’s gift registry has been updated.</p>');data=await request(ep)}
   catch(err){e.target.nextElementSibling.textContent=err.message;btn.disabled=false}
  }
 });
 let loading=false;
 async function load(){
  if(loading||document.hidden||document.getElementById('registryDialog')?.childElementCount)return;
  loading=true;
  try{const next=await request(ep);const changed=JSON.stringify(next)!==JSON.stringify(data);data=next;if(changed)render()}
  catch(err){if(!data)root.innerHTML='<div class="experience-error"><h1>Gift registry unavailable</h1><p>'+h(err.message)+'</p></div>'}
  finally{loading=false}
 }
 setInterval(load,15000);
 load();
})();
