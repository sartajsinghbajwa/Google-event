'use strict';
(() => {
  const esc = v => String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const ART={
    rose:'<path d="M45 68C20 59 26 32 43 36c-5-24 23-27 30-7 20 2 21 28 3 38-11 8-23 8-31 1Z"/><path d="M48 62c-15-14-5-28 7-20 6-16 19-9 15 4 15 8 0 23-14 19"/><path d="M56 73c-2 10-5 16-13 23M48 85c-11-10-21-9-29-8 6 12 15 16 29 8M53 85c13-10 24-8 28-5-5 11-16 15-28 5"/>',
    leaf:'<path d="M16 91C24 69 42 40 82 15"/><path d="M33 68C13 54 16 34 23 23c18 12 19 30 10 45ZM48 52C40 31 56 14 70 11c8 22-3 34-22 41ZM62 39C70 20 86 24 92 28c-1 18-14 20-30 11ZM28 80C16 79 11 71 9 62c15-5 25 2 19 18Z"/>',
    flourish:'<path d="M5 72c12-46 41-56 55-38 16 20-6 30-17 20-7-7 0-20 10-14M19 64C5 49 13 31 27 24M60 34c9-22 28-23 36-14M58 34C52 7 69 5 76 11M35 51C39 26 27 11 17 7M67 34c20 7 22 19 22 31M69 42C83 43 88 59 82 70"/>',
    rings:'<circle cx="39" cy="57" r="28"/><circle cx="63" cy="57" r="28"/><path d="M43 29l7-11 7 11M38 32l12-14 12 14M50 18v-7M29 13l-5-5M72 14l5-5"/>',
    heart:'<path d="M50 88 15 51C-2 32 22 5 43 28l7 8 7-8C79 5 103 32 85 51Z"/><path d="M50 76 24 48"/>',
    stars:'<path d="m50 5 10 33 33 12-33 11-10 34-11-34L6 50l33-12Z"/><path d="M9 12v21M0 23h18M85 72v20M75 82h20M85 2v16M77 10h16"/>',
    lotus:'<path d="M50 80C32 66 28 44 50 16c22 28 18 50 0 64Z"/><path d="M50 83C19 81 13 59 19 34c23 8 32 25 31 49ZM50 83c31-2 37-24 31-49-23-9-32-25-31-49ZM50 82C28 94 11 87 5 68c19-9 34-4 45 14ZM50 82c22 12 39 5 45-14-19-9-34-4-45 14Z"/>',
    mandala:'<circle cx="50" cy="50" r="13"/><circle cx="50" cy="50" r="25"/><circle cx="50" cy="50" r="42"/><path d="M50 8C40 23 40 30 50 37 60 30 60 23 50 8ZM50 92c-10-15-10-22 0-29 10 7 10 14 0 29ZM8 50c15-10 22-10 29 0-7 10-14 10-29 0ZM92 50c-15-10-22-10-29 0 7 10 14 10 29 0Z"/>',
    butterfly:'<path d="M48 48C30 5 8 10 9 34c-4 23 17 28 39 18M52 48C70 5 92 10 91 34c4 23-17 28-39 18M48 53C16 51 16 81 34 83c8 2 13-11 14-30ZM52 53c32-2 32 28 14 30-8 2-13-11-14-30Z"/><path d="M50 35v40M48 33 39 20M52 33l9-13"/>',
    bouquet:'<path d="M42 54 50 95l12-40M30 59 50 95M71 58 50 95"/><path d="M19 49c-16-5-15-19-4-25C14 10 34 9 39 21c18-4 27 15 12 25-4 15-24 16-32 3ZM60 49c-14-10-7-27 6-27 10-13 28-4 26 11 10 13-1 27-15 25-6 9-17 0-17-9Z"/><path d="M28 36c5-11 18-6 14 3M72 35c11-8 18 3 11 10M39 77C25 60 15 68 16 77c8 8 16 11 23 0M64 78c14-18 23-9 20 1-10 5-17 6-20-1"/>'
  };
  const names={rose:'Rose',leaf:'Leaf branch',flourish:'Floral flourish',rings:'Wedding rings',heart:'Heart',stars:'Stars',lotus:'Lotus',mandala:'Mandala',butterfly:'Butterfly',bouquet:'Bouquet'};
  const defaults={
    host_line:{x:50,y:23,size:3.5},headline:{x:50,y:35,size:6.5},
    title:{x:50,y:48,size:7.5},subtitle:{x:50,y:60,size:3.5},
    date:{x:50,y:72,size:3.2},location:{x:50,y:79,size:3.2},
    closing_note:{x:50,y:90,size:3.1}
  };
  const color=c=>/^#[a-fA-F0-9]{6}$/.test(c)?c:'#604633';
  const num=(v,f,min,max)=>typeof v==='number'&&Number.isFinite(v)?Math.min(max,Math.max(min,v)):f;
  const values=(event,d)=>({
    host_line:d.host_line||'',headline:d.headline||'',
    title:d.canvas_title||event.event_name||event.name||'Wedding celebration',
    subtitle:d.subtitle||'',date:d.show_date?(d.canvas_date||event.start_date||''):'',
    location:d.show_location?(d.canvas_location||event.location||''):'',
    closing_note:d.closing_note||''
  });
  const svg=id=>'<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">'+ART[id]+'</svg>';
  const libraryPrefix=prefix=>{
    const guest=prefix.match(/^(\/api\/rsvp\/[^/]+)\/media$/);
    if(guest)return guest[1]+'/design-assets';
    const admin=prefix.match(/^\/api\/w\/([^/]+)\/events\/[^/]+\/invitation-media$/);
    return admin?'/api/w/'+encodeURIComponent(admin[1])+'/design-assets':'';
  };
  const legacyFallback={
    'google:Playfair Display':'serif','google:Great Vibes':'script',
    'google:Montserrat':'sans','google:Poppins':'sans','google:Lora':'serif',
    'google:Dancing Script':'script','google:Pacifico':'script',
    'google:Cormorant Garamond':'serif','google:Libre Baskerville':'serif',
    'google:DM Sans':'sans'
  };
  const fontStyle=(key,assetBase)=>{
    const candidate=legacyFallback[String(key||'serif')]||String(key||'serif');
    if(/^font:[0-9a-f-]{36}$/.test(candidate)&&assetBase){
      const id=candidate.slice(5),face='EventOS'+id.replace(/-/g,'');
      return {css:'font-family:"'+face+'",Georgia,serif',face,id};
    }
    const css={'serif':'font-family:Georgia,serif','sans':'font-family:system-ui,sans-serif',
      'script':'font-family:"Brush Script MT","Segoe Script",cursive','display':'font-family:Impact,"Arial Black",sans-serif'};
    return {css:css[candidate]||css.serif};
  };
  // Register user-uploaded fonts as document fonts. In particular, Safari can
  // ignore a font-face inside injected preview markup until a document refresh.
  const loadedFonts=new Map();
  function prepareFonts(design,urlPrefix,onError){
    const assetBase=libraryPrefix(urlPrefix||'');
    if(!assetBase||typeof document==='undefined'||typeof FontFace==='undefined'||!document.fonts){
      return Promise.resolve([]);
    }
    const keys=[design?.font,design?.canvas_font,...Object.values(design?.canvas_field_fonts||{}),
      ...(Array.isArray(design?.canvas_items)?design.canvas_items.filter(x=>x.kind==='text').map(x=>x.font):[])];
    const ids=[...new Set(keys.filter(x=>typeof x==='string'&&/^font:[0-9a-f-]{36}$/.test(x)).map(x=>x.slice(5)))];
    return Promise.all(ids.map(id=>{
      const url=assetBase+'/'+encodeURIComponent(id),family='EventOS'+id.replace(/-/g,'');
      if(!loadedFonts.has(url)){
        const face=new FontFace(family,'url("'+url+'")');
        const pending=face.load().then(result=>{
          document.fonts.add(result);
          return result;
        });
        loadedFonts.set(url,pending);
      }
      return loadedFonts.get(url).catch(error=>{
        loadedFonts.delete(url);
        if(typeof onError==='function')onError('Could not load the selected uploaded font. Check that it is a valid TTF, OTF, WOFF, or WOFF2 file.');
        return null;
      });
    }));
  }
  function canvas(event,design,guest,media,urlPrefix){
    const d=design||{},bg=['ivory','blush','sage','champagne','midnight','parchment'].includes(d.canvas_background)?d.canvas_background:'ivory';
    const accent=color(d.accent_color),ink=color(d.canvas_text_color);
    const assetBase=libraryPrefix(urlPrefix||'');
    const globalFont=fontStyle(d.canvas_font,assetBase);
    const fontRefs=new Map();
    if(globalFont.face)fontRefs.set(globalFont.id,globalFont.face);
    for(const value of Object.values(d.canvas_field_fonts||{})){
      const font=fontStyle(value,assetBase);
      if(font.face)fontRefs.set(font.id,font.face);
    }
    (d.canvas_items||[]).forEach(item=>{
      if(item.kind==='text'){
        const styled=fontStyle(item.font,assetBase);
        if(styled.face)fontRefs.set(styled.id,styled.face);
      }
    });
    const fontDefinitions=[...fontRefs.entries()].map(([id,face])=>
      '@font-face{font-family:"'+face+'";src:url("'+assetBase+'/'+id+'");font-display:swap}').join('');
    const cover=media?.cover?.id&&urlPrefix?urlPrefix+'/'+encodeURIComponent(media.cover.id):/^https:\/\/[^<>"\s]+$/i.test(d.cover_image_url||'')?d.cover_image_url:'';
    const background=d.canvas_use_cover&&cover?'<img class="invite-canvas-bg-img" src="'+esc(cover)+'" loading="lazy" alt="Invitation background artwork">':'';
    const positions={...defaults,...(d.canvas_positions||{})};
    const hidden=new Set(Array.isArray(d.canvas_hidden_fields)?d.canvas_hidden_fields:[]);
    const fields=Object.entries(values(event,d)).filter(([key,v])=>v&&!hidden.has(key)).map(([key,text])=>{
      const p={...defaults[key],...(positions[key]||{})};
      const x=num(p.x,50,0,100),y=num(p.y,50,0,100),size=num(p.size,3.5,1.6,12);
      const tone=(key==='title'||key==='headline')?accent:ink;
      const kind=(key==='title'||key==='headline'||key==='closing_note')?'invite-canvas-serif':'invite-canvas-sans';
      const fieldFont=fontStyle((d.canvas_field_fonts||{})[key]||d.canvas_font,assetBase);
      return '<div class="invite-canvas-item invite-canvas-text '+kind+' invite-canvas-field-'+key+'" data-canvas-field="'+esc(key)+'" style="left:'+x+'%;top:'+y+'%;font-size:'+size+'cqw;color:'+tone+';'+fieldFont.css+'">'+esc(text)+'</div>';
    }).join('');
    const items=(Array.isArray(d.canvas_items)?d.canvas_items:[]).slice(0,40).map(item=>{
      if(!item||(item.kind!=='clipart'&&item.kind!=='text'&&item.kind!=='asset'))return '';
      const x=num(item.x,50,0,100),y=num(item.y,50,0,100),rotation=num(item.rotation,0,-180,180),tone=color(item.color);
      if(item.kind==='clipart'){
        if(!ART[item.art])return '';
        const size=num(item.size,18,3,48);
        return '<div class="invite-canvas-item invite-canvas-clipart" data-canvas-item="'+esc(item.id)+'" style="left:'+x+'%;top:'+y+'%;width:'+size+'%;color:'+tone+';--canvas-rotation:'+rotation+'deg" aria-label="'+esc(names[item.art])+' clipart">'+svg(item.art)+'</div>';
      }
      if(item.kind==='asset'){
        if(!assetBase||!/^[0-9a-f-]{36}$/.test(item.asset_id||''))return '';
        const size=num(item.size,18,3,48);
        return '<div class="invite-canvas-item invite-canvas-clipart" data-canvas-item="'+esc(item.id)+'" style="left:'+x+'%;top:'+y+'%;width:'+size+'%;--canvas-rotation:'+rotation+'deg"><img alt="Decorative clipart" src="'+assetBase+'/'+encodeURIComponent(item.asset_id)+'" draggable="false"></div>';
      }
      const size=num(item.size,3.5,1.8,12),font=fontStyle(item.font||d.canvas_font,assetBase);
      return '<div class="invite-canvas-item invite-canvas-text" data-canvas-item="'+esc(item.id)+'" style="left:'+x+'%;top:'+y+'%;font-size:'+size+'cqw;color:'+tone+';--canvas-rotation:'+rotation+'deg;'+font.css+'">'+esc(item.text||'')+'</div>';
    }).join('');
    return (fontDefinitions?'<style>'+fontDefinitions+'</style>':'')+'<div class="invite-canvas invite-canvas-bg-'+bg+'" style="--invite-accent:'+accent+';--invite-text-color:'+ink+'">'+background+'<div class="invite-canvas-frame"></div>'+fields+items+(guest?'<span class="invite-canvas-guest">Prepared for '+esc(guest)+'</span>':'')+'</div>';
  }
  window.eventosPrepareCanvasFonts=prepareFonts;
  window.eventosInvitationCanvas=canvas;
  window.eventosCanvasArt=ART;
  window.eventosCanvasArtNames=names;
  window.eventosCanvasDefaultPositions=defaults;
  window.eventosCanvasFieldValues=values;
})();