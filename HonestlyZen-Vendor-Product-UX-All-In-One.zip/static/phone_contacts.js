'use strict';
(() => {
  let people=[],eventId='',workspaceId='',busy=false,search='';
  const root=()=>document.getElementById('modalRoot');
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clean=v=>String(v||'').trim();
  const norm=v=>clean(v).normalize('NFKC').toLowerCase();
  const digits=v=>clean(v).replace(/\D/g,'');
  const picker=()=>!!navigator.contacts?.select;
  function load(rows){
    const seen=(Array.isArray(state.rows)?state.rows:[]).map(c=>({name:norm(c.name),email:norm(c.email),phone:digits(c.phone)}));
    const next=[];
    for(const row of rows){
      const name=clean(row.name).slice(0,160),email=clean(row.email).slice(0,250),phone=clean(row.phone).slice(0,80);
      if(!name)continue;
      const duplicate=seen.some(c=>(email&&c.email&&norm(email)===c.email)||(phone&&c.phone&&digits(phone)===c.phone)||(!email&&!phone&&norm(name)===c.name));
      next.push({name,email,phone,party_size:1,duplicate,selected:!duplicate});
      seen.push({name:norm(name),email:norm(email),phone:digits(phone)});
      if(next.length>=1000)break;
    }
    if(!next.length){toast('No named contacts found');return}
    people=next;search='';render();
    if(rows.length>1000)toast('First 1,000 contacts loaded. Import in batches.');
  }
  function unescapeCard(v){return String(v||'').replace(/\\([nN,;\\])/g,(_,x)=>x==='n'||x==='N'?'\n':x).trim()}
  function parseVcf(text){
    const lines=text.replace(/\r\n?/g,'\n').replace(/\n[ \t]/g,'').split('\n');
    const entries=[];let item=null,nParts=[];
    for(const line of lines){
      if(/^BEGIN:VCARD\s*$/i.test(line)){item={name:'',email:'',phone:''};nParts=[];continue}
      if(/^END:VCARD\s*$/i.test(line)){
        if(item){if(!item.name)item.name=[nParts[1],nParts[0]].filter(Boolean).join(' ');
          if(item.name)entries.push(item)}
        item=null;if(entries.length>=1000)break;continue;
      }
      if(!item)continue;
      const at=line.indexOf(':');if(at<1)continue;
      const key=line.slice(0,at).split(';')[0].split('.').pop().toUpperCase();
      const val=unescapeCard(line.slice(at+1));
      if(key==='FN'&&!item.name)item.name=val;
      if(key==='N')nParts=line.slice(at+1).split(';').map(unescapeCard);
      if(key==='EMAIL'&&!item.email)item.email=val;
      if(key==='TEL'&&!item.phone)item.phone=val.replace(/^tel:/i,'');
    }
    return entries;
  }
  const selected=()=>people.filter(p=>p.selected);
  function count(){
    const n=root()?.querySelector('#contactsSelected');
    if(n)n.textContent=selected().length+' of '+people.length+' selected';
    const button=root()?.querySelector('[data-phone-action="import"]');
    if(button)button.disabled=busy||selected().length===0;
  }
  function rows(){
    const el=root()?.querySelector('#phoneContactsList');if(!el)return;
    const visible=people.map((p,i)=>({p,i})).filter(({p})=>[p.name,p.email,p.phone].join(' ').toLowerCase().includes(search.toLowerCase()));
    el.innerHTML=visible.length?visible.map(({p,i})=>`<div class="phone-contact-row">
      <label class="phone-contact-person"><input type="checkbox" data-phone-check="${i}" ${p.selected?'checked':''}>
        <span><strong>${esc(p.name)}</strong><small>${esc([p.email,p.phone].filter(Boolean).join(' · ')||'No email or phone')}</small>
        ${p.duplicate?'<small class="phone-contact-duplicate">Possible duplicate — not preselected</small>':''}</span></label>
      <label class="phone-contact-seats">Seats <input type="number" aria-label="Seats for ${esc(p.name)}" data-phone-seats="${i}" min="1" max="10000" step="1" value="${p.party_size}"></label></div>`).join('')
      :'<p class="tiny-note">No matches. Try a different search.</p>';
    count();
  }
  function render(){
    if(!root())return;
    root().innerHTML=`<div class="modal-overlay"><section class="modal phone-contacts-modal" role="dialog" aria-modal="true" aria-labelledby="phoneContactsTitle">
      <header class="modal-head"><div><h2 id="phoneContactsTitle">Import phone contacts</h2><p class="tiny-note">Select people to invite to this event.</p></div><button type="button" class="xclose" data-phone-action="close" aria-label="Close">×</button></header>
      <div class="modal-body"><div class="phone-contact-actions">
        ${picker()?'<button class="btn primary" type="button" data-phone-action="picker">Select contacts from phone</button>':''}
        <label class="btn phone-vcf-label">Choose .vcf contact file<input id="phoneContactsFile" type="file" accept=".vcf,text/vcard,text/x-vcard" hidden></label></div>
        <p class="small-note">On iPhone/Safari, export contacts to a .vcf file from Contacts and choose that file here. Browsers with native contact selection offer a direct picker.</p>
        <p class="small-note">Only contacts you select and explicitly import are saved to Honestly Zen Event Planning. Invitations are not sent automatically.</p>
        ${people.length?`<div class="phone-contacts-controls"><label class="field"><span>Search contacts</span><input id="phoneContactsSearch" type="search" placeholder="Search by name, email or phone" value="${esc(search)}"></label>
          <button type="button" class="btn tiny" data-phone-action="all">Select nonduplicates</button><button type="button" class="btn tiny" data-phone-action="none">Clear selection</button></div>
          <div class="phone-contacts-list" id="phoneContactsList" role="group" aria-label="Review contacts"></div>
          <p id="contactsSelected" class="tiny-note" aria-live="polite"></p>`:''}
        <div class="modal-actions"><button type="button" class="btn" data-phone-action="close">Cancel</button><button type="button" class="btn primary" data-phone-action="import" ${people.some(p=>p.selected)?'':'disabled'}>Import selected guests</button></div>
      </div></section></div>`;
    rows();
  }
  async function choose(){
    if(!picker()){toast('Use a .vcf contact file on this browser');return}
    try{
      const result=await navigator.contacts.select(['name','email','tel'],{multiple:true});
      load(result.map(c=>({name:c.name?.[0]||'',email:c.email?.[0]||'',phone:c.tel?.[0]||''})));
    }catch(e){if(e?.name!=='AbortError')toast('Contact picker unavailable. Try a .vcf file.')}
  }
  async function importing(){
    if(busy||!selected().length)return;
    if(state.ws?.id!==workspaceId||state.eventId!==eventId){toast('Event changed; reopen importer');return}
    const chosen=selected();
    if(!confirm('Import '+chosen.length+' selected contacts as event guests? No invitations will be sent.'))return;
    busy=true;count();
    try{
      const result=await api(evpath()+'/guests/import',{method:'POST',body:chosen.map(p=>({
        name:p.name,email:p.email,phone:p.phone,party_size:p.party_size,group_name:'Phone contacts',rsvp:'Pending'
      }))});
      root().innerHTML='';people=[];toast(result.imported+' guests imported. No messages sent.');await refresh();
    }catch(e){toast('Import failed: '+e.message)}
    finally{busy=false;count()}
  }
  const close=()=>{people=[];search='';if(root())root().innerHTML=''};
  window.openPhoneContactImport=()=>{
    if(state.page!=='guests'||!state.eventId)return;
    if(state.ws?.role==='viewer'){toast('Only workspace editors can import guests');return}
    eventId=state.eventId;workspaceId=state.ws.id;people=[];search='';busy=false;render();
  };
  document.addEventListener('click',async e=>{
    const b=e.target.closest('[data-phone-action]');
    if(!b||!b.closest('.phone-contacts-modal'))return;
    if(b.dataset.phoneAction==='close')close();
    else if(b.dataset.phoneAction==='picker')await choose();
    else if(b.dataset.phoneAction==='all'){people.forEach(p=>p.selected=!p.duplicate);rows()}
    else if(b.dataset.phoneAction==='none'){people.forEach(p=>p.selected=false);rows()}
    else if(b.dataset.phoneAction==='import')await importing();
  });
  document.addEventListener('input',e=>{
    if(!e.target.closest('.phone-contacts-modal'))return;
    if(e.target.id==='phoneContactsSearch'){search=e.target.value;rows()}
    if(e.target.matches('[data-phone-seats]')){
      const p=people[Number(e.target.dataset.phoneSeats)],n=Number(e.target.value);
      if(p&&Number.isInteger(n)&&n>=1&&n<=10000)p.party_size=n;
    }
  });
  document.addEventListener('change',async e=>{
    if(!e.target.closest('.phone-contacts-modal'))return;
    if(e.target.id==='phoneContactsFile'){
      const file=e.target.files?.[0];if(!file)return;
      try{
        if(file.size>5*1024*1024)throw Error('File must be under 5 MB');
        const loaded=parseVcf(await file.text());
        if(!loaded.length)throw Error('No contacts in the file');
        load(loaded);
      }catch(error){toast('Unable to read contacts: '+error.message)}
    }else if(e.target.matches('[data-phone-check]')){
      const p=people[Number(e.target.dataset.phoneCheck)];
      if(p)p.selected=e.target.checked;count();
    }else if(e.target.matches('[data-phone-seats]')){
      const p=people[Number(e.target.dataset.phoneSeats)],n=Number(e.target.value);
      if(!p)return;
      if(!Number.isInteger(n)||n<1||n>10000){e.target.value=p.party_size;toast('Seats must be between 1 and 10,000')}
      else p.party_size=n;
    }
  });
})();