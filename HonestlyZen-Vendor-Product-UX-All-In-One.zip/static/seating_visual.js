/* Honestly Zen Event Planning visual seating floor-plan: pointer dragging, tap-to-assign and persisted table layout. */
'use strict';
(function(){
var selected=null,session=null;
const h=x=>String(x??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[k]));
const data=()=>state.operations||{guests:[],tables:[]};
const selectedGuest=()=>data().guests.find(g=>g.id===selected);
const floorElements=()=>data().floor_elements||[];
const marker=(id)=>floorElements().find(x=>x.id===id);
const repaint=()=>{if(state.page==='operations'&&state.opsTab==='seating')window.render()};
const apiBase=()=>evpath()+'/seating/floor';
function markerNode(m,edit){
 const kind=['stage','entrance','dancefloor','custom'].includes(m.kind)?m.kind:'custom';
 return '<div class="floor-marker '+kind+(m.visible?'':' floor-hidden')+'" data-floor-marker="'+h(m.id)+'" style="left:'+Number(m.pos_x)+'%;top:'+Number(m.pos_y)+'%;width:'+Number(m.width)+'%;height:'+Number(m.height)+'%" role="img" aria-label="'+h(m.label)+'">'+
 '<span class="floor-marker-name">'+h(m.label)+'</span>'+
 (edit?'<button class="floor-marker-handle" type="button" data-floor-marker-handle="'+h(m.id)+'" title="Drag to reposition '+h(m.label)+'" aria-label="Drag '+h(m.label)+'">⠿</button>':'')+
 '</div>';
}
function markerRow(m,edit){
 return '<div class="floor-marker-row" data-floor-marker-row="'+h(m.id)+'"><strong>'+h(m.kind==='dancefloor'?'Dance floor':m.kind[0].toUpperCase()+m.kind.slice(1))+'</strong>'+
 (edit?'<label>Label<input type="text" data-marker-label="'+h(m.id)+'" maxlength="50" value="'+h(m.label)+'"></label>'+
 '<label>Width %<input type="number" data-marker-width="'+h(m.id)+'" min="7" max="75" step="1" value="'+Number(m.width)+'"></label>'+
 '<label>Height %<input type="number" data-marker-height="'+h(m.id)+'" min="5" max="55" step="1" value="'+Number(m.height)+'"></label>'+
 '<label class="floor-marker-check"><input type="checkbox" data-marker-visible="'+h(m.id)+'" '+(m.visible?'checked':'')+'> Show</label>'+
 '<button type="button" class="btn tiny" onclick="opsFloorSaveMarker(\''+h(m.id)+'\')">Apply</button>'+
 '<select aria-label="Move '+h(m.label)+' to venue edge" onchange="opsFloorPlaceMarker(\''+h(m.id)+'\',this.value);this.selectedIndex=0">'+
 '<option value="">Position…</option><option value="top">Top</option><option value="bottom">Bottom</option><option value="left">Left</option><option value="right">Right</option><option value="center">Center</option></select>'+
 (m.kind==='custom'?'<button type="button" class="btn tiny danger" onclick="opsFloorRemoveMarker(\''+h(m.id)+'\')">Delete</button>':''):
 '<span class="floor-marker-note">'+(m.visible?'Visible':'Hidden')+'</span>')+
 '</div>';
}

function tableNode(t,edit){
 var pct=Math.min(100,Math.round(t.allocated*100/t.capacity));
 var names=data().guests.filter(g=>g.table_id===t.id).map(g=>g.name);
 var shape=t.shape==='rectangle'?'rectangle':'round';
 var pos_x=Number(t.pos_x??50),pos_y=Number(t.pos_y??50);
 return '<div class="floor-table '+shape+(t.allocated>=t.capacity?' full':'')+'" data-floor-table="'+h(t.id)+'" role="button" tabindex="0" aria-label="'+h(t.name)+'; '+t.allocated+' of '+t.capacity+' seats; tap to assign selected guest" style="left:'+pos_x+'%;top:'+pos_y+'%;--usage:'+pct+'%">'+
 (edit?'<div class="floor-grip" data-floor-handle="'+h(t.id)+'" title="Drag to move table" aria-label="Move table">⠿</div>':'')+
 '<div class="floor-table-content"><span class="floor-table-label">'+h(t.name)+'</span><strong>'+t.allocated+'/'+t.capacity+'</strong><small>'+h(names.slice(0,2).join(' · '))+'</small></div>'+
 '</div>';
}
function render(d,canEdit){
 var tables=d.tables||[],guests=d.guests||[];
 var selectedRow=guests.find(g=>g.id===selected);
 var markers=d.floor_elements||[];
 var unassigned=guests.filter(g=>g.rsvp==='Confirmed'&&!g.table_id);
 var assigned=guests.filter(g=>g.table_id);
 var seated=assigned.reduce((sum,g)=>sum+Number(g.seats||0),0);
 var capacity=tables.reduce((sum,t)=>sum+Number(t.capacity||0),0);
 return '<section class="floor-workspace">'+
 '<div class="floor-topline"><div><div class="floor-eyebrow">SEATING STUDIO</div><h2>Reception floor plan</h2><p>Arrange your tables and venue landmarks, then download a printable guest seating chart. Drag markers or use their position presets.</p></div>'+
 '<div class="floor-top-metrics"><span><strong>'+tables.length+'</strong> tables</span><span><strong>'+seated+'</strong> assigned seats</span><span><strong>'+capacity+'</strong> total seats</span></div></div>'+
 (canEdit?'<form class="floor-toolbar" onsubmit="opsAddTable(event)"><label>New table <input name="name" required maxlength="80" placeholder="Table name"></label><label>Seats <input name="capacity" type="number" min="1" max="500" value="8" required></label><label>Shape <select name="shape" aria-label="New table shape"><option value="round">Round</option><option value="rectangle">Rectangular</option></select></label><button class="btn primary" type="submit">+ Add table</button></form>':'')+
 '<div class="floor-print-toolbar"><div><strong>Guest-facing seating chart</strong><p>'+unassigned.length+' confirmed invitation groups still unassigned. PDFs include table layout and an alphabetical name index.</p></div>'+
 '<a class="btn primary" download="eventos-seating-chart.pdf" href="/api'+evpath()+'/seating/chart.pdf">↓ Download A3 seating chart (PDF)</a>'+
 '<button class="btn" type="button" onclick="opsFloorPrint()">Print guest directory</button></div>'+
 '<div class="floor-shell">'+
 '<aside class="floor-guests"><div class="floor-sidebar-head"><h3>Guest groups</h3><span>'+guests.length+' invitations</span></div>'+
 '<p class="floor-hint">'+(selectedRow?'Selected: '+h(selectedRow.name)+'. Tap a table to assign.':'Drag a card or tap to choose a guest.')+'</p>'+
 '<div class="floor-guest-list">'+guests.map(g=>'<div role="button" tabindex="0" class="floor-person'+(g.id===selected?' is-selected':'')+(g.rsvp==='Declined'?' is-declined':'')+'" data-floor-guest="'+h(g.id)+'" aria-label="Select '+h(g.name)+'; '+g.seats+' seats">'+
 '<div class="floor-person-avatar">'+h(g.name.slice(0,1).toUpperCase())+'</div><div class="floor-person-info"><strong>'+h(g.name)+'</strong><small>'+h(g.group_name||g.category||g.rsvp)+' · '+h(g.table_name||'Unassigned')+'</small></div><span class="floor-seats">'+g.seats+' seats</span></div>').join('')+
 '</div><p class="tiny-note">Table capacity is checked when assignments are saved. Guests who decline can be left unassigned.</p></aside>'+
 '<div class="floor-stage-column"><div class="floor-stage-header"><span>VENUE MAP</span><span>Move tables by the ⠿ handle</span></div>'+
 '<div class="floor-stage" id="floorStage">'+markers.filter(m=>m.visible).map(m=>markerNode(m,canEdit)).join('')+
 tables.map(t=>tableNode(t,canEdit)).join('')+
 (!tables.length?'<div class="floor-empty">Add your first table to begin arranging your venue.</div>':'')+'</div>'+
 '<div class="floor-legend"><span>◯ Round</span><span>▭ Rectangular</span><span>⠿ Drag table or venue features</span><span>Tap guest, then table</span></div>'+
 '<div class="floor-table-controls">'+tables.map(t=>'<div class="floor-control"><strong>'+h(t.name)+'</strong><span>'+t.allocated+' / '+t.capacity+' seats</span>'+
 (canEdit?'<select aria-label="Table shape" onchange="opsFloorShape('+"'"+t.id+"'"+',this.value)"><option value="round"'+(t.shape==='rectangle'?'':' selected')+'>Round</option><option value="rectangle"'+(t.shape==='rectangle'?' selected':'')+'>Rectangular</option></select>'+
 '<button type="button" class="btn tiny" onclick="opsFloorUnassign('+"'"+t.id+"'"+')">Clear table</button>'+
 '<button type="button" class="btn tiny danger" onclick="opsDeleteTable('+"'"+t.id+"'"+')">Delete</button>':'')+'</div>').join('')+
 '</div>'+
 '<section class="floor-feature-settings"><div class="floor-settings-title"><h3>Customize your floor plan</h3><p>Move the stage, entrance and dance floor to any side. Hide, resize and rename them, or add a buffet, DJ, bar or photo booth marker.</p></div>'+
 '<div class="floor-marker-list">'+markers.map(m=>markerRow(m,canEdit)).join('')+'</div>'+
 (canEdit?'<form class="floor-add-marker" onsubmit="opsFloorAddMarker(event)"><label>New venue feature <input name="label" maxlength="50" required placeholder="Buffet / Bar / Photo booth"></label><button class="btn" type="submit">+ Add feature</button></form>':'')+
 '</section></div></div>'+
 '<p class="floor-footer-note">Table shapes, positions, venue features and seating are saved to the event. Download the PDF for your welcome desk or print it for guest wayfinding.</p></section>';
}
async function saveLayout(id,x,y,shape){
 try{await api(evpath()+'/tables/'+id+'/layout',{method:'PUT',body:{x,y,shape}});
 const target=data().tables.find(t=>t.id===id);if(target){target.pos_x=x;target.pos_y=y;target.shape=shape}
 toast('Floor plan saved');return true;
 }catch(e){toast(e.message);await window.EventOSOperations.refresh();return false}
}
window.opsFloorShape=(id,shape)=>{
 const t=data().tables.find(t=>t.id===id);if(!t)return;
 saveLayout(id,Number(t.pos_x??50),Number(t.pos_y??50),shape).then(ok=>{if(ok)repaint()});
};
function markerPayload(m,changes={}){
 return {label:changes.label??m.label,x:changes.x??Number(m.pos_x),y:changes.y??Number(m.pos_y),
  width:changes.width??Number(m.width),height:changes.height??Number(m.height),
  visible:changes.visible??Boolean(m.visible)};
}
window.opsFloorUpdateMarker=async(id,changes)=>{
 const m=marker(id);if(!m)return;
 const body=markerPayload(m,changes);
 try{
  const saved=await api(apiBase()+'/'+encodeURIComponent(id),{method:'PUT',body});
  Object.assign(m,{label:saved.label,pos_x:saved.pos_x,pos_y:saved.pos_y,
   width:saved.width,height:saved.height,visible:saved.visible});
  repaint();toast('Venue feature updated');
 }catch(e){toast(e.message);await window.EventOSOperations.refresh()}
};
window.opsFloorSaveMarker=id=>{
 const m=marker(id);if(!m)return;
 const by=type=>document.querySelector('[data-marker-'+type+'="'+id+'"]');
 const width=Number(by('width')?.value),height=Number(by('height')?.value);
 window.opsFloorUpdateMarker(id,{label:by('label')?.value||m.label,width,height,visible:by('visible')?.checked??Boolean(m.visible)});
};
window.opsFloorPlaceMarker=(id,side)=>{
 const p={top:{x:50,y:10},bottom:{x:50,y:90},left:{x:13,y:50},right:{x:87,y:50},center:{x:50,y:50}}[side];
 if(p)window.opsFloorUpdateMarker(id,p);
};
window.opsFloorAddMarker=async e=>{
 e.preventDefault();
 const label=String(new FormData(e.target).get('label')||'').trim();
 if(!label)return;
 try{
  const m=await api(apiBase(),{method:'POST',body:{label}});
  data().floor_elements.push(m);
  repaint();toast('Venue feature added; drag it to position');
 }catch(error){toast(error.message)}
};
window.opsFloorRemoveMarker=async id=>{
 const m=marker(id);
 if(!m||m.kind!=='custom'||!confirm('Remove this floor feature?'))return;
 try{
  await api(apiBase()+'/'+encodeURIComponent(id),{method:'DELETE'});
  data().floor_elements=data().floor_elements.filter(x=>x.id!==id);
  repaint();toast('Venue feature removed');
 }catch(error){toast(error.message)}
};
window.opsFloorPrint=()=>{window.open('/api'+evpath()+'/seating/chart.pdf?inline=true','_blank','noopener,noreferrer')};
window.opsFloorUnassign=id=>{
 const names=data().guests.filter(g=>g.table_id===id);
 if(!names.length){toast('No assignments to clear');return}
 if(!confirm('Remove '+names.length+' guest group(s) from this table?'))return;
 Promise.all(names.map(g=>api(evpath()+'/seating/'+g.id,{method:'PUT',body:{table_id:null}}))).then(()=>window.EventOSOperations.refresh()).catch(e=>toast(e.message));
};
function choose(id){
 selected=id;
 document.querySelectorAll('.floor-person').forEach(n=>n.classList.toggle('is-selected',n.dataset.floorGuest===id));
 const name=data().guests.find(g=>g.id===id)?.name||'';
 const el=document.querySelector('.floor-hint');if(el)el.textContent='Selected: '+name+'. Tap a table to assign.';
}
const down=e=>{
 if(state.page!=='operations'||state.opsTab!=='seating'||data().role==='viewer')return;
 const grip=e.target.closest('[data-floor-handle]');
 const markerGrip=e.target.closest('[data-floor-marker-handle]');
 const person=e.target.closest('[data-floor-guest]');
 if(!grip&&!person&&!markerGrip)return;
 if(e.button!==undefined&&e.button!==0)return;
 const isTable=!!grip,isMarker=!!markerGrip,
 node=isTable?grip.closest('[data-floor-table]'):isMarker?markerGrip.closest('[data-floor-marker]'):person,
 id=isTable?grip.dataset.floorHandle:isMarker?markerGrip.dataset.floorMarkerHandle:person.dataset.floorGuest;
 const rect=document.getElementById('floorStage')?.getBoundingClientRect();
 session={type:isTable?'table':isMarker?'marker':'guest',node,id,rect,x:e.clientX,y:e.clientY,
 startLeft:parseFloat(node.style.left)||0,startTop:parseFloat(node.style.top)||0,drag:false,pointerId:e.pointerId};
 if(e.pointerType==='touch')e.preventDefault();
};
const move=e=>{
 if(!session||e.pointerId!==session.pointerId)return;
 const dx=e.clientX-session.x,dy=e.clientY-session.y;
 if(Math.abs(dx)+Math.abs(dy)>7)session.drag=true;
 if(!session.drag)return;
 e.preventDefault();
 if((session.type==='table'||session.type==='marker')&&session.rect){
 const x=Math.min(94,Math.max(6,session.startLeft+dx/session.rect.width*100));
 const y=Math.min(94,Math.max(6,session.startTop+dy/session.rect.height*100));
 session.node.style.left=x.toFixed(2)+'%';session.node.style.top=y.toFixed(2)+'%';
 }else{
 let ghost=document.getElementById('floorGhost');
 if(!ghost){ghost=document.createElement('div');ghost.id='floorGhost';ghost.className='floor-ghost';ghost.textContent=data().guests.find(g=>g.id===session.id)?.name||'Guest';document.body.append(ghost)}
 ghost.style.left=e.clientX+14+'px';ghost.style.top=e.clientY+14+'px';
 document.querySelectorAll('[data-floor-table]').forEach(el=>el.classList.remove('drop-target'));
 const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-floor-table]');
 if(target)target.classList.add('drop-target');
 }
};
const up=e=>{
 if(!session||e.pointerId!==session.pointerId)return;
 const cur=session;session=null;
 document.getElementById('floorGhost')?.remove();
 document.querySelectorAll('[data-floor-table]').forEach(el=>el.classList.remove('drop-target'));
 if(cur.type==='table'&&cur.drag){
 const t=data().tables.find(x=>x.id===cur.id);if(!t)return;
 saveLayout(cur.id,parseFloat(cur.node.style.left),parseFloat(cur.node.style.top),t.shape||'round');return;
 }
 if(cur.type==='marker'&&cur.drag){
 window.opsFloorUpdateMarker(cur.id,{x:parseFloat(cur.node.style.left),y:parseFloat(cur.node.style.top)});return;
 }
 if(cur.type==='guest'){
 choose(cur.id);
 if(cur.drag){
 const node=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-floor-table]');
 if(node)window.opsSeat(cur.id,node.dataset.floorTable);
 }
 }
};
document.addEventListener('pointerdown',down);
document.addEventListener('pointermove',move,{passive:false});
document.addEventListener('pointerup',up);
document.addEventListener('pointercancel',()=>{session=null;document.getElementById('floorGhost')?.remove()});
document.addEventListener('click',e=>{
 if(e.target.closest('[data-floor-handle],[data-floor-marker-handle]'))return;
 const t=e.target.closest('[data-floor-table]');if(!t||state.page!=='operations'||state.opsTab!=='seating')return;
 if(session||!selected||data().role==='viewer')return;
 const guest=selectedGuest(),table=data().tables.find(x=>x.id===t.dataset.floorTable);
 if(!guest||!table||guest.table_id===table.id)return;
 window.opsSeat(guest.id,table.id);selected=null;
});
document.addEventListener('keydown',e=>{
 if((e.key==='Enter'||e.key===' ')&&e.target?.matches('[data-floor-guest]')){e.preventDefault();choose(e.target.dataset.floorGuest)}
 if((e.key==='Enter'||e.key===' ')&&e.target?.matches('[data-floor-table]')){e.preventDefault();e.target.click()}
});
window.EventOSSeating={render};
})();