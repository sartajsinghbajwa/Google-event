/* Honestly Zen Event Planning Event Operations — Phase 5 and 6 UI */
'use strict';
(function(){
const h=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ops=()=>state.operations||{guests:[],tables:[],metrics:{},role:'viewer'};
const msg=()=>state.opsMessages||{messages:[]};
const canEdit=()=>ops().role!=='viewer';
const route=()=>evpath();
let scanning=null;
function stop(){if(scanning){scanning.active=false;scanning.stream.getTracks().forEach(t=>t.stop());scanning=null}let video=document.getElementById('opsCamera');if(video){video.srcObject=null;video.hidden=true}}
const kpi=(label,value)=>'<div class="card pad"><p class="tiny-note">'+h(label)+'</p><strong class="ops-big">'+h(value)+'</strong></div>';
const b=(label,action)=>'<button class="btn" type="button" onclick="'+action+'">'+h(label)+'</button>';
const options=(items,current)=>items.map(x=>'<option value="'+h(x[0])+'" '+(x[0]===current?'selected':'')+'>'+h(x[1])+'</option>').join('');
function totals(){let m=ops().metrics||{};return '<div class="ops-kpis">'+[
 ['Invitations',m.invitations],['Confirmed attendees',m.confirmed_attendees],['Checked in',m.checked_in],
 ['Still expected',m.remaining],['Pending RSVPs',m.pending],['Provider-accepted emails',(m.messages||{}).sent]
].map(x=>kpi(x[0],x[1]||0)).join('')+'</div>'}
function overview(){let d=ops(),m=d.metrics||{},unseated=(d.guests||[]).filter(g=>g.rsvp==='Confirmed'&&!g.table_id);
return '<div class="grid two-col"><section class="card pad"><h2>Event-day readiness</h2>'+
'<div class="attention-row"><span>Confirmed guests without table assignments</span><strong>'+unseated.length+'</strong></div>'+
'<div class="attention-row"><span>Seated invitations</span><strong>'+h(m.seated||0)+'</strong></div>'+
'<div class="attention-row"><span>Arrived attendees</span><strong>'+h(m.checked_in||0)+'</strong></div>'+
b('Open check-in',"opsTab('checkin')")+'</section>'+
'<section class="card pad"><h2>Messaging setup</h2><p class="small-note">Email delivery requires your SMTP provider credentials. WhatsApp links open a draft that you send yourself; opening is not proof of delivery.</p>'+
'<div class="attention-row"><span>SMTP configured</span><strong>'+(d.email_configured?'Yes':'No')+'</strong></div>'+
'<div class="attention-row"><span>Scheduled delivery</span><strong>'+(d.cron_configured?'Job token present (external scheduler required)':'Not configured')+'</strong></div>'+
b('Prepare messages',"opsTab('messages')")+'</section></div>'+
'<section class="card pad m-top"><h2>Reports</h2><p class="small-note">Export seating, RSVP, and event-day check-ins for your records.</p>'+
b('Download event report',"location.href='/api'+evpath()+'/report.csv'")+'</section>'}
function seating(){let d=ops();if(window.EventOSSeating)return window.EventOSSeating.render(d,canEdit());return '<section class="card pad"><h2>Seating planner</h2><p class="small-note">Each table has a maximum seat capacity. Assign whole invitation groups to tables.</p>'+
(canEdit()?'<form class="ops-form-row" onsubmit="opsAddTable(event)"><input name="name" placeholder="Table name" maxlength="80" required aria-label="Table name"><input name="capacity" type="number" min="1" max="500" value="8" required aria-label="Table capacity"><button class="btn primary" type="submit">Add table</button></form>':'')+
'<div class="ops-tables">'+(d.tables||[]).map(t=>'<div class="ops-table-chip"><strong>'+h(t.name)+'</strong> '+t.allocated+' / '+t.capacity+' seats '+(canEdit()?b('Delete',"opsDeleteTable('"+t.id+"')"):'')+'</div>').join('')+'</div>'+
'<div class="table-wrap"><table class="table"><thead><tr><th>Invitation</th><th>RSVP</th><th>Seats</th><th>Table</th></tr></thead><tbody>'+
(d.guests||[]).map(g=>'<tr><td><strong>'+h(g.name)+'</strong><div class="tiny-note">'+h(g.group_name)+'</div></td><td>'+h(g.rsvp)+'</td><td>'+h(g.seats)+'</td><td>'+
'<select class="select" aria-label="Table for '+h(g.name)+'" '+(canEdit()?'':'disabled')+' onchange="opsSeat('+"'"+g.id+"'"+',this.value)">'+options([['','Unassigned']].concat((d.tables||[]).map(t=>[t.id,t.name+' ('+t.allocated+'/'+t.capacity+')'])),g.table_id||'')+'</select></td></tr>').join('')+
'</tbody></table></div></section>'}
function checkin(){let gs=ops().guests||[];return '<section class="card pad"><h2>Check-in desk</h2><p class="small-note">Only signed-in owners and editors may record check-ins. Guests can display their own QR pass after confirming attendance.</p>'+
(canEdit()?'<div class="ops-form-row">'+b('Scan QR code',"opsScan()")+b('Stop camera',"opsStop()")+
'<form onsubmit="opsLookup(event)"><input type="text" name="code" placeholder="QR code or check-in URL" required aria-label="Check-in code"><button class="btn primary" type="submit">Look up</button></form></div><video id="opsCamera" playsinline autoplay muted hidden></video>':'')+
'<div class="table-wrap"><table class="table"><thead><tr><th>Guest</th><th>Attending</th><th>Status</th><th>QR pass</th><th>Action</th></tr></thead><tbody>'+
gs.map(g=>'<tr><td><strong>'+h(g.name)+'</strong><div class="tiny-note">'+h(g.table_name||'Unassigned')+'</div></td><td>'+h(g.attending)+'</td><td>'+(g.checked_in_at?'Checked in '+h(g.checked_in_at.slice(0,16)):'Not arrived')+'</td><td>'+(g.rsvp==='Confirmed'?b('Show QR',"opsQr('"+g.id+"')"):'—')+'</td><td>'+
(g.checked_in_at?(canEdit()?b('Undo',"opsUndo('"+g.id+"')"):'—'):g.rsvp==='Confirmed'&&canEdit()?b('Check in',"opsCheckin('"+g.id+"')"):'—')+
'</td></tr>').join('')+'</tbody></table></div></section>'}
function messages(){let d=ops(),history=msg().messages||[],targets=state.opsTargets||new Set();
let form=canEdit()?'<section class="card pad"><h2>Prepare messages</h2><p class="small-note">Select up to 25 guests per batch. Draft WhatsApp sharing is manual. Sending emails requires SMTP setup and confirmation.</p>'+
'<form onsubmit="opsCompose(event)" id="opsComposer">'+
'<label class="field"><span>Channel</span><select name="channel">'+options([['whatsapp','WhatsApp manual share'],['email','Email (configured SMTP)']],'whatsapp')+'</select></label>'+
'<label class="field"><span>Message type</span><select name="kind">'+options([['invitation','Invitation'],['reminder','RSVP reminder'],['announcement','Event update'],['confirmation','RSVP confirmation']],'invitation')+'</select></label>'+
'<label class="field"><span>Subject (optional)</span><input name="subject" maxlength="160" placeholder="Invitation to {event}"></label>'+
'<label class="field"><span>Message (optional)</span><textarea name="body" rows="4" maxlength="2000" placeholder="Hello {guest}, please RSVP here: {link}"></textarea></label>'+
'<p class="tiny-note">Leave blank to use the default message. Placeholders: {guest}, {event}, {date}, {link}.</p>'+
'<label class="field"><span>Schedule email (optional, local date/time)</span><input type="datetime-local" name="schedule_at"></label>'+
'<div class="ops-recipients"><strong>Recipients ('+targets.size+' selected)</strong>'+
(d.guests||[]).map(g=>'<label><input type="checkbox" data-ops-guest="'+g.id+'" '+(targets.has(g.id)?'checked':'')+' onchange="opsTarget('+"'"+g.id+"'"+',this.checked)"> '+h(g.name)+' · '+h(g.rsvp)+'<small> · '+h(g.email||g.phone||'No contact')+'</small></label>').join('')+'</div>'+
'<button class="btn primary" type="submit">Prepare selected messages</button></form>'+
'<p class="tiny-note">SMTP: '+(d.email_configured?'configured':'not configured')+'. Scheduled delivery: '+(d.cron_configured?'external job still required':'disabled')+'.</p></section>':'';
return '<div class="grid two-col">'+form+'<section class="card pad"><h2>Message log</h2><p class="small-note">“Prepared” is not delivered. “Opened” means only the WhatsApp link was opened. “Sent” means SMTP accepted the email, not that it was read.</p>'+
history.map(m=>'<div class="ops-message"><strong>'+h(m.guest_name)+' · '+h(m.kind)+'</strong><div class="tiny-note">'+h(m.channel)+' · '+h(m.status)+' '+h(m.sent_at||'')+'</div>'+
(m.error?'<p class="tiny-note">'+h(m.error)+'</p>':'')+
(canEdit()&&m.channel==='email'&&['prepared','failed'].includes(m.status)?b('Send email',"opsSend('"+m.id+"')"):'')+
(canEdit()&&m.channel==='whatsapp'&&m.share_url?'<button class="btn tiny" data-share="'+h(m.id)+'" type="button">Open WhatsApp</button>':'')+'</div>').join('')+
'</section></div>'}
function renderEventOperations(){
const selected=state.opsTab||'overview';
return head('Event operations','Messaging, seating, check-in and event-day reporting',button('Export CSV',"location.href='/api'+evpath()+'/report.csv'",false))+
totals()+'<div class="ops-nav">'+[['overview','Overview'],['seating','Seating'],['checkin','Check-in'],['messages','Messages'],['guest','Guest Experience']].map(t=>
'<button type="button" class="btn '+(selected===t[0]?'primary':'')+'" onclick="opsTab('+"'"+t[0]+"'"+')">'+t[1]+'</button>').join('')+'</div>'+
(selected==='seating'?seating():selected==='checkin'?checkin():selected==='messages'?messages():selected==='guest'?window.EventOSGuestStudio?.render()||'<section class="card pad">Guest Experience Studio unavailable</section>':overview())}
async function refreshOps(){stop();state.operations=await api(route()+'/operations');state.opsMessages=await api(route()+'/messages');render()}
async function change(work,notice){try{await work();if(notice)toast(notice);await refreshOps()}catch(e){toast(e.message)}}
window.opsTab=t=>{stop();state.opsTab=t;if(t==='guest')window.EventOSGuestStudio?.load();else render()};
window.opsAddTable=ev=>{
 ev.preventDefault();const form=new FormData(ev.target),shape=form.get('shape')||'round';
 change(async()=>{
  const table=await api(route()+'/tables',{method:'POST',body:{name:form.get('name'),capacity:Number(form.get('capacity'))}});
  if(shape==='rectangle')await api(route()+'/tables/'+table.id+'/layout',{method:'PUT',
   body:{x:table.pos_x,y:table.pos_y,shape:'rectangle'}});
 },'Table added');
};
window.opsDeleteTable=id=>{if(confirm('Delete this table and remove its assignments?'))change(()=>api(route()+'/tables/'+id,{method:'DELETE'}),'Table removed')};
window.opsSeat=(id,table)=>change(()=>api(route()+'/seating/'+id,{method:'PUT',body:{table_id:table||null}}),'Seating updated');
window.opsQr=id=>{const url='/api'+route()+'/guests/'+encodeURIComponent(id)+'/checkin-qr.png';window.open(url,'_blank','noopener,noreferrer')};
window.opsCheckin=id=>{let g=ops().guests.find(x=>x.id===id);if(!g||!confirm('Check in '+g.name+' ('+g.attending+' attending)?'))return;change(()=>api(route()+'/checkins/'+id,{method:'POST'}),'Guest checked in')};
window.opsUndo=id=>{if(confirm('Undo this check-in?'))change(()=>api(route()+'/checkins/'+id,{method:'DELETE'}),'Check-in undone')};
window.opsTarget=(id,on)=>{if(!state.opsTargets)state.opsTargets=new Set();on?state.opsTargets.add(id):state.opsTargets.delete(id);let label=document.querySelector('.ops-recipients strong');if(label)label.textContent='Recipients ('+state.opsTargets.size+' selected)'};
window.opsCompose=async ev=>{ev.preventDefault();let f=new FormData(ev.target),ids=[...(state.opsTargets||[])];if(!ids.length||ids.length>25){toast('Select 1–25 guests');return}let channel=String(f.get('channel')),kind=String(f.get('kind'));if(!confirm('Prepare '+ids.length+' '+channel+' messages? This does not automatically send them.'))return;
let payload={guest_ids:ids,channel,kind,subject:String(f.get('subject')||''),body:String(f.get('body')||'')},when=String(f.get('schedule_at')||'');
if(when){let d=new Date(when);if(Number.isNaN(d.getTime())){toast('Choose valid scheduling date');return}payload.schedule_at=d.toISOString()}
try{let output=await api(route()+'/messages',{method:'POST',body:payload});state.opsTargets=new Set();await refreshOps();toast(output.created.length+' messages prepared. Open the log to send or share.') }catch(e){toast(e.message)}};
window.opsSend=id=>{if(confirm('Send this prepared email through your configured SMTP provider?'))change(async()=>{let x=await api(route()+'/messages/'+id+'/send',{method:'POST'});if(!x.ok)throw Error('Email delivery failed; review message log')},'Email accepted by provider')};
window.opsLookup=ev=>{ev.preventDefault();let input=String(new FormData(ev.target).get('code')||''),code=input.split('/checkin/').pop().split(/[?#]/)[0];if(code)opsLookupCode(code);else toast('Enter a check-in code or URL')};
window.opsLookupCode=async code=>{stop();try{let guest=await api('/checkin/'+encodeURIComponent(code));if(guest.checked_in_at){toast('Guest already checked in');return}if(guest.rsvp!=='Confirmed'){toast('Guest must confirm RSVP first');return}if(!confirm('Check in '+guest.guest_name+' ('+guest.attending+' attendees)?'))return;await api('/checkin/'+encodeURIComponent(code),{method:'POST'});toast('Guest checked in');await refreshOps()}catch(e){toast(e.message)}};
window.opsStop=stop;
window.opsScan=async()=>{
if(!window.BarcodeDetector||!navigator.mediaDevices?.getUserMedia){toast('Use the phone camera to open a QR pass or enter the code; in-page scanning is unavailable on this browser.');return}
try{stop();let stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false}),video=document.getElementById('opsCamera');if(!video){stream.getTracks().forEach(x=>x.stop());return}video.hidden=false;video.srcObject=stream;await video.play();
let detector=new BarcodeDetector({formats:['qr_code']}),session={stream,active:true};scanning=session;
let loop=async()=>{if(!session.active)return;try{let found=await detector.detect(video);if(found.length){let raw=String(found[0].rawValue||''),code=raw.includes('/checkin/')?raw.split('/checkin/').pop().split(/[?#]/)[0]:'';if(code){stop();opsLookupCode(code);return}}}catch(e){}if(session.active)requestAnimationFrame(loop)};
loop()}catch(e){stop();toast('Unable to access camera. Try using the phone camera or manual code.')}}
document.getElementById('app')?.addEventListener('click',ev=>{let btn=ev.target.closest('[data-share]');if(!btn)return;let item=(msg().messages||[]).find(m=>m.id===btn.dataset.share);if(!item?.share_url)return;window.open(item.share_url,'_blank','noopener,noreferrer');api(route()+'/messages/'+item.id+'/shared',{method:'POST'}).then(refreshOps).catch(e=>toast(e.message))});
window.EventOSOperations={render:renderEventOperations,stop:stop,refresh:refreshOps};
})();