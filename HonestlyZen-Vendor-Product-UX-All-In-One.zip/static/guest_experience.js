/* Honestly Zen Event Planning Phase 11 mobile guest hub and private welcome-desk seat finder.
 * No guest directory is sent to browsers. Every query is server-validated.
 */
'use strict';
(()=>{
 const root=document.getElementById('guestExperience');
 const path=location.pathname.split('/').filter(Boolean);
 const finder=path[0]==='seat-finder';
 const token=path[1]||'';
 const h=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const link=x=>h(x);
 let source=null;
 async function api(endpoint,body){
  const opts={method:body?'POST':'GET',credentials:'same-origin',headers:{'Accept':'application/json'}};
  if(body){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body)}
  const response=await fetch(endpoint,opts);
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw Error(typeof data.detail==='string'?data.detail:'Unable to load this page');
  return data;
 }
 function notice(message,good=false){
   const node=document.getElementById('geNotice');
   if(!node)return;
   node.hidden=false;
   node.textContent=message;
   node.className='ge-notice '+(good?'ge-ok':'ge-error');
 }
 function formatLocal(value){
   const str=String(value||'');
   if(!str.includes('T'))return str;
   const [day,time]=str.split('T');
   return day+' · '+time.slice(0,5);
 }
 function venueMap(floor,seat){
   const tables=Array.isArray(floor?.tables)?floor.tables:[];
   const markers=Array.isArray(floor?.markers)?floor.markers:[];
   const marker=markers.map(m=>'<div class="ge-landmark ge-'+h(m.kind)+
     '" style="left:'+Number(m.pos_x)+'%;top:'+Number(m.pos_y)+'%;width:'+Number(m.width)+'%;height:'+Number(m.height)+'%" title="'+h(m.label)+'">'+h(m.label)+'</div>').join('');
   const tableNodes=tables.map(t=>{
      const active=seat&&t.id===seat.id;
      const shape=t.shape==='rectangle'?'ge-rectangle':'ge-round';
      return '<div class="ge-table '+shape+(active?' ge-mine':'')+
       '" style="left:'+Number(t.pos_x)+'%;top:'+Number(t.pos_y)+'%"'+
       (active?' aria-label="Your table: '+h(t.name)+'"':' aria-hidden="true"')+'>'+
       (active?'<span class="ge-mine-dot">★</span>':'')+
       '<span>'+h(t.name)+'</span></div>';
   }).join('');
   return '<section class="ge-card ge-map-card"><div class="ge-section-head"><div><span class="ge-eyebrow">YOUR VENUE</span><h2>Find your table</h2></div>'+
     (seat?'<span class="ge-table-label">★ Your table highlighted</span>':'')+'</div>'+
     '<div class="ge-map" role="img" aria-label="'+h(seat?'Floor plan highlighting '+seat.name:'Event floor plan')+'">'+marker+tableNodes+
     (!tables.length?'<div class="ge-empty-map">Your organizer is finalizing the seating layout.</div>':'')+'</div>'+
     '<p class="ge-help">Map is indicative, not to scale. Please follow venue signs and staff directions.</p></section>';
 }
 function itinerary(data){
  if(!data.length)return '<p class="ge-muted">The organizer hasn’t published a program yet. Check back for updates.</p>';
  return '<div class="ge-program">'+data.map(item=>
     '<article class="ge-program-item"><div class="ge-program-time">'+h(formatLocal(item.start_at))+'</div>'+
     '<div><h3>'+h(item.title)+'</h3>'+(item.location?'<div class="ge-program-location">⌖ '+h(item.location)+'</div>':'')+
     (item.description?'<p>'+h(item.description)+'</p>':'')+'</div></article>').join('')+'</div>';
 }
 function updates(data){
   if(!data.length)return '<p class="ge-muted">No published updates yet.</p>';
   return data.map(item=>
      '<article class="ge-update '+(item.category==='important'?'ge-important':'')+'"><span class="ge-update-type">'+h(item.category==='transport'?'Travel':item.category==='important'?'Important':'Event news')+'</span>'+
      '<h3>'+h(item.title)+'</h3><p>'+h(item.body)+'</p><small>'+h(item.created_at?.slice(0,10)||'')+'</small></article>').join('');
 }
 function header(name,eyebrow){
  return '<header class="ge-header"><div class="ge-mark">✦</div><span class="ge-header-caption">'+h(eyebrow||'YOUR EVENT EXPERIENCE')+'</span>'+
    '<h1>'+h(name)+'</h1><div class="ge-header-sub">Everything you need to enjoy your event, in one place.</div></header>';
 }
 function guestScreen(data){
  const guest=data.invitation;
  const seat=data.seat;
  const confirmed=guest.rsvp==='Confirmed';
  const status=guest.checked_in?'Checked in':guest.rsvp==='Confirmed'?'RSVP confirmed':guest.rsvp==='Declined'?'Unable to attend':'Awaiting confirmation';
  return header(data.event.name,'PRIVATE GUEST PASS')+
   '<nav class="ge-quick"><a href="#geSeat">My seat</a><a href="#geProgram">Program</a><a href="#geUpdates">Updates</a></nav>'+
   '<section class="ge-card ge-pass"><div><span class="ge-eyebrow">ADMISSION PASS</span>'+
   '<h2>'+h(guest.name)+'</h2><p class="ge-status">'+h(status)+' · Invitation for '+h(guest.party_size)+' '+(guest.party_size===1?'person':'people')+'</p>'+
   '<p>'+h(data.event.start_date||'Date to be announced')+' · '+h(data.event.location||'Venue to be announced')+'</p>'+
   (confirmed?'<p class="ge-seat-large">'+(seat?'Table '+h(seat.name):'Your seat is being arranged')+'</p>':
     '<p class="ge-help">Confirm your attendance to access your check-in QR pass and assigned table.</p>')+
   '</div>'+(confirmed?'<div class="ge-pass-qr"><img src="/api/rsvp/'+encodeURIComponent(token)+'/checkin-qr.png" alt="Private QR pass for event staff to scan" loading="lazy"><small>Show to check-in staff<br>Scanning does not check you in automatically.</small></div>':'')+
   '</section>'+
   '<div class="ge-actions"><a href="/rsvp/'+encodeURIComponent(token)+'" class="ge-button ge-primary">Update my RSVP</a>'+
     '<a href="/api/guest/'+encodeURIComponent(token)+'/calendar.ics" class="ge-button" download>Add date to calendar</a>'+
     '<button type="button" class="ge-button" id="geShare">Copy private guest link</button>'+
     (confirmed?'<button type="button" class="ge-button" id="gePrintPass">Print / Save QR Pass</button>':'')+'</div>'+
   '<div id="geNotice" class="ge-notice" role="status" hidden></div>'+
   '<div id="geSeat">'+(confirmed?'<section class="ge-card ge-seat-info"><span class="ge-eyebrow">SEATING INFORMATION</span><h2>'+(seat?'You’re at '+h(seat.name):'Your table will appear here')+'</h2>'+
     '<p>'+(seat?'Find your highlighted table in the map below.':'Your host has not assigned a table yet. You can check this page again closer to the event.')+'</p></section>'+
     venueMap(data.floor,seat):'<section class="ge-card"><h2>Seating information</h2><p>Confirm your RSVP first to see your assigned table.</p></section>')+'</div>'+
   '<section class="ge-card" id="geProgram"><div class="ge-section-head"><div><span class="ge-eyebrow">PLAN YOUR DAY</span><h2>Personal event program</h2></div></div>'+itinerary(data.itinerary||[])+'</section>'+
   '<section class="ge-card" id="geUpdates"><div class="ge-section-head"><div><span class="ge-eyebrow">LATEST ANNOUNCEMENTS</span><h2>Event updates</h2></div></div>'+updates(data.updates||[])+'</section>'+
   '<footer class="ge-footer"><button class="ge-link" id="geRefresh" type="button">Refresh my event information ↻</button><p>Your invitation link is private. Share it only with your invited party.</p></footer>';
 }
 function finderStart(data){
    return header(data.event_name,'VENUE WELCOME DESK')+
     '<section class="ge-card ge-finder-intro"><span class="ge-eyebrow">FIND YOUR SEAT</span><h2>Where am I sitting?</h2>'+
     '<p>Enter the full name printed on your invitation and the venue PIN supplied by your host. We’ll highlight your assigned table.</p>'+
     '<form id="geFinderForm" class="ge-form"><label>Full invitation name<input name="name" required minlength="3" maxlength="160" autocomplete="name" placeholder="Example: Jordan Smith"></label>'+
     '<label>Venue access PIN<input name="pin" required minlength="6" maxlength="12" pattern="[0-9]{6,12}" inputmode="numeric" autocomplete="off" placeholder="6–12 digit PIN" type="password"></label>'+
     '<button type="submit" class="ge-button ge-primary">Find my table →</button></form><p class="ge-help">If your invitation name is shared by multiple groups, ask the welcome desk for assistance. Staff can find your seat without using this page.</p></section>'+
     '<div id="geNotice" class="ge-notice" role="status" hidden></div><div id="geFinderResult"></div>'+
     '<footer class="ge-footer">Only a matching invitation name and correct venue PIN can reveal a table assignment. Guest names, emails and contact details are not displayed.</footer>';
 }
 function bindGuest(){
  document.getElementById('gePrintPass')?.addEventListener('click',()=>window.print());
  document.getElementById('geShare')?.addEventListener('click',async()=>{
   try{await navigator.clipboard.writeText(location.href);notice('Private guest link copied.',true)}
   catch(e){notice('Copy this page address from your browser to share your guest pass.')}
  });
  document.getElementById('geRefresh')?.addEventListener('click',async()=>{
   try{source=await api('/api/guest/'+encodeURIComponent(token));root.innerHTML=guestScreen(source);bindGuest();notice('Your event information is up to date.',true)}
   catch(e){notice(e.message)}
  });
 }
 function bindFinder(){
  document.getElementById('geFinderForm')?.addEventListener('submit',async e=>{
   e.preventDefault();
   const btn=e.currentTarget.querySelector('button[type=submit]'),form=new FormData(e.currentTarget);
   btn.disabled=true;
   document.getElementById('geFinderResult').innerHTML='';
   try{
     const result=await api('/api/seat-finder/'+encodeURIComponent(token)+'/lookup',{
       name:String(form.get('name')||'').trim(),pin:String(form.get('pin')||'').trim()});
     document.getElementById('geFinderResult').innerHTML=
      '<section class="ge-card ge-seat-info"><span class="ge-eyebrow">SEAT RESULT</span>'+
      '<h2>'+(result.table?'Your table is '+h(result.table.name):'Your host is still arranging seating')+'</h2>'+
      '<p>'+(result.table?'Follow the highlighted table on the map below.':'Your name matches an invitation, but no table is assigned yet. Ask the welcome desk.')+'</p></section>'+
      venueMap(result.floor,result.table);
     notice('Seat lookup completed.',true);
   }catch(err){notice(err.message)}
   finally{btn.disabled=false}
  });
 }
 async function main(){
  if(!token){root.innerHTML='<p class="ge-error">This link is incomplete.</p>';return}
  try{
   source=await api(finder?'/api/seat-finder/'+encodeURIComponent(token)+'/info':'/api/guest/'+encodeURIComponent(token));
   root.innerHTML=finder?finderStart(source):guestScreen(source);
   finder?bindFinder():bindGuest();
  }catch(err){root.innerHTML=header('Invitation unavailable','ACCESS ERROR')+
    '<div class="ge-card"><h2>This link is unavailable</h2><p>'+h(err.message)+'</p><p>Contact your event host for an updated link.</p></div>'}
 }
 main();
})();