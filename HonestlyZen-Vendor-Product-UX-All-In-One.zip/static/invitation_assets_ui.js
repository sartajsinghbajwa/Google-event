'use strict';
(() => {
  const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const folders=['Flowers','Borders','Symbols','Cultural','Other'];
  const mime={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',woff2:'font/woff2',woff:'font/woff',ttf:'font/ttf',otf:'font/otf'};
  const base64=async file=>{
    const bytes=new Uint8Array(await file.arrayBuffer());let out='';
    for(let i=0;i<bytes.length;i+=32768)out+=String.fromCharCode(...bytes.subarray(i,i+32768));
    return btoa(out);
  };
  function render(data){
    if(!data.can_manage)return '<p>Only the workspace administrator can manage shared clipart and fonts.</p>';
    return `<div class="compact-library"><label class="field"><span>Clipart name</span><input data-asset-name="clipart" maxlength="75" placeholder="e.g. Golden floral corner"></label>
      <label class="field"><span>Clipart category</span><select data-asset-category>${folders.map(x=>`<option>${x}</option>`).join('')}</select></label>
      <label class="btn tiny">Upload PNG/JPG/WebP<input type="file" data-library-upload="clipart" accept=".png,.jpg,.jpeg,.webp" hidden></label>
      ${data.can_manage_fonts?`<label class="field"><span>Font name (platform admin only)</span><input data-asset-name="font" maxlength="75" placeholder="e.g. Wedding calligraphy"></label><label class="btn tiny">Upload licensed font<input type="file" data-library-upload="font" accept=".woff2,.woff,.ttf,.otf" hidden></label>`:''}</div>
      <p class="tiny-note">Upload only artwork and fonts you are licensed to use. 2 MB limit per file. SVG files are not accepted.</p>
      <div class="compact-library-list">${[...data.clipart,...data.fonts].map(x=>`<div class="compact-library-row">
        <span>${esc(x.name)} <small>${esc(x.category)}</small></span>
        ${(x.kind!=='font'||data.can_manage_fonts)?`<button type="button" class="btn tiny" data-library-delete="${esc(x.id)}">Remove</button>`:'<small>Admin managed</small>'}</div>`).join('')}</div>`;
  }
  async function upload(input){
    const s=window.EventOSCompactContext?.();if(!s?.assets.can_manage)return;
    const kind=input.dataset.libraryUpload;if(kind==='font'&&!s.assets.can_manage_fonts)return;const file=input.files?.[0];if(!file)return;
    const ext=file.name.split('.').pop().toLowerCase(),content_type=mime[ext];
    if(!content_type||(kind==='clipart'&&content_type.startsWith('font/'))||(kind==='font'&&!content_type.startsWith('font/'))){s.ctx.toast('Unsupported file type');return}
    if(file.size>2*1024*1024||!file.size){s.ctx.toast('Files must be smaller than 2 MB');return}
    const name=document.querySelector(`[data-asset-name="${kind}"]`)?.value?.trim()||file.name.replace(/\.[^.]+$/,'').slice(0,75);
    const category=kind==='clipart'?(document.querySelector('[data-asset-category]')?.value||'Other'):'Fonts';
    input.disabled=true;
    try{
      const saved=await api(s.base(),{method:'POST',body:{kind,name,category,filename:file.name,content_type,data_base64:await base64(file)}});
      await window.EventOSCompactRefresh();
      const placed=window.EventOSCompactUseUploaded?.(kind,saved?.id);
      s.ctx.toast(placed?(kind==='font'?'Font applied to the invitation. Save to publish.':'Artwork placed on the canvas. Move or resize, then save.'):'Added to your '+(kind==='font'?'font':'clipart')+' library');
    }catch(e){s.ctx.toast(e.message)}finally{input.disabled=false}
  }
  document.getElementById('modalRoot')?.addEventListener('change',e=>{
    if(e.target.matches('[data-library-upload]')&&e.target.closest('.invitation-designer'))upload(e.target);
  });
  document.getElementById('modalRoot')?.addEventListener('click',async e=>{
    const btn=e.target.closest('[data-library-delete]');if(!btn||!btn.closest('.invitation-designer'))return;
    const s=window.EventOSCompactContext?.();if(!s?.assets.can_manage)return;
    if(!confirm('Remove this library file? Files used by saved invitations must be removed from those designs first.'))return;
    try{await api(s.base()+'/'+encodeURIComponent(btn.dataset.libraryDelete),{method:'DELETE'});
      await window.EventOSCompactRefresh();s.ctx.toast('Library file removed')}
    catch(err){s.ctx.toast(err.message)}
  });
  window.EventOSAssetPanel={render};
})();