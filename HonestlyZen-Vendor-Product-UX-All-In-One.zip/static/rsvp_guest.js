/* Public, invitation-token scoped RSVP form. The backend validates all answers. */
'use strict';
(() => {
  const token=location.pathname.split('/').pop();
  const root=document.querySelector('#invitation');
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let invitation=null;
  const attendanceDefaults={question:'Will you attend?',confirmed:'Joyfully accepts',maybe:'Maybe',declined:'Regretfully declines'};
  function applyInvitationTheme(d){
    const design=d.design||{};
    const options=['ivory','blush','sage','champagne','midnight','parchment'];
    document.body.dataset.rsvpTheme=options.includes(design.canvas_background)?design.canvas_background:'ivory';
    document.body.classList.toggle('rsvp-canvas-event',design.mode==='canvas');
    document.body.style.setProperty('--invite-accent',/^#[0-9a-fA-F]{6}$/.test(design.accent_color||'')?design.accent_color:'#946e50');
    const cover=d.media?.cover?.id&&design.canvas_use_cover?
      '/api/rsvp/'+encodeURIComponent(token)+'/media/'+encodeURIComponent(d.media.cover.id):'';
    const url=String(design.cover_image_url||'');
    const external=!cover&&design.canvas_use_cover&&url.startsWith('https://')&&url.length<501&&!/["'()<>\\]/.test(url)?url:'';
    const background=cover||external;
    if(background){
      document.body.style.setProperty('--rsvp-page-cover','url("'+background+'")');
      document.body.classList.add('rsvp-has-cover');
    }else{
      document.body.style.removeProperty('--rsvp-page-cover');
      document.body.classList.remove('rsvp-has-cover');
    }
  }
  function countdownLabel(date){
    const match=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(date||''));
    if(!match)return '';
    const y=Number(match[1]),m=Number(match[2]),day=Number(match[3]);
    const check=new Date(Date.UTC(y,m-1,day));
    if(check.getUTCFullYear()!==y||check.getUTCMonth()!==m-1||check.getUTCDate()!==day)return '';
    const now=new Date();
    const remaining=Math.round((Date.UTC(y,m-1,day)-Date.UTC(now.getFullYear(),now.getMonth(),now.getDate()))/86400000);
    return remaining>1?remaining+' days until the celebration':remaining===1?'1 day until the celebration':remaining===0?'Today is the day!':'The celebration has begun';
  }
  function guestExtras(d){
    const design=d.design||{},music=String(design.guest_music_url||'');
    const safeMusic=/^https:\/\/[^\s"'<>\\()]+$/i.test(music)&&music.length<=500;
    const counter=design.guest_show_countdown?countdownLabel(d.start_date):'';
    if(!counter&&!safeMusic)return '';
    return '<section class="rsvp-guest-extras" aria-label="Celebration extras">'+
      (counter?'<p class="rsvp-countdown" id="rsvpCountdown" aria-live="off">'+esc(counter)+'</p>':'')+
      (safeMusic?'<div class="rsvp-music"><strong>Celebration music</strong><p>Tap Play to listen while you respond.</p><audio controls preload="none" src="'+esc(music)+'">Your browser does not support audio playback.</audio></div>':'')+
      '</section>';
  }
  function partyRows(total,existing=[]) {
    const config=invitation.form.party;
    if(!config.names_optional&&!config.meals_optional)return '';
    const limit=Math.min(total,100), note=total>100?'<p class="tiny-note">Individual details can be entered for the first 100 guests.</p>':'';
    return note+Array.from({length:limit},(_,i)=>{
      const guest=existing[i]||{};
      return `<div class="inline-fields rsvp-attendee-row" data-guest-index="${i}">
        ${config.names_optional?`<label class="field"><span>Guest ${i+1} name (optional)</span><input data-guest-name maxlength="160" value="${esc(guest.name||'')}"></label>`:''}
        ${config.meals_optional?`<label class="field"><span>Guest ${i+1} meal (optional)</span><select data-guest-meal><option value="">No preference</option>${config.meal_options.map(o=>`<option value="${esc(o)}" ${guest.meal===o?'selected':''}>${esc(o)}</option>`).join('')}</select></label>`:''}
      </div>`;
    }).join('');
  }
  function countParty() {
    const section=root.querySelector('#rsvpParty');
    if(!section)return;
    const status=root.querySelector('[name="rsvp"]')?.value;
    section.hidden=status!=='Confirmed';
    section.querySelectorAll('input,select').forEach(node=>{node.disabled=status!=='Confirmed'});
    if(status!=='Confirmed')return;
    const adults=Number(section.querySelector('[name="partyAdults"]')?.value||0),
      kids=Number(section.querySelector('[name="partyKids"]')?.value||0),
      plus=!!section.querySelector('[name="partyPlusOne"]')?.checked,
      max=Number(invitation.party_size)+(plus?1:0),total=adults+kids;
    const info=section.querySelector('#partySeatInfo');
    if(info)info.textContent=`${total} attending · ${max} seat${max===1?'':'s'} available${total>max?' — too many guests':''}`;
    const previous=Array.from(section.querySelectorAll('.rsvp-attendee-row')).map(row=>({
      name:row.querySelector('[data-guest-name]')?.value||'',
      meal:row.querySelector('[data-guest-meal]')?.value||''
    }));
    section.querySelector('#rsvpAttendees').innerHTML=partyRows(Math.max(0,Math.min(total,100)),previous);
  }
  function partyMarkup(d){
    const cfg=d.form.party;
    if(!cfg?.enabled)return '';
    const saved=d.party||{},adults=saved.adults??1,kids=saved.kids??0;
    return `<section id="rsvpParty" class="rsvp-question">
      <h3>Who is attending?</h3><p class="tiny-note">Your invitation reserves ${esc(d.party_size)} seat${d.party_size===1?'':'s'}.</p>
      <div class="inline-fields"><label class="field"><span>${cfg.ask_adults_kids?'Number of adults':'Number attending'} *</span><input type="number" name="partyAdults" min="0" max="${Math.min(10000,d.party_size+1)}" step="1" value="${esc(adults)}" required></label>
      ${cfg.ask_adults_kids?`<label class="field"><span>Number of kids *</span><input type="number" name="partyKids" min="0" max="${Math.min(10000,d.party_size+1)}" step="1" value="${esc(kids)}" required></label>`:''}
      ${cfg.allow_plus_one?`<label class="rsvp-check-label"><input type="checkbox" name="partyPlusOne" ${saved.plus_one?'checked':''}> Bring one additional guest (+1)</label>`:''}
      </div><p class="tiny-note" id="partySeatInfo"></p><div id="rsvpAttendees">${partyRows(adults+kids,saved.guests||[])}</div>
      <p class="tiny-note">Guest names and meal choices are optional.</p></section>`;
  }
  function field(q,existing) {
    const key=esc(q.id), saved=existing[q.id];
    let control='';
    if(q.type==='short_text')control=`<input name="${key}" maxlength="350" value="${esc(saved||'')}" ${q.required?'required':''}>`;
    if(q.type==='paragraph')control=`<textarea name="${key}" maxlength="3000" ${q.required?'required':''}>${esc(saved||'')}</textarea>`;
    if(q.type==='number')control=`<input type="number" step="any" name="${key}" value="${saved===undefined?'':esc(saved)}" ${q.required?'required':''}>`;
    if(q.type==='date')control=`<input type="date" name="${key}" value="${esc(saved||'')}" ${q.required?'required':''}>`;
    if(q.type==='yes_no')control=`<select name="${key}" ${q.required?'required':''}><option value="">Select an answer</option><option value="yes" ${saved===true?'selected':''}>Yes</option><option value="no" ${saved===false?'selected':''}>No</option></select>`;
    if(q.type==='single_choice')control=`<select name="${key}" ${q.required?'required':''}><option value="">Select an answer</option>${q.options.map(o=>`<option ${saved===o?'selected':''} value="${esc(o)}">${esc(o)}</option>`).join('')}</select>`;
    if(q.type==='multiple_choice')control=`<div class="rsvp-check-options">${q.options.map(o=>`<label><input type="checkbox" name="${key}" value="${esc(o)}" ${Array.isArray(saved)&&saved.includes(o)?'checked':''}> ${esc(o)}</label>`).join('')}</div>`;
    return `<div class="field rsvp-preview-field" data-show-when="${esc(q.show_when||'always')}"><span>${esc(q.label)}${q.required?' *':''}</span>${q.help_text?`<small>${esc(q.help_text)}</small>`:''}${control}</div>`;
  }
  function updateConditionalQuestions(){
    const status=root.querySelector('#rsvpForm [name="rsvp"]')?.value||'';
    root.querySelectorAll('[data-show-when]').forEach(section=>{
      const visible=section.dataset.showWhen==='always'||section.dataset.showWhen===status;
      section.hidden=!visible;
      section.querySelectorAll('input,select,textarea').forEach(el=>{el.disabled=!visible;});
    });
  }
  async function load() {
    try {
      const r=await fetch('/api/rsvp/'+encodeURIComponent(token));const d=await r.json();
      if(!r.ok)throw Error(d.detail||'Invitation unavailable');invitation=d;applyInvitationTheme(d);
      const f=d.form, words={...attendanceDefaults,...d.form.attendance}, expired=!!f.deadline&&new Date().toISOString().slice(0,10)>f.deadline;
      const closed=!f.published||expired||['Completed','Cancelled'].includes(d.status);
      root.innerHTML=`<div class="rsvp-public-art">${window.eventosInvitationExperience(d,d.design,d.name,d.media,'/api/rsvp/'+encodeURIComponent(token)+'/media')}</div><div class="rsvp-form-content"><div class="invitation-name"><strong>${esc(f.title)}</strong></div><p>${esc(f.intro)}</p>${guestExtras(d)}<p>We have reserved ${esc(d.party_size)} ${d.party_size===1?'seat':'seats'} for your invitation.</p>${f.deadline?`<p class="tiny-note">Please reply by ${esc(f.deadline)}.</p>`:''}
        ${closed?'<div class="alert">This invitation is not currently accepting responses.</div>':''}
        <form id="rsvpForm"><label class="field rsvp-preview-field"><span>${esc(words.question)} *</span><select name="rsvp" required><option value="">Choose your response</option>${[['Confirmed',words.confirmed],['Maybe',words.maybe],['Declined',words.declined]].map(([status,label])=>`<option value="${status}" ${d.rsvp===status?'selected':''}>${esc(label)}</option>`).join('')}</select></label>
        ${partyMarkup(d)}
        ${f.questions.map(q=>field(q,d.answers||{})).join('')}<button type="submit" class="btn primary full" ${closed?'disabled':''}>Save my RSVP</button></form>
        <section class="rsvp-guest-pass" id="rsvpCheckinPass" ${d.rsvp==='Confirmed'?'':'hidden'}><h3>Event check-in pass</h3><p class="tiny-note">Save this QR code for the check-in staff. It identifies your invitation; staff must confirm your arrival.</p><img src="/api/rsvp/${encodeURIComponent(token)}/checkin-qr.png" alt="Event QR check-in pass" loading="lazy"></section>
        <section class="rsvp-experience-links" aria-label="More event experiences">
        ${d.event_extras?.gallery||d.event_extras?.registry||d.event_extras?.website||d.event_extras?.guest_hub?'<h3>Your event information</h3>':''}
        ${d.event_extras?.guest_hub?`<a href="${esc(d.event_extras.guest_hub)}" class="rsvp-guest-hub-link"><strong>🎟 My event pass & seat</strong><small>Find your table, event program, guest QR pass and updates</small></a>`:''}
         ${d.event_extras?.website?`<a href="${esc(d.event_extras.website)}" target="_blank" rel="noopener noreferrer"><strong>✦ Event website</strong><small>Schedule, location and everything to know</small></a>`:''}
        ${d.event_extras?.gallery?`<a href="${esc(d.event_extras.gallery)}" target="_blank" rel="noopener noreferrer"><strong>📸 Live photo gallery</strong><small>Browse or share event memories</small></a>`:''}
        ${d.event_extras?.registry?`<a href="${esc(d.event_extras.registry)}" target="_blank" rel="noopener noreferrer"><strong>🎁 Gift registry</strong><small>Browse gifts and gift funds</small></a>`:''}
        </section><div class="alert" id="message" role="status" style="display:none"></div></div>`;
      if(d.design?.mode==='canvas'){
        window.eventosPrepareCanvasFonts?.(d.design,'/api/rsvp/'+encodeURIComponent(token)+'/media');
      }
      const countdown=root.querySelector('#rsvpCountdown');
      if(countdown)countdown.textContent=countdownLabel(d.start_date);
      document.querySelector('#rsvpForm').addEventListener('submit', submit);
      document.querySelector('#rsvpForm [name="rsvp"]')?.addEventListener('change', ()=>{countParty();updateConditionalQuestions()});
      updateConditionalQuestions();
      root.querySelector('#rsvpParty')?.addEventListener('input',e=>{
        if(e.target.matches('[name="partyAdults"],[name="partyKids"],[name="partyPlusOne"]'))countParty();
      });
      root.querySelector('#rsvpParty')?.addEventListener('change',e=>{
        if(e.target.matches('[name="partyAdults"],[name="partyKids"],[name="partyPlusOne"]'))countParty();
      });
      if(root.querySelector('#rsvpParty')){
        const section=root.querySelector('#rsvpParty'), total=Number(section.querySelector('[name="partyAdults"]')?.value||0)+Number(section.querySelector('[name="partyKids"]')?.value||0);
        section.hidden=d.rsvp!=='Confirmed';
        section.querySelectorAll('input,select').forEach(node=>{node.disabled=d.rsvp!=='Confirmed'});
        const max=Number(d.party_size)+Number(!!section.querySelector('[name="partyPlusOne"]')?.checked);
        section.querySelector('#partySeatInfo').textContent=`${total} attending · ${max} seat${max===1?'':'s'} available`;
      }
    }catch(e){root.innerHTML=`<h2>Invitation unavailable</h2><p class="muted">${esc(e.message)}</p>`}
  }
  async function submit(event) {
    event.preventDefault();const data=new FormData(event.currentTarget),answers={};
    for(const q of invitation.form.questions){
      let val=q.type==='multiple_choice'?data.getAll(q.id):data.get(q.id);
      if(q.type==='multiple_choice'&&!val.length)continue;
      if(val===null||val==='')continue;
      if(q.type==='number'){val=Number(val);if(!Number.isFinite(val)){show('Please enter a valid number.',false);return}}
      if(q.type==='yes_no')val=val==='yes';
      answers[q.id]=val;
    }
    let party;
    if(data.get('rsvp')==='Confirmed' && invitation.form.party?.enabled){
      const adults=Number(data.get('partyAdults')),kids=invitation.form.party.ask_adults_kids?Number(data.get('partyKids')):0,
        plus_one=data.get('partyPlusOne')==='on',total=adults+kids,
        max=Number(invitation.party_size)+Number(plus_one);
      if(!Number.isInteger(adults)||!Number.isInteger(kids)||adults<0||kids<0||total<1||total>max){
        show('Choose a valid number of adults and kids within your seats.',false);return;
      }
      const guests=Array.from(root.querySelectorAll('.rsvp-attendee-row')).map(row=>({
        name:row.querySelector('[data-guest-name]')?.value.trim()||'',
        meal:row.querySelector('[data-guest-meal]')?.value||''
      }));
      party={adults,kids,plus_one,guests};
    }
    const button=event.currentTarget.querySelector('button[type=submit]');button.disabled=true;
    try{
      const r=await fetch('/api/rsvp/'+encodeURIComponent(token),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rsvp:data.get('rsvp'),answers,party})});
      const d=await r.json();if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'Could not save your response');
      invitation.answers=d.answers;invitation.rsvp=d.rsvp;const pass=root.querySelector('#rsvpCheckinPass');if(pass){pass.hidden=d.rsvp!=='Confirmed';if(d.rsvp==='Confirmed'){pass.querySelector('img').src='/api/rsvp/'+encodeURIComponent(token)+'/checkin-qr.png?updated='+Date.now()}}show('Thank you! Your RSVP and answers have been saved.',true);
    }catch(e){show(e.message,false)}finally{button.disabled=false}
  }
  function show(message,success){const el=document.querySelector('#message');el.style.display='block';el.textContent=message;el.className='alert '+(success?'success':'error')}
  load();
})();
