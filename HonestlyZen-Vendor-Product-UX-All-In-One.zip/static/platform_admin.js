/* Honestly Zen Event Planning SaaS platform owner console — separate from event planning permissions. */
'use strict';
(function(){
const escText=value=>String(value??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[k]));
const p=()=>state.platform||{users:[],workspaces:[],codes:[],require_access_code:false};
const field=(title,name,defaultValue,type='text')=>'<label class="field"><span>'+escText(title)+'</span><input type="'+type+'" name="'+name+'" value="'+escText(defaultValue)+'" required></label>';
const options=(items,value)=>items.map(([id,label])=>'<option value="'+escText(id)+'" '+(id===value?'selected':'')+'>'+escText(label)+'</option>').join('');
const fieldOptional=(title,name,value='',type='text')=>'<label class="field"><span>'+escText(title)+'</span><input type="'+type+'" name="'+name+'" value="'+escText(value)+'"></label>';
const num=value=>Number.isFinite(Number(value))?Number(value).toLocaleString('en-CA'):'0';
const boolBadge=(value,yes='Configured',no='Not configured')=>'<span class="badge '+(value?'good':'red')+'">'+(value?escText(yes):escText(no))+'</span>';
const pill=(label,value,tone='blue')=>'<div class="platform-mini-item"><span>'+escText(label)+'</span><strong class="'+tone+'">'+escText(value)+'</strong></div>';
const quickButton=(label,target)=>'<button type="button" class="btn" onclick="platformSwitchTab(\''+target+'\')">'+escText(label)+'</button>';
const parseDate=value=>{if(!value || typeof value!=='string')return null;const d=new Date(value);return Number.isNaN(d.getTime())?null:d};
const formatDate=value=>{const d=parseDate(value);return d?d.toLocaleString('en-CA',{year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'—'};
const formatShortDate=value=>{const d=parseDate(value);return d?d.toLocaleDateString('en-CA',{year:'numeric',month:'short',day:'numeric'}):'—'};
const pct=(a,b)=>!b?'0%':Math.round((Number(a)||0)/(Number(b)||1)*100)+'%';
const clampPct=(a,b)=>Math.max(0,Math.min(100,Math.round((Number(a)||0)/(Number(b)||1)*100)));

function statCard(title,value,meta='',tone='teal'){
 return '<article class="card platform-stat-card '+tone+'"><div class="platform-stat-top"><span>'+escText(title)+'</span></div><div class="platform-stat-value">'+escText(value)+'</div>'+(meta?'<div class="platform-stat-meta">'+meta+'</div>':'')+'</article>';
}
function healthCard(title,subtitle,items){
 return '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>'+escText(title)+'</h2><p>'+escText(subtitle||'')+'</p></div><div class="platform-health-list">'+items.join('')+'</div></section>';
}
function healthRow(label,badge,help=''){
 return '<div class="platform-health-row"><div><strong>'+escText(label)+'</strong>'+(help?'<small>'+escText(help)+'</small>':'')+'</div><div>'+badge+'</div></div>';
}
function derive(){
 const d=p();
 const users=d.users||[];
 const workspaces=d.workspaces||[];
 const codes=d.codes||[];
 const packages=(state.platformStudio?.packages)||[];
 const now=new Date();
 const activeUsers=users.filter(u=>u.is_active).length;
 const suspendedUsers=users.length-activeUsers;
 const admins=users.filter(u=>u.platform_role==='admin').length;
 const activeWorkspaces=workspaces.filter(w=>w.is_active).length;
 const suspendedWorkspaces=workspaces.length-activeWorkspaces;
 const personal=workspaces.filter(w=>w.type==='personal').length;
 const business=workspaces.filter(w=>w.type==='business').length;
 const paid=workspaces.filter(w=>['pro','business'].includes(w.billing_plan) && ['active','trialing','manual'].includes(w.billing_status)).length;
 const trialing=workspaces.filter(w=>w.billing_status==='trialing').length;
 const manual=workspaces.filter(w=>w.billing_status==='manual').length;
 const pastDue=workspaces.filter(w=>w.billing_status==='past_due').length;
 const canceled=workspaces.filter(w=>w.billing_status==='canceled').length;
 const expiringSoon=workspaces.filter(w=>{const d=parseDate(w.expires_at);return d && d>now && ((d-now)/(1000*60*60*24))<=14}).length;
 const events=workspaces.reduce((n,w)=>n+(Number(w.event_count)||0),0);
 const guests=workspaces.reduce((n,w)=>n+(Number(w.guest_count)||0),0);
 const members=workspaces.reduce((n,w)=>n+(Number(w.member_count)||0),0);
 const eventCapacity=workspaces.reduce((n,w)=>n+(Number(w.max_events)||0),0);
 const guestCapacity=workspaces.reduce((n,w)=>n+(Number(w.max_guests)||0),0);
 const memberCapacity=workspaces.reduce((n,w)=>n+(Number(w.max_members)||0),0);
 const activeCodes=codes.filter(c=>c.is_active).length;
 const disabledCodes=codes.length-activeCodes;
 const redeemedCodes=codes.filter(c=>(Number(c.uses)||0)>0).length;
 const remainingRedemptions=codes.reduce((n,c)=>n+Math.max(0,(Number(c.max_uses)||0)-(Number(c.uses)||0)),0);
 const last7=users.filter(u=>{const d=parseDate(u.created_at);return d && ((now-d)/(1000*60*60*24))<=7}).length;
 const last30=users.filter(u=>{const d=parseDate(u.created_at);return d && ((now-d)/(1000*60*60*24))<=30}).length;
 const packageCounts={};
 workspaces.forEach(w=>{const key=w.billing_plan||'unassigned';packageCounts[key]=(packageCounts[key]||0)+1});
 const billingCounts={};
 workspaces.forEach(w=>{const key=w.billing_status||'unconfigured';billingCounts[key]=(billingCounts[key]||0)+1});
 const recentUsers=[...users].sort((a,b)=>(parseDate(b.created_at)?.getTime()||0)-(parseDate(a.created_at)?.getTime()||0)).slice(0,5);
 const busiest=[...workspaces].sort((a,b)=>(Number(b.guest_count)||0)-(Number(a.guest_count)||0)).slice(0,5);
 return {users,workspaces,codes,packages,activeUsers,suspendedUsers,admins,activeWorkspaces,suspendedWorkspaces,personal,business,paid,trialing,manual,pastDue,canceled,expiringSoon,events,guests,members,eventCapacity,guestCapacity,memberCapacity,activeCodes,disabledCodes,redeemedCodes,remainingRedemptions,last7,last30,packageCounts,billingCounts,recentUsers,busiest};
}
function packageBreakdown(items){
 const rows=Object.entries(items||{}).sort((a,b)=>b[1]-a[1]);
 if(!rows.length)return '<div class="platform-empty-mini">No workspace package assignments yet.</div>';
 return '<div class="platform-pill-grid">'+rows.map(([k,v])=>pill(k.replaceAll('_',' '),num(v),'blue')).join('')+'</div>';
}
function usageMeter(label,used,total){
 const usedNum=Number(used)||0,totalNum=Number(total)||0,pc=clampPct(usedNum,totalNum||1);
 return '<div class="platform-usage-row"><div class="platform-usage-head"><strong>'+escText(label)+'</strong><span>'+num(usedNum)+' / '+num(totalNum||0)+' <em>'+pct(usedNum,totalNum||1)+'</em></span></div><div class="progress"><span style="width:'+pc+'%"></span></div></div>';
}
function render(){
 if(state.user?.platform_role!=='admin')return '<p>Platform administrator access is required.</p>';
 const d=p(),ready=state.platformReadiness||{},launch=state.platformLaunch||{},studio=state.platformStudio||{site:{},packages:[]},backups=state.platformBackups||{},audit=state.platformBillingAudit||[];
 const x=derive();
 const topButtons='<button class="btn primary" onclick="go(\'monetization\')">Monetization Center →</button>'+quickButton('Website & SEO','site')+quickButton('Packages','billing')+quickButton('Workspaces','workspaces')+quickButton('Users','people')+'<button class="btn" onclick="go(\'partyModeration\')">✓ Vendor listing approvals</button>'+'<button class="btn" onclick="go(\'supportInbox\')">Support inbox</button>'+'<button class="btn primary" onclick="refresh()">↻ Refresh data</button>';
 return head('Honestly Zen Event Planning control center','Operations, subscriptions, payments, analytics, customer oversight and publishing.',topButtons)+platformTabs()+
 '<section class="platform-hero card" data-platform-tab="overview"><div class="platform-hero-main"><div class="platform-kicker">Platform operations</div><h2>Advanced admin control center</h2><p>Manage your full Honestly Zen Event Planning business from one place: onboarding, access control, subscriptions, quotas, website settings, package design, backups and launch readiness.</p><div class="platform-hero-tags">'+
 boolBadge(d.require_access_code,'Access codes required','Public signup open')+
 boolBadge(studio.billing_secret_configured,'Stripe secret configured','Stripe secret missing')+
 boolBadge(studio.invoice_secret_configured,'Invoice payments configured','Invoice payment keys missing')+
 boolBadge(ready.smtp_configured,'SMTP ready','SMTP not ready')+
 '</div></div><div class="platform-hero-side"><div class="platform-hero-metric"><span>Accounts</span><strong>'+num(x.users.length)+'</strong><small>'+num(x.activeUsers)+' active · '+num(x.admins)+' admins</small></div><div class="platform-hero-metric"><span>Workspaces</span><strong>'+num(x.workspaces.length)+'</strong><small>'+num(x.activeWorkspaces)+' active · '+num(x.paid)+' paid/granted</small></div><div class="platform-hero-metric"><span>Records</span><strong>'+num(x.events)+' / '+num(x.guests)+'</strong><small>events · guest records</small></div></div></section>'+
 '<section class="platform-overview-grid" data-platform-tab="overview">'+
 statCard('Accounts',num(x.users.length),'<span>'+num(x.activeUsers)+' active</span><span>'+num(x.suspendedUsers)+' suspended</span>','teal')+
 statCard('Workspaces',num(x.workspaces.length),'<span>'+num(x.business)+' business</span><span>'+num(x.personal)+' personal</span>','navy')+
 statCard('Subscriptions',num(x.paid),'<span>'+num(x.trialing)+' trialing</span><span>'+num(x.manual)+' manual</span>','gold')+
 statCard('Access codes',num(x.codes.length),'<span>'+num(x.activeCodes)+' active</span><span>'+num(x.redeemedCodes)+' redeemed</span>','purple')+
 statCard('Events tracked',num(x.events),'<span>capacity '+num(x.eventCapacity)+'</span><span>'+pct(x.events,x.eventCapacity||1)+' utilized</span>','teal')+
 statCard('Guest records',num(x.guests),'<span>capacity '+num(x.guestCapacity)+'</span><span>'+pct(x.guests,x.guestCapacity||1)+' utilized</span>','navy')+
 statCard('Team memberships',num(x.members),'<span>capacity '+num(x.memberCapacity)+'</span><span>'+pct(x.members,x.memberCapacity||1)+' utilized</span>','gold')+
 statCard('Recent growth',num(x.last30),'<span>'+num(x.last7)+' signups in 7 days</span><span>'+num(x.last30)+' in 30 days</span>','purple')+
 '</section>'+
 '<div class="grid two-col m-top" data-platform-tab="overview">'+
 healthCard('Launch verification','Critical configuration and production safeguards.',[
   healthRow('Managed database engine',boolBadge(launch.flags?.database_engine,'Configured','Not configured'),'Current staging engine and cutover readiness'),
   healthRow('Managed database configured',boolBadge(launch.flags?.managed_database_configured),'External managed database / production target'),
   healthRow('Off-site backups scheduled',boolBadge(launch.flags?.offsite_backup_scheduled),'Automated backup schedule and monitoring'),
   healthRow('Restore drill configured',boolBadge(launch.flags?.restore_drill_configured),'Recovery practice and verification'),
   healthRow('Cloud media configured',boolBadge(launch.flags?.cloud_media_configured),'Private object storage for uploads'),
   healthRow('SMTP configured',boolBadge(launch.flags?.smtp_configured),'Transactional email delivery'),
   healthRow('Stripe configured',boolBadge(launch.flags?.stripe_configured),'Subscriptions and platform billing'),
   healthRow('Production mode',boolBadge(launch.flags?.production_mode),'Operational launch mode and sign-off')
 ])+
 healthCard('Platform readiness','Commercial and operational readiness checklist.',[
   healthRow('Verified-email requirement',boolBadge(ready.email_verification_required,'Enabled','Disabled')),
   healthRow('Stripe billing',boolBadge(ready.stripe_configured,'Ready','Not ready')),
   healthRow('Private cloud media',boolBadge(ready.private_cloud_media_configured,'Ready','Not ready')),
   healthRow('Managed database verified',boolBadge(ready.database_persistence_verified,'Verified','Not ready')),
   healthRow('Automated backups verified',boolBadge(ready.backup_automation_configured,'Verified','Not ready')),
   healthRow('Latest backup',boolBadge(Boolean(launch.latest_backup?.finished_at),'Verified','Not yet verified'),launch.latest_backup?.finished_at||'No successful backup recorded'),
   healthRow('Latest restore drill',boolBadge(Boolean(launch.latest_restore_drill?.finished_at),'Verified','Not yet verified'),launch.latest_restore_drill?.finished_at||'No successful restore drill recorded'),
   healthRow('Launch sign-off',boolBadge(launch.fully_verified,'Verified','Pending'),'Operator approval still required')
 ])+
 '</div>'+
 '<div class="grid three-col m-top" data-platform-tab="overview">'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Workspace mix</h2><p>Account composition and lifecycle status.</p></div><div class="platform-pill-grid">'+
 pill('Business',num(x.business),'teal')+pill('Personal',num(x.personal),'blue')+pill('Active',num(x.activeWorkspaces),'good')+pill('Suspended',num(x.suspendedWorkspaces),'red')+pill('Expiring ≤ 14 days',num(x.expiringSoon),'gold')+pill('Paid / granted',num(x.paid),'purple')+
 '</div><div class="platform-mini-section"><h3>Package distribution</h3>'+packageBreakdown(x.packageCounts)+'</div><div class="platform-mini-section"><h3>Billing status</h3>'+packageBreakdown(x.billingCounts)+'</div></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Usage & capacity</h2><p>Current occupancy against provisioned quotas.</p></div>'+usageMeter('Events',x.events,x.eventCapacity)+usageMeter('Guests',x.guests,x.guestCapacity)+usageMeter('Team members',x.members,x.memberCapacity)+'<div class="platform-mini-section"><h3>Access code pool</h3><div class="platform-pill-grid">'+pill('Codes issued',num(x.codes.length),'blue')+pill('Codes active',num(x.activeCodes),'good')+pill('Codes disabled',num(x.disabledCodes),'red')+pill('Remaining redemptions',num(x.remainingRedemptions),'purple')+'</div></div></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Revenue readiness</h2><p>Subscription catalogue and payment configuration.</p></div><div class="platform-pill-grid">'+pill('Packages configured',num(x.packages.length),'blue')+pill('Paid / granted',num(x.paid),'good')+pill('Trialing',num(x.trialing),'gold')+pill('Past due',num(x.pastDue),'red')+pill('Canceled',num(x.canceled),'red')+pill('Manual grants',num(x.manual),'purple')+'</div><div class="platform-mini-section"><h3>Configuration</h3><div class="platform-pill-grid">'+pill('Stripe secret',studio.billing_secret_configured?'Configured':'Missing',studio.billing_secret_configured?'good':'red')+pill('Invoice payments',studio.invoice_secret_configured?'Configured':'Missing',studio.invoice_secret_configured?'good':'red')+pill('Signup policy',d.require_access_code?'Restricted':'Open',d.require_access_code?'gold':'blue')+'</div></div></section>'+
 '</div>'+
 '<div class="grid two-col m-top" data-platform-tab="overview">'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Recent accounts</h2><p>Newest registered users on the platform.</p></div><div class="platform-list">'+
 (x.recentUsers.length?x.recentUsers.map(u=>'<div class="platform-list-row"><div><strong>'+escText(u.full_name||u.email)+'</strong><small>'+escText(u.email)+' · '+escText(u.platform_role||'user')+'</small></div><div class="platform-list-meta"><span class="badge '+(u.is_active?'good':'red')+'">'+(u.is_active?'Active':'Suspended')+'</span><small>'+formatShortDate(u.created_at)+'</small></div></div>').join(''):'<div class="platform-empty-mini">No users yet.</div>')+
 '</div></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Top workspaces by guest volume</h2><p>Quick view of your busiest organizations or planners.</p></div><div class="platform-list">'+
 (x.busiest.length?x.busiest.map(w=>'<div class="platform-list-row"><div><strong>'+escText(w.name)+'</strong><small>'+escText(w.type)+' · plan '+escText(w.billing_plan||'free')+'</small></div><div class="platform-list-meta"><span class="badge blue">'+num(w.guest_count)+' guests</span><small>'+num(w.event_count)+' events · '+num(w.member_count)+' staff</small></div></div>').join(''):'<div class="platform-empty-mini">No workspace activity yet.</div>')+
 '</div></section>'+
 '</div>'+
 '<section class="card pad m-top" data-platform-tab="access"><div class="platform-section-head"><div><h2>Signup access control</h2><p class="small-note">Enforce invite-only signup or leave registration open while you test packages and onboarding.</p></div><div>'+boolBadge(d.require_access_code,'Invite-only access enabled','Open signup enabled')+'</div></div>'+
 '<label class="rsvp-check-label"><input type="checkbox" '+(d.require_access_code?'checked':'')+' onchange="platformEnforceCodes(this.checked)"> Require access code on signup & workspace creation</label></section>'+
 '<div class="grid two-col m-top" data-platform-tab="access"><section class="card pad platform-panel"><div class="platform-panel-head"><h2>Issue access codes</h2><p>Create controlled onboarding codes with quotas and redemption limits.</p></div>'+
 '<form onsubmit="platformNewCode(event)"><div class="inline-fields">'+field('Code label','label','New customer')+
 '<label class="field"><span>Workspace type</span><select name="workspace_type" id="platformType">'+options([['personal','Personal / small party'],['business','Event planning organization']],'personal')+'</select></label>'+
 field('Maximum events','max_events','3','number')+field('Maximum guests','max_guests','120','number')+
 field('Maximum team members','max_members','2','number')+field('Number of redemptions','max_uses','1','number')+'</div>'+
 '<button class="btn primary" type="submit">Generate secure access code</button></form></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Access code library</h2><p>Manage issued codes, redemptions and activation state.</p></div><div class="platform-scroll">'+
 (d.codes||[]).map(c=>'<div class="platform-code"><div><strong>'+escText(c.label)+'</strong><small>'+escText(c.workspace_type)+' · '+num(c.uses)+'/'+num(c.max_uses)+' uses · '+num(c.max_events)+' events / '+num(c.max_guests)+' guests / '+num(c.max_members)+' staff</small><small>Created '+formatShortDate(c.created_at)+(c.expires_at?' · Expires '+formatShortDate(c.expires_at):'')+'</small></div><div class="platform-code-actions"><span class="badge '+(c.is_active?'good':'red')+'">'+(c.is_active?'Active':'Disabled')+'</span><button type="button" class="btn tiny" onclick="platformToggleCode(\''+c.id+'\','+(!c.is_active)+')">'+(c.is_active?'Disable':'Enable')+'</button><button class="btn tiny hz-danger" onclick="platformRemoveCode(\''+c.id+'\')">Delete / revoke</button></div></div>').join('')+
 '</div></section></div>'+
 '<section class="card pad m-top" id="platform-workspaces" data-platform-tab="workspaces"><div class="platform-section-head"><div><h2>Workspace subscriptions, quotas & controls</h2><p class="small-note">Adjust plan, limits, status and feature access for every tenant.</p></div><div class="platform-inline-badges">'+pill('Total',num(x.workspaces.length),'blue')+pill('Active',num(x.activeWorkspaces),'good')+pill('Suspended',num(x.suspendedWorkspaces),'red')+'</div></div>'+
 '<input class="search" id="platformWorkspaceSearch" aria-label="Search workspaces" placeholder="Find a workspace, plan or status..." oninput="platformFilterWorkspaces(this.value)" style="max-width:420px;width:100%;margin:12px 0">'+
 '<div class="table-wrap"><table class="table"><thead><tr><th>Workspace</th><th>Type</th><th>Usage</th><th>Plan</th><th>Billing</th><th>Status</th><th>Expiry</th><th>Admin actions</th></tr></thead><tbody>'+
 (d.workspaces||[]).map(w=>'<tr class="platform-workspace-row" data-search="'+escText((w.name+' '+w.type+' '+(w.billing_plan||'')+' '+(w.billing_status||'')).toLowerCase())+'"><td><strong>'+escText(w.name)+'</strong><div class="tiny-note">'+num(w.member_count)+' staff · '+num(w.guest_count)+' guests · '+num(w.event_count)+' events</div></td><td>'+escText(w.type)+'</td><td><div class="tiny-note">Events '+num(w.event_count)+'/'+num(w.max_events)+'</div><div class="tiny-note">Guests '+num(w.guest_count)+'/'+num(w.max_guests)+'</div><div class="tiny-note">Staff '+num(w.member_count)+'/'+num(w.max_members)+'</div></td><td><span class="badge blue">'+escText(w.billing_plan||'free')+'</span></td><td><span class="badge '+(['active','manual','trialing'].includes(w.billing_status)?'good':((w.billing_status||'')==='past_due'?'warn':'blue'))+'">'+escText(w.billing_status||'unconfigured')+'</span></td><td><span class="badge '+(w.is_active?'good':'red')+'">'+(w.is_active?'Active':'Suspended')+'</span></td><td>'+escText(w.expires_at?formatShortDate(w.expires_at):'—')+'</td><td>'+ '<button class="btn tiny" type="button" onclick="platformEditWorkspace(\''+w.id+'\')">Limits</button> '+ '<button class="btn tiny" type="button" onclick="platformGrantPlan(\''+w.id+'\')">Plan</button> '+ '<button class="btn tiny" type="button" onclick="platformSuspendWorkspace(\''+w.id+'\','+(!w.is_active)+')">'+(w.is_active?'Suspend':'Reactivate')+'</button> '+ '<button class="btn tiny" type="button" onclick="platformShowFeatures(\''+w.id+'\')">Features</button>'+ '<div class="platform-feature-picker" id="platform-features-'+escText(w.id)+'" hidden>'+ Object.entries(d.available_features||{}).map(([id,label])=>'<label><input type="checkbox" '+(w.features?.[id]?'checked':'')+' onchange="platformToggleFeature(\''+w.id+'\',\''+id+'\',this.checked)">'+escText(label)+'</label>').join('')+'</div></td></tr>').join('')+
 '</tbody></table></div></section>'+
 '<section class="card pad m-top" id="platform-users" data-platform-tab="people"><div class="platform-section-head"><div><h2>Registered users</h2><p class="small-note">Review platform accounts, edit customer identity details and control active access.</p></div><div class="platform-inline-badges">'+pill('Total',num(x.users.length),'blue')+pill('Active',num(x.activeUsers),'good')+pill('Suspended',num(x.suspendedUsers),'red')+pill('Admins',num(x.admins),'purple')+'</div></div>'+
 '<div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Created</th><th>Action</th></tr></thead><tbody>'+
 (d.users||[]).map(u=>'<tr><td><strong>'+escText(u.full_name)+'</strong><div class="tiny-note">'+escText(u.email)+'</div></td><td><span class="badge '+(u.platform_role==='admin'?'purple':'blue')+'">'+escText(u.platform_role)+'</span></td><td><span class="badge '+(u.is_active?'good':'red')+'">'+(u.is_active?'Active':'Suspended')+'</span></td><td>'+formatShortDate(u.created_at)+'</td><td>'+ (u.platform_role==='admin'?'Protected':'<button type="button" class="btn tiny" onclick="platformEditUser(\''+escText(u.id)+'\')">Edit</button> <button type="button" class="btn tiny" onclick="platformSetUser(\''+u.id+'\','+(!u.is_active)+')">'+(u.is_active?'Suspend':'Activate')+'</button>'+' <button type="button" class="btn tiny hz-danger" onclick="platformRemoveUser(\''+u.id+'\')">Delete / deactivate</button>')+'</td></tr>').join('')+
 '</tbody></table></div></section>'+renderDirectorySections()+
 '<div class="grid two-col m-top" data-platform-tab="security"><section class="card pad platform-panel"><div class="platform-panel-head"><h2>Database backups</h2><p>Manual exports and private cloud backup actions.</p></div>'+
 '<div class="platform-backup-bar">'+(ready.database_engine==='sqlite'?'<a class="btn" href="/api/platform/backups/export" download>↓ Download SQLite backup</a>':'<span class="small-note">For MariaDB, take database backups from cPanel / JetBackup. The legacy SQLite snapshot button is not a MariaDB backup.</span>')+(ready.database_engine==='sqlite'?'<button type="button" class="btn" onclick="platformCloudBackup()">Send private S3 backup</button>':'')+'</div>'+
 '<div class="platform-pill-grid">'+pill('Last backup',backups.last_backup?.created_at?formatShortDate(backups.last_backup.created_at):'None','blue')+pill('Storage',backups.last_backup?.storage||'—','teal')+pill('SHA-256',backups.last_backup?.sha256?backups.last_backup.sha256.slice(0,12)+'…':'—','purple')+'</div></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Admin audit trail</h2><p>Recent administrator actions and governance activity.</p></div><div class="table-wrap"><table class="table"><thead><tr><th>Action</th><th>Target</th><th>Date</th></tr></thead><tbody>'+
 (audit.length?audit.map(x=>'<tr><td>'+escText(x.action)+'</td><td>'+escText(x.target_type)+'</td><td>'+formatDate(x.created_at)+'</td></tr>').join(''):'<tr><td colspan="3">No admin actions recorded yet.</td></tr>')+'</tbody></table></div></section></div>'+platformAnalyticsSections()+platformExportLinks()+studioSections()+renderInvoiceAdmin();
}


const platformNavTabs=[['overview','Overview'],['insights','Analytics'],['workspaces','Workspaces'],['people','Customers & vendors'],['billing','Subscriptions & invoices'],['site','Website & SEO'],['access','Access codes'],['security','Security & logs']];
let platformActiveTab='overview';
function platformTabs(){
 return '<nav class="platform-workbench-nav" role="tablist" aria-label="Platform admin areas">'+platformNavTabs.map(([id,label])=>
 '<button type="button" role="tab" data-tab="'+id+'" aria-selected="'+(platformActiveTab===id?'true':'false')+'" class="platform-tab '+(platformActiveTab===id?'active':'')+'" onclick="platformSwitchTab(\''+id+'\')">'+escText(label)+'</button>').join('')+'</nav>';
}
function trendGraph(title,items){
 const values=(items||[]),max=Math.max(1,...values.map(x=>Number(x.count)||0));
 return '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>'+escText(title)+'</h2><p>Actual new records by month, last 12 months</p></div><div class="platform-chart-bars" role="img" aria-label="'+escText(title)+' chart">'+values.map(x=>
  '<div class="platform-chart-item" title="'+escText(x.month+': '+x.count)+'"><span>'+num(x.count)+'</span><div class="platform-chart-track"><i style="height:'+Math.max(4,(Number(x.count)||0)/max*100)+'%"></i></div><small>'+escText((x.month||'').slice(5))+'</small></div>').join('')+'</div></section>';
}
function analyticsStatusBlock(title,items){
 return '<div class="platform-status-block"><h3>'+escText(title)+'</h3>'+((items||[]).length?(items||[]).slice(0,12).map(x=>'<div class="platform-breakdown-row"><span>'+escText(x.name||'Unspecified')+'</span><strong>'+num(x.count)+'</strong></div>').join(''):'<p class="small-note">No records yet</p>')+'</div>';
}
function analyticsMoneyRow(title,records){
 return '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>'+escText(title)+'</h2><p>Recorded amounts, separated by currency</p></div>'+(
 (records||[]).length?(records||[]).map(x=>'<div class="platform-money-row"><span>'+escText(x.currency||'Unknown currency')+' · '+num(x.count)+' records</span><strong>'+escText(x.currency||'')+' '+(Number(x.amount_cents||0)/100).toLocaleString('en-CA',{minimumFractionDigits:2,maximumFractionDigits:2})+'</strong></div>').join(''):
 '<p class="small-note">No recorded amounts available.</p>')+'</section>';
}

function renderDirectorySections(){
 const a=state.platformAnalytics||{},directory=a.directory||{},vendors=directory.vendors||[],clients=directory.clients||[];
 return '<div class="grid two-col m-top" data-platform-tab="people">'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Platform vendor directory</h2><p>Cross-workspace vendor records, categories and contact details. Edit without switching workspaces.</p></div>'+ 
 '<input class="search" placeholder="Search vendors" aria-label="Search vendors" oninput="platformFilterDirectory(\'platform-vendor-row\',this.value)">'+
 '<div class="table-wrap"><table class="table"><thead><tr><th>Vendor</th><th>Workspace</th><th>Category</th><th>Email</th><th>Action</th></tr></thead><tbody>'+
 (vendors.map(v=>'<tr class="platform-vendor-row" data-search="'+escText([v.name,v.workspace_name,v.category,v.email].join(' ').toLowerCase())+'"><td><strong>'+escText(v.name)+'</strong></td><td>'+escText(v.workspace_name)+'</td><td>'+escText(v.category)+'</td><td>'+escText(v.email)+'</td><td><button class="btn tiny" onclick="platformEditVendor(\''+escText(v.id)+'\')">Edit</button></td></tr>').join('')||'<tr><td colspan="5">No vendors yet.</td></tr>')+'</tbody></table></div>'+
 '<p class="tiny-note">Showing up to 200 vendor records. Use CSV export for larger datasets.</p></section>'+
 '<section class="card pad platform-panel"><div class="platform-panel-head"><h2>Client portals</h2><p>Manage active client-portal accounts across business workspaces.</p></div>'+
 '<input class="search" placeholder="Search clients" aria-label="Search clients" oninput="platformFilterDirectory(\'platform-client-row\',this.value)">'+
 '<div class="table-wrap"><table class="table"><thead><tr><th>Client</th><th>Workspace</th><th>Status</th><th>Action</th></tr></thead><tbody>'+
 (clients.map(c=>'<tr class="platform-client-row" data-search="'+escText([c.client_name,c.client_email,c.workspace_name].join(' ').toLowerCase())+'"><td><strong>'+escText(c.client_name)+'</strong><small>'+escText(c.client_email)+'</small></td><td>'+escText(c.workspace_name)+'</td><td><span class="badge '+(c.active?'good':'red')+'">'+(c.active?'Active':'Disabled')+'</span></td><td><button class="btn tiny" onclick="platformEditClient(\''+escText(c.id)+'\')">Edit</button> <button class="btn tiny" onclick="platformClientToggle(\''+escText(c.id)+'\','+(!c.active)+')">'+(c.active?'Disable':'Enable')+'</button></td></tr>').join('')||'<tr><td colspan="4">No client portals yet.</td></tr>')+'</tbody></table></div>'+
 '<p class="tiny-note">Client login links and PINs are never disclosed in the platform directory.</p></section></div>';
}
function renderInvoiceAdmin(){
 const a=state.platformAnalytics||{},items=a.directory?.invoices||[];
 return '<section class="card pad m-top" data-platform-tab="billing"><div class="platform-panel-head"><h2>Client invoices across Honestly Zen Event Planning</h2><p>Read-only financial overview. Actual collection is managed through each agency’s payment controls.</p></div>'+ 
 '<div class="table-wrap"><table class="table"><thead><tr><th>Invoice</th><th>Workspace</th><th>Total</th><th>Status</th><th>Due</th></tr></thead><tbody>'+
 (items.map(v=>'<tr><td><strong>'+escText(v.number||v.title||'Invoice')+'</strong><small>'+escText(v.title||'')+'</small></td><td>'+escText(v.workspace_name)+'</td><td>'+escText(v.currency)+' '+(Number(v.total_cents||0)/100).toLocaleString('en-CA',{minimumFractionDigits:2,maximumFractionDigits:2})+'</td><td><span class="badge blue">'+escText(v.status)+'</span></td><td>'+escText(v.due_date||'—')+'</td></tr>').join('')||'<tr><td colspan="5">No invoices have been issued yet.</td></tr>')+'</tbody></table></div><p class="tiny-note">Amounts are invoice face values, not verified platform revenue. Showing up to 200 invoices.</p></section>';
}
window.platformFilterDirectory=(rowClass,value)=>{const q=(value||'').toLowerCase().trim();document.querySelectorAll('.'+rowClass).forEach(row=>{row.hidden=!row.dataset.search.includes(q)})};
async function directoryUpdate(fn){try{await fn();await refresh();toast('Directory updated')}catch(e){toast(e.message)}}
window.platformEditVendor=id=>{
 const v=(state.platformAnalytics?.directory?.vendors||[]).find(x=>x.id===id);if(!v)return;
 const name=prompt('Vendor name',v.name);if(name===null)return;
 const category=prompt('Vendor category',v.category||'');if(category===null)return;
 const email=prompt('Vendor email (optional)',v.email||'');if(email===null)return;
 const phone=prompt('Vendor phone (optional)',v.phone||'');if(phone===null)return;
 if(!confirm('Update vendor '+v.name+'?'))return;
 directoryUpdate(()=>api('/platform/directory/vendors/'+encodeURIComponent(id),{method:'PATCH',body:{name,category,email,phone}}));
};
window.platformEditClient=id=>{
 const c=(state.platformAnalytics?.directory?.clients||[]).find(x=>x.id===id);if(!c)return;
 const client_name=prompt('Client name',c.client_name);if(client_name===null)return;
 const client_email=prompt('Client email',c.client_email);if(client_email===null)return;
 if(!confirm('Update client '+c.client_name+'?'))return;
 directoryUpdate(()=>api('/platform/directory/clients/'+encodeURIComponent(id),{method:'PATCH',body:{client_name,client_email}}));
};
window.platformClientToggle=(id,active)=>{
 if(!confirm(active?'Enable client portal?':'Disable this client portal?'))return;
 directoryUpdate(()=>api('/platform/directory/clients/'+encodeURIComponent(id),{method:'PATCH',body:{active}}));
};
function platformAnalyticsSections(){
 const d=state.platformAnalytics;
 if(!d)return '<section class="card pad m-top" data-platform-tab="insights"><h2>Platform analytics</h2><p class="small-note">Analytics data is unavailable. Other dashboard sections will still work.</p></section>';
 const c=d.counts||{},g=d.groups||{},money=d.money||{},trend=d.trends||{},recent=d.recent||{};
 return '<section class="platform-insights" data-platform-tab="insights">'+
 '<div class="platform-insights-grid">'+[
  ['Vendors',c.vendors],['Contacts',c.contacts],['Agency clients',c.clients],['Leads',c.leads],['Issued invoices',c.issued_invoices],['Recorded payments',c.agency_payment_records],['QR check-ins',c.checked_in_guest_records],['RSVP submissions',c.rsvp_submissions],['Published event sites',c.published_event_websites],['Event vendor assignments',c.event_vendor_assignments],['Active Connect accounts',c.active_vendor_connections],['Linked Stripe subscriptions',c.stripe_subscriptions_linked]
 ].map(([name,value])=>statCard(name,num(value??0),'Platform-wide','navy')).join('')+'</div>'+
 '<div class="grid three-col m-top">'+trendGraph('Account growth',trend.users)+trendGraph('Workspace growth',trend.workspaces)+trendGraph('Event creation',trend.events)+'</div>'+
 '<div class="grid three-col m-top">'+
 '<section class="card pad platform-panel">'+analyticsStatusBlock('Subscription status',g.subscription_statuses)+analyticsStatusBlock('Workspace plans',g.workspace_plans)+'</section>'+
 '<section class="card pad platform-panel">'+analyticsStatusBlock('Event status',g.event_statuses)+analyticsStatusBlock('RSVP status',g.guest_rsvp_statuses)+'</section>'+
 '<section class="card pad platform-panel">'+analyticsStatusBlock('Lead pipeline',g.lead_stages)+analyticsStatusBlock('Vendor categories',g.vendor_categories)+'</section></div>'+
 '<div class="grid three-col m-top">'+analyticsMoneyRow('Issued agency invoices',money.issued_invoices)+analyticsMoneyRow('Recorded agency payments',money.recorded_agency_payments)+analyticsMoneyRow('Paid client checkouts',money.stripe_invoice_checkouts_paid)+'</div>'+
 '<section class="card pad m-top"><div class="platform-panel-head"><h2>Recent platform events</h2><p>Newest events across all workspaces</p></div><div class="table-wrap"><table class="table"><thead><tr><th>Event</th><th>Workspace</th><th>Status</th><th>Created</th></tr></thead><tbody>'+
 ((recent.events||[]).map(x=>'<tr><td>'+escText(x.name)+'</td><td>'+escText(x.workspace_name)+'</td><td>'+escText(x.status)+'</td><td>'+formatShortDate(x.created_at)+'</td></tr>').join('')||'<tr><td colspan="4">No events yet.</td></tr>')+'</tbody></table></div></section>'+
 '<p class="platform-disclaimer">'+escText(d.notes?.financial||'Financial records shown do not imply settled payments or recurring platform revenue.')+'</p></section>';
}
function platformExportLinks(){
 const lists=[['users','Accounts'],['workspaces','Workspaces'],['events','Events'],['vendors','Vendors'],['contacts','Contacts'],['clients','Clients'],['invoices','Invoices'],['payments','Payments'],['access_codes','Access codes'],['audit','Audit log']];
 return '<section class="card pad m-top" data-platform-tab="security"><div class="platform-section-head"><div><h2>Admin data exports</h2><p class="small-note">Authenticated CSV exports of platform records. Sensitive access-code secrets and payment credentials are excluded. Maximum 10,000 records per dataset.</p></div></div><div class="platform-export-links">'+lists.map(([id,label])=>'<a class="btn" download href="/api/platform/export/'+id+'">'+escText(label)+' ↓</a>').join('')+'</div></section>';
}
window.platformSwitchTab=id=>{
 if(!platformNavTabs.some(x=>x[0]===id))return;
 platformActiveTab=id;
 document.querySelectorAll('[data-platform-tab]').forEach(node=>{
  if(node.classList.contains('platform-tab'))return;
  node.hidden=node.getAttribute('data-platform-tab')!==id;
 });
 document.querySelectorAll('.platform-tab').forEach(node=>{const active=node.dataset.tab===id;node.classList.toggle('active',active);node.setAttribute('aria-selected',active?'true':'false')});
 const top=document.querySelector('.platform-workbench-nav');if(top)top.scrollIntoView({behavior:'auto',block:'start'});
};
window.platformAfterRender=()=>window.platformSwitchTab(platformActiveTab);
const siteFields=[
 ['site_name','Website name'],['seo_title','SEO title'],['seo_description','Search description'],
 ['seo_keywords','SEO keywords'],['hero_title','Landing page headline'],
 ['hero_description','Landing page description'],
 ['accent_color','Theme accent (#RRGGBB)']
];
function studioSections(){
 const d=state.platformStudio||{site:{},packages:[]};
 return '<section class="card pad m-top" id="platform-site-editor" data-platform-tab="site"><div class="platform-section-head"><div><h2>Website · SEO · branding</h2><p class="small-note">Control your platform landing page, branding, search preview and public discovery from the admin console.</p></div><div class="platform-inline-badges">'+pill('Accounts',num(d.accounts||0),'blue')+pill('Stripe',d.billing_secret_configured?'Configured':'Missing',d.billing_secret_configured?'good':'red')+pill('Invoice payments',d.invoice_secret_configured?'Configured':'Missing',d.invoice_secret_configured?'good':'red')+'</div></div>'+
 '<div class="platform-site-preview" id="platformSitePreview" style="--preview-accent:'+escText(/^#[a-fA-F0-9]{6}$/.test(d.site?.accent_color||'')?d.site.accent_color:'#137c6a')+'"><div class="platform-site-preview-bar"><strong data-preview-site>'+escText(d.site?.site_name||'Honestly Zen Event Planning')+'</strong><span>Website preview</span></div><div class="platform-site-preview-hero"><small>YOUR PLATFORM</small><h3 data-preview-hero>'+escText(d.site?.hero_title||'Every event deserves a beautiful beginning.')+'</h3><p data-preview-description>'+escText(d.site?.hero_description||'Create, invite, organize and celebrate—all in one place.')+'</p><span data-preview-cta>Get started with Honestly Zen Event Planning ↗</span></div></div>'+
 '<form oninput="platformSitePreview(this)" onsubmit="platformSaveSite(event)"><div class="grid two-col">'+
 siteFields.map(([key,label])=>'<label class="field"><span>'+escText(label)+'</span><input name="'+key+'" value="'+escText(d.site?.[key]||'')+'" maxlength="'+(key.endsWith('_url')?2048:350)+'"></label>').join('')+
 [['logo_url','Site logo','logo'],['favicon_url','Browser favicon','favicon'],['social_image_url','Social share preview','social']].map(([key,label,kind])=>'<div class="field platform-media-field"><span>'+label+'</span><input type="hidden" name="'+key+'" value="'+escText(d.site?.[key]||'')+'"><input type="file" accept="image/png,image/jpeg,image/webp" aria-label="Upload '+label+'" onchange="platformUploadImage(this,\''+key+'\',\''+kind+'\')"><small>Upload JPG, PNG or WebP, up to 4 MB. Uploaded images replace external URLs.</small><div class="platform-image-preview">'+(d.site?.[key]?'<img src="'+escText(d.site[key])+'" loading="lazy" alt="'+label+'">':'No image uploaded')+'</div><button type="button" class="btn tiny" onclick="platformRemoveImage(this,\''+key+'\')">Remove image</button></div>').join('')+
 '</div><label class="rsvp-check-label"><input name="robots_index" type="checkbox" '+(d.site?.robots_index!=='0'?'checked':'')+'> Allow Google and search engines to index the landing page</label>'+
 '<p><button class="btn primary" type="submit">Save website settings</button> <a class="btn" href="/" target="_blank" rel="noopener">Preview landing page</a> <a class="btn" href="/sitemap.xml" target="_blank">View sitemap</a></p></form></section>'+
 '<section class="card pad m-top" id="platform-packages" data-platform-tab="billing"><div class="platform-section-head"><div><h2>Subscription package studio</h2><p class="small-note">Create and maintain packages, quotas and Stripe price IDs for your SaaS plans.</p></div><div class="platform-inline-badges">'+pill('Packages',num((d.packages||[]).length),'blue')+pill('Visible',num((d.packages||[]).filter(x=>x.is_active).length),'good')+pill('Hidden',num((d.packages||[]).filter(x=>!x.is_active).length),'red')+'</div></div>'+
 '<div class="table-wrap"><table class="table"><thead><tr><th>Package</th><th>Description</th><th>Quotas</th><th>Stripe price IDs</th><th>Status</th><th>Action</th></tr></thead><tbody>'+
 (d.packages||[]).map(pkg=>'<tr><td><strong>'+escText(pkg.label)+'</strong><div class="tiny-note">'+escText(pkg.id)+'</div></td><td>'+escText(pkg.description||'No description')+'</td><td>'+num(pkg.max_events)+' events · '+num(pkg.max_guests)+' guests · '+num(pkg.max_members)+' staff</td><td><small>'+escText(pkg.stripe_monthly_price||'Monthly not set')+'</small><div class="tiny-note">'+escText(pkg.stripe_yearly_price||'Yearly not set')+'</div></td><td><span class="badge '+(pkg.is_active?'good':'red')+'">'+(pkg.is_active?'Active':'Hidden')+'</span></td><td><button class="btn tiny" onclick="platformEditPackage(\''+escText(pkg.id)+'\')">Edit package</button></td></tr>').join('')+
 '</tbody></table></div><form onsubmit="platformAddPackage(event)"><h3>New package</h3><div class="grid three-col">'+
 field('Package ID','id','premium')+field('Display name','label','Premium')+
 fieldOptional('Description','description','Premium event planning features')+
 field('Max events','max_events','100','number')+field('Max guests','max_guests','10000','number')+
 field('Max team members','max_members','25','number')+fieldOptional('Stripe monthly Price ID','stripe_monthly_price')+fieldOptional('Stripe yearly Price ID','stripe_yearly_price')+'</div><button class="btn primary" type="submit">Create package</button></form></section>';
}
const platformFileBase64=async file=>{
 const b=new Uint8Array(await file.arrayBuffer());let out='';
 for(let i=0;i<b.length;i+=32768)out+=String.fromCharCode(...b.subarray(i,i+32768));return btoa(out);
};
window.platformUploadImage=async(input,key,kind)=>{
 const file=input.files?.[0];if(!file)return;
 if(!['image/jpeg','image/png','image/webp'].includes(file.type)||!file.size||file.size>4*1024*1024){toast('Choose a JPG, PNG or WebP smaller than 4 MB');input.value='';return}
 input.disabled=true;
 try{
   const result=await api('/platform/media',{method:'POST',body:{kind,content_type:file.type,data_base64:await platformFileBase64(file)}});
   const field=input.closest('.platform-media-field');field.querySelector('input[type="hidden"]').value=result.url;
   field.querySelector('.platform-image-preview').innerHTML='<img src="'+escText(result.url)+'" loading="lazy" alt="Uploaded '+kind+'">';
   toast('Image uploaded. Save website settings to publish it.');
 }catch(e){toast(e.message)}finally{input.disabled=false;input.value=''}
};
window.platformRemoveImage=(button,key)=>{
 const row=button.closest('.platform-media-field');row.querySelector('input[type="hidden"]').value='';
 row.querySelector('.platform-image-preview').textContent='No image selected';
 toast('Click Save website settings to remove the image.');
};
window.platformSaveSite=event=>{
 event.preventDefault();const form=event.target,data=Object.fromEntries(new FormData(form));
 data.robots_index=form.elements.robots_index.checked?'1':'0';
 updateStudio(()=>api('/platform/site-settings',{method:'PATCH',body:data}),'Website settings saved');
};
async function updateStudio(fn,message){
 try{await fn();[state.platformStudio,state.platform]=await Promise.all([api('/platform/studio'),api('/platform/overview')]);window.render();toast(message)}catch(e){toast(e.message)}
}
window.platformAddPackage=e=>{
 e.preventDefault();const d=Object.fromEntries(new FormData(e.target));
 ['max_events','max_guests','max_members'].forEach(k=>d[k]=Number(d[k]));
 updateStudio(()=>api('/platform/packages',{method:'POST',body:d}),'Package created');
};
window.platformEditPackage=id=>{
 const pkg=(state.platformStudio?.packages||[]).find(x=>x.id===id);if(!pkg)return;
 const modal=document.getElementById('modalRoot');if(!modal){toast('Editor is unavailable');return}
 modal.innerHTML='<div class="modal-overlay" role="presentation" onclick="if(event.target===this)platformClosePackageEditor()"><div class="modal" role="dialog" aria-modal="true" aria-label="Edit subscription package"><div class="modal-head"><h2>Edit package · '+escText(pkg.label)+'</h2><button type="button" class="xclose" onclick="platformClosePackageEditor()" aria-label="Close">×</button></div><form onsubmit="platformSavePackage(event)"><div class="modal-body"><p class="small-note">Update plan copy, usage quotas and Stripe recurring Price IDs. Existing paid subscriptions are not charged or repriced by saving this form.</p><input type="hidden" name="id" value="'+escText(pkg.id)+'"><div class="inline-fields">'+
 field('Display name','label',pkg.label)+fieldOptional('Description','description',pkg.description||'')+
 field('Max events','max_events',pkg.max_events,'number')+field('Max guests','max_guests',pkg.max_guests,'number')+field('Max staff','max_members',pkg.max_members,'number')+
 fieldOptional('Stripe monthly Price ID','stripe_monthly_price',pkg.stripe_monthly_price||'')+fieldOptional('Stripe yearly Price ID','stripe_yearly_price',pkg.stripe_yearly_price||'')+
 '</div><label class="rsvp-check-label" style="margin-top:14px"><input name="is_active" type="checkbox" '+(pkg.is_active?'checked':'')+'> Package available for new subscriptions</label><div class="modal-actions"><button class="btn" type="button" onclick="platformClosePackageEditor()">Cancel</button><button class="btn primary" type="submit">Save package</button></div></div></form></div></div>';
};
window.platformClosePackageEditor=()=>{const modal=document.getElementById('modalRoot');if(modal)modal.innerHTML=''};
window.platformSavePackage=event=>{
 event.preventDefault();const form=event.target;const d=Object.fromEntries(new FormData(form));
 const id=d.id;delete d.id;
 ['max_events','max_guests','max_members'].forEach(k=>d[k]=Number(d[k]));
 d.is_active=form.elements.is_active.checked;
 if(id==='free' && !d.is_active){toast('Starter package must remain active');return}
 if(!confirm('Save changes for '+id+'? Existing customer subscriptions are not repriced.'))return;
 platformClosePackageEditor();
 updateStudio(()=>api('/platform/packages/'+encodeURIComponent(id),{method:'PATCH',body:d}),'Package updated');
};
window.platformSitePreview=form=>{
 const root=document.getElementById('platformSitePreview');if(!root||!form)return;
 const get=name=>form.elements[name]?.value||'';
 const color=get('accent_color');if(/^#[a-fA-F0-9]{6}$/.test(color))root.style.setProperty('--preview-accent',color);
 root.querySelector('[data-preview-site]').textContent=get('site_name')||'Honestly Zen Event Planning';
 root.querySelector('[data-preview-hero]').textContent=get('hero_title')||'Every event deserves a beautiful beginning.';
 root.querySelector('[data-preview-description]').textContent=get('hero_description')||'Create, invite, organize and celebrate—all in one place.';
};
window.platformEditUser=id=>{
 const u=(p().users||[]).find(x=>x.id===id);if(!u)return;
 const name=prompt('Full name',u.full_name);if(name===null)return;
 const email=prompt('Email address',u.email);if(email===null)return;
 if(!confirm('Update '+u.email+' account details?'))return;
 update(()=>api('/platform/users/'+id+'/details',{method:'PATCH',body:{full_name:name,email:email}}),'Account updated');
};
async function update(work,message){try{await work();state.platform=await api('/platform/overview');window.render();if(message)toast(message)}catch(e){toast(e.message)}}
window.platformEnforceCodes=checked=>{if(checked&&!confirm('Require an access code for all new signups and workspace creation? Create codes first.')){window.render();return}
 update(()=>api('/platform/settings',{method:'PUT',body:{require_access_code:checked}}),'Signup policy updated')};
window.platformNewCode=async event=>{event.preventDefault();const d=Object.fromEntries(new FormData(event.target));const req={label:d.label,workspace_type:d.workspace_type,
 max_events:Number(d.max_events),max_guests:Number(d.max_guests),max_members:Number(d.max_members),max_uses:Number(d.max_uses)};
 try{const made=await api('/platform/codes',{method:'POST',body:req});
 state.platform=await api('/platform/overview');window.render();
 const out=document.createElement('div');out.className='platform-reveal';
 const title=document.createElement('strong');title.textContent='New code — copy it now (it will not be displayed again)';
 const field=document.createElement('textarea');field.readOnly=true;field.value=made.access_code;field.rows=2;
 const copy=document.createElement('button');copy.type='button';copy.className='btn primary';copy.textContent='Copy code';copy.onclick=()=>navigator.clipboard.writeText(field.value).then(()=>toast('Code copied')).catch(()=>{field.select();toast('Select and copy the code')});
 out.append(title,field,copy);document.querySelector('[data-platform-tab="access"] .platform-panel')?.prepend(out);
 }catch(e){toast(e.message)}};
window.platformToggleCode=(id,active)=>update(()=>api('/platform/codes/'+id,{method:'PATCH',body:{is_active:active}}),'Code updated');
window.platformRemoveCode=(id)=>{if(!confirm('Revoke this access code? Previous redemptions will remain in the audit history.'))return;update(()=>api('/platform/codes/'+encodeURIComponent(id),{method:'DELETE'}),'Access code revoked')};
window.platformRemoveUser=(id)=>{if(!confirm('Deactivate this customer account and revoke its sessions? Their bookings, invoices and data will be kept.'))return;update(()=>api('/platform/users/'+encodeURIComponent(id),{method:'DELETE'}),'Customer account deactivated')};
window.platformSuspendWorkspace=(id,active)=>{if(!confirm(active?'Reactivate this workspace?':'Suspend this workspace and block its members?'))return;
 update(()=>api('/platform/workspaces/'+id,{method:'PATCH',body:{is_active:active}}),'Workspace updated')};
window.platformEditWorkspace=id=>{
 const w=(p().workspaces||[]).find(x=>x.id===id);if(!w)return;
 const answer=prompt('Limits: max events, max guests, max staff (comma-separated)',[w.max_events,w.max_guests,w.max_members].join(', '));
 if(!answer)return;const values=answer.split(',').map(x=>Number(x.trim()));
 if(values.length!==3||values.some(x=>!Number.isInteger(x)||x<1)){toast('Enter 3 whole numbers greater than 0');return}
 update(()=>api('/platform/workspaces/'+id,{method:'PATCH',body:{max_events:values[0],max_guests:values[1],max_members:values[2]}}),'Limits updated')};
window.platformSetUser=(id,active)=>{if(!confirm(active?'Reactivate this account?':'Suspend this user account?'))return;
 update(()=>api('/platform/users/'+id,{method:'PATCH',body:{is_active:active}}),'Account updated')};
window.platformClaim=async()=>{
 const key=prompt('Enter your server-configured EVENTOS_ADMIN_BOOTSTRAP_TOKEN. Do not share this secret with customers.');
 if(!key)return;
 try{await api('/platform/bootstrap',{method:'POST',body:{token:key}});const me=await api('/me');state.user=me.user;toast('Platform administrator activated');state.platform=await api('/platform/overview');go('platform')}catch(e){toast(e.message)}
};
window.platformGrantPlan=id=>{
 const w=(p().workspaces||[]).find(x=>x.id===id);if(!w)return;
 const available=(state.platformStudio?.packages||[]).filter(x=>x.is_active).map(x=>x.id);
 const plan=prompt('Manual subscription package ('+available.join(', ')+')',available.includes('pro')?'pro':available[0]);
 if(!plan)return;
 if(!available.includes(plan)){toast('Choose one of the listed packages');return}
 if(!confirm('Grant '+plan+' to '+w.name+'? This does not charge the customer.'))return;
 update(()=>api('/platform/workspaces/'+id+'/subscription',{method:'PATCH',body:{plan}}),'Plan updated');
};
window.platformFilterWorkspaces=query=>{
 const needle=(query||'').trim().toLowerCase();
 document.querySelectorAll('.platform-workspace-row').forEach(row=>{row.hidden=!row.dataset.search.includes(needle)});
};
window.platformShowFeatures=id=>{
 const el=document.getElementById('platform-features-'+id);if(el)el.hidden=!el.hidden;
};
window.platformToggleFeature=(id,feature,enabled)=>
 update(()=>api('/platform/workspaces/'+id+'/features',{method:'PATCH',body:{feature,enabled}}),'Workspace feature access updated');
window.platformCloudBackup=async()=>{
 if(!confirm('Save an encrypted backup in the configured private S3 bucket? This does not enable recurring backups.'))return;
 try{
  const result=await api('/platform/backups/cloud',{method:'POST'});
  state.platformBackups=await api('/platform/backups');window.render();
  toast('Encrypted cloud backup saved: '+result.sha256.slice(0,12)+'…');
 }catch(e){toast(e.message)}
};
window.platformJump=id=>document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'start'});
window.EventOSPlatform={render};
})();
